import { AssemblyStep, FurnitureProject } from '@/types/furniture';

/**
 * Automatically computes physical flat-pack assembly sequences
 * based on joinery dependencies and structural precedence.
 */
export function generateAssemblySequence(project: FurnitureProject): AssemblyStep[] {
  const steps: AssemblyStep[] = [];
  const { config, components } = project;

  // Step 1: Hardware Pre-insertion
  steps.push({
    stepNumber: 1,
    title: 'Pre-insert Cam Bolts & Hardwood Dowels into Side Panels',
    instruction:
      'Lay Left Side Panel (comp_side_left) and Right Side Panel (comp_side_right) flat on a clean protective surface. Thread 8x Häfele Minifix connecting bolts into pre-drilled M6 holes and tap 8x 8×30mm fluted beech dowels with a rubber mallet.',
    targetComponentIds: ['comp_side_left', 'comp_side_right'],
    requiredHardware: [
      { name: 'Minifix 15 Connecting Bolt', count: 8, iconType: 'cam_lock' },
      { name: 'Beech Dowel 8×30mm', count: 8, iconType: 'dowel' },
    ],
    requiredTools: ['PZ2 Screwdriver', 'Rubber Mallet'],
    estimatedMinutes: 8,
    safetyTip: 'Ensure dowels are inserted straight to at least 15mm depth without mushrooming the ends.',
  });

  // Step 2: Plinth & Base Assembly
  if (config.plinthHeight > 0) {
    steps.push({
      stepNumber: 2,
      title: 'Assemble Base Plinth and Mount Leveler Feet',
      instruction:
        'Attach adjustable leveler feet to the Bottom Structural Panel. Fix the front toe-kick plinth using 90° angle brackets or cam connectors.',
      targetComponentIds: ['comp_bottom_panel', 'comp_plinth_front'],
      requiredHardware: [
        { name: 'Adjustable Leveler M10', count: 4, iconType: 'foot' },
        { name: 'Corner Fastening Bracket', count: 4, iconType: 'bracket' },
      ],
      requiredTools: ['5mm Hex Key', 'PZ2 Screwdriver'],
      estimatedMinutes: 6,
    });
  }

  // Step 3: Main Carcass Assembly
  steps.push({
    stepNumber: 3,
    title: 'Connect Bottom and Top Panels to Left Side',
    instruction:
      'Position Bottom and Top panels onto the Left Side Panel dowels and connecting bolts. Insert Minifix 15mm cam casings into internal pockets and rotate 180° clockwise until fully locked.',
    targetComponentIds: ['comp_side_left', 'comp_bottom_panel', 'comp_top_panel'],
    requiredHardware: [
      { name: 'Minifix 15 Cam Casing', count: 4, iconType: 'cam_lock' },
    ],
    requiredTools: ['PZ2 Screwdriver'],
    estimatedMinutes: 10,
  });

  // Step 4: Vertical Partitions & Dividers
  const partitions = components.filter((c) => c.type === 'partition');
  if (partitions.length > 0) {
    steps.push({
      stepNumber: 4,
      title: 'Install Internal Vertical Divider Partitions',
      instruction:
        'Slide internal vertical partition panels into position between top and bottom carcass panels. Secure with confirmat screws or dual-sided cam pins.',
      targetComponentIds: partitions.map((p) => p.id),
      requiredHardware: [
        { name: 'Confirmat Screw 7.0×50mm', count: partitions.length * 4, iconType: 'screw' },
      ],
      requiredTools: ['4mm Hex Bit Drill / Allen Key'],
      estimatedMinutes: 8,
    });
  }

  // Step 5: Slide in Grooved Back Panel
  steps.push({
    stepNumber: 5,
    title: 'Slide Back Enclosure Panel into Grooves',
    instruction:
      'Before attaching the remaining side panel, slide the 6mm HDF back panel down through the milled 8mm carcass grooves from the rear. Verify complete seating into the bottom groove.',
    targetComponentIds: ['comp_back_panel'],
    requiredHardware: [],
    requiredTools: ['Square measuring tape'],
    estimatedMinutes: 4,
    safetyTip: 'Measure diagonal corners (X-brace check) to guarantee the carcass is 100% square (90°) before closing.',
  });

  // Step 6: Close Carcass with Right Side Panel
  steps.push({
    stepNumber: 6,
    title: 'Mount Right Side Panel and Lock Cams',
    instruction:
      'Align Right Side Panel onto the protruding top, bottom, and partition dowels and bolts. Tighten all 4x Minifix cam locks securely.',
    targetComponentIds: ['comp_side_right'],
    requiredHardware: [
      { name: 'Minifix 15 Cam Casing', count: 4, iconType: 'cam_lock' },
    ],
    requiredTools: ['PZ2 Screwdriver'],
    estimatedMinutes: 6,
  });

  // Step 7: Shelf Hardware & Interior Shelving
  const shelves = components.filter((c) => c.category === 'interior');
  if (shelves.length > 0) {
    steps.push({
      stepNumber: 7,
      title: 'Insert Duplo Shelf Support Pins and Place Shelves',
      instruction:
        'Push nickel-plated 5mm shelf pins into the CNC system-32 holes at your desired height increments. Rest shelf boards securely onto anti-tilt rubber lips.',
      targetComponentIds: shelves.map((s) => s.id),
      requiredHardware: [
        { name: 'Duplo 5mm Steel Shelf Pin', count: shelves.length * 4, iconType: 'shelf_pin' },
      ],
      requiredTools: ['None (Push-fit)'],
      estimatedMinutes: 5,
    });
  }

  // Step 8: Drawer Assembly & Runner Mounts
  const drawers = components.filter((c) => c.category === 'drawers');
  if (drawers.length > 0) {
    steps.push({
      stepNumber: 8,
      title: 'Assemble Drawer Boxes and Mount Blum Slides',
      instruction:
        'Fasten drawer boxes together, attach drawer fronts, screw architectural bar handles, and click undermount runners into the system holes in the carcass sides.',
      targetComponentIds: drawers.map((d) => d.id),
      requiredHardware: [
        { name: 'Blum MOVENTO 550mm Slide Pair', count: config.drawersCount, iconType: 'slide' },
        { name: 'Architectural Bar Pull (160mm)', count: config.drawersCount, iconType: 'handle' },
      ],
      requiredTools: ['Cordless Drill / PZ2', '3mm Pilot bit'],
      estimatedMinutes: 15,
    });
  }

  // Step 9: Doors & Soft-Close Hinges
  const doors = components.filter((c) => c.category === 'doors');
  if (doors.length > 0) {
    steps.push({
      stepNumber: 9,
      title: 'Clip Concealed Hinges and Hang Front Doors',
      instruction:
        'Press 35mm Blum Clip Top hinges into pre-milled door cups and tighten expanding dowel screws. Clip hinge arms onto carcass mounting plates. Use 3-way cam screws to align door gaps to 2.5mm.',
      targetComponentIds: doors.map((d) => d.id),
      requiredHardware: [
        { name: 'Blum Clip Top BLUMOTION 110° Hinge', count: doors.length * 3, iconType: 'hinge' },
        { name: 'Architectural Bar Pull (160mm)', count: doors.length, iconType: 'handle' },
      ],
      requiredTools: ['PZ2 Screwdriver'],
      estimatedMinutes: 12,
      safetyTip: 'Use two people when holding and aligning full-height 2200mm doors.',
    });
  }

  // Step 10: Final Anti-Tip Wall Anchor
  steps.push({
    stepNumber: steps.length + 1,
    title: 'Anchor Furniture to Wall & Quality Inspection',
    instruction:
      'Fasten 2x heavy-duty steel safety brackets to top structural corners and secure directly into wall studs with appropriate heavy masonry/stud anchors. Inspect all clearances and smooth soft-close action.',
    targetComponentIds: ['comp_top_panel'],
    requiredHardware: [
      { name: 'Heavy Duty Anti-Tip Wall Bracket', count: 2, iconType: 'bracket' },
      { name: 'Masonry / Stud Anchor Screw', count: 2, iconType: 'screw' },
    ],
    requiredTools: ['Spirit Level', 'Stud Finder', 'Masonry Drill'],
    estimatedMinutes: 8,
    safetyTip: 'Mandatory compliance with safety standard EN 14749 for tip-over hazard prevention.',
  });

  return steps;
}
