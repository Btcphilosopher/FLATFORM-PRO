package com.example.ui.panels

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.DesignWarning
import com.example.domain.model.FurnitureProject
import com.example.domain.model.WarningSeverity
import com.example.ui.theme.*

@Composable
fun DesignValidationPanel(
    project: FurnitureProject,
    onAutoFixWarning: (DesignWarning) -> Unit,
    onSelectComponent: (String?) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxHeight()
            .background(CadSurface)
            .testTag("design_validation_panel")
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "DESIGN RULE CHECKS (DRC)",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = CadAccentBlue,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "${project.warnings.count { it.severity == WarningSeverity.ERROR }} Errors • ${project.warnings.count { it.severity == WarningSeverity.WARNING }} Warnings",
                    fontSize = 10.sp,
                    color = CadTextMuted
                )
            }
        }

        HorizontalDivider(color = CadBorder)

        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(project.warnings, key = { it.id }) { warn ->
                val (borderColor, badgeColor, icon) = when (warn.severity) {
                    WarningSeverity.ERROR -> Triple(CadAccentRed, CadAccentRed.copy(alpha = 0.15f), Icons.Default.Error)
                    WarningSeverity.WARNING -> Triple(CadAccentAmber, CadAccentAmber.copy(alpha = 0.15f), Icons.Default.Warning)
                    WarningSeverity.INFO -> Triple(CadAccentGreen, CadAccentGreen.copy(alpha = 0.15f), Icons.Default.CheckCircle)
                }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = CadSurfaceVariant),
                    border = androidx.compose.foundation.BorderStroke(1.dp, borderColor.copy(alpha = 0.7f)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(icon, contentDescription = null, tint = borderColor, modifier = Modifier.size(18.dp))
                            Text(
                                text = warn.title,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = CadTextPrimary,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Text(
                            text = warn.message,
                            fontSize = 11.sp,
                            color = CadTextSecondary,
                            lineHeight = 15.sp
                        )

                        if (warn.canAutoFix && warn.fixActionTitle != null) {
                            Button(
                                onClick = { onAutoFixWarning(warn) },
                                shape = RoundedCornerShape(6.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = CadAccentBlue, contentColor = Color.Black),
                                modifier = Modifier.fillMaxWidth().height(30.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Icon(Icons.Default.AutoFixHigh, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Text("Auto-Fix: ${warn.fixActionTitle}", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
