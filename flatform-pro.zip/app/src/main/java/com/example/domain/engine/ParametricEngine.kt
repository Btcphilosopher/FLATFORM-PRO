package com.example.domain.engine

import com.example.domain.hardware.HardwareCatalog
import com.example.domain.materials.MaterialLibrary
import com.example.domain.model.*
import kotlin.math.max
import kotlin.math.min

object ParametricEngine {

    /**
     * Generates a complete engineered furniture project from parametric inputs.
     */
    fun buildProject(
        id: String,
        name: String,
        templateType: FurnitureTemplateType,
        params: FurnitureParameters,
        variants: List<DesignVariant> = emptyList(),
        activeVariantId: String? = null
    ): FurnitureProject {
        val components = generateComponents(params)
        val hardware = generateHardware(params, components)
        val bom = generateBom(components, hardware, params)
        val cutList = generateCutList(components)
        val nesting = calculateNesting(cutList)
        val assemblySteps = generateAssemblySteps(components, hardware, params)
        val warnings = validateDesign(params, components, hardware)

        return FurnitureProject(
            id = id,
            name = name,
            templateType = templateType,
            parameters = params,
            components = components,
            hardwareList = hardware,
            bomItems = bom,
            cutListItems = cutList,
            nestingSheets = nesting,
            assemblySteps = assemblySteps,
            warnings = warnings,
            variants = variants,
            activeVariantId = activeVariantId
        )
    }

    private fun generateComponents(params: FurnitureParameters): List<FurnitureComponent> {
        val list = mutableListOf<FurnitureComponent>()
        val w = params.widthMm
        val h = params.heightMm
        val d = params.depthMm
        val t = params.panelThicknessMm
        val toeKick = params.toeKickHeightMm
        val backT = params.backPanelThicknessMm
        val backInset = params.backPanelInsetMm
        val matId = params.primaryMaterialId
        val accentMatId = params.accentMaterialId

        val carcassH = h - toeKick
        val internalW = w - (2 * t)
        val internalH = carcassH - (2 * t)
        val internalD = d - backInset - backT

        // 1. STRUCTURE - Left Side Panel
        list.add(
            FurnitureComponent(
                id = "comp_side_left",
                name = "Left Side Panel",
                group = ComponentGroup.STRUCTURE,
                role = ComponentRole.SIDE_LEFT,
                dimensions = Dimension3D(width = t, height = carcassH, depth = d),
                position = Vector3D(x = 0f, y = toeKick, z = 0f),
                materialId = matId,
                edgeTreatment = EdgeTreatment(
                    top = EdgeBandingType.ABS_1MM,
                    bottom = EdgeBandingType.ABS_1MM,
                    left = EdgeBandingType.ABS_2MM, // Front edge exposed
                    right = EdgeBandingType.NONE
                ),
                operations = listOf(
                    CncOperation("op_l_sys32", CncOperationType.BORE_HOLE_32MM_SYSTEM, "Line Boring 32mm System (Ø5mm)", diameterMm = 5f, depthMm = 13f, xMm = 37f, yMm = 100f),
                    CncOperation("op_l_cam", CncOperationType.CAM_LOCK_POCKET_15MM, "Cam Lock Pin Holes (Ø8mm)", diameterMm = 8f, depthMm = 34f, xMm = 50f, yMm = 50f),
                    CncOperation("op_l_rabbet", CncOperationType.RABBET_BACK_PANEL, "Back Panel Groove (6×8mm)", diameterMm = 6f, depthMm = 8f, xMm = d - backInset, lengthMm = carcassH)
                ),
                jointType = params.defaultJoint,
                explosiveOffset = Vector3D(x = -350f, y = 0f, z = 0f)
            )
        )

        // 2. STRUCTURE - Right Side Panel
        list.add(
            FurnitureComponent(
                id = "comp_side_right",
                name = "Right Side Panel",
                group = ComponentGroup.STRUCTURE,
                role = ComponentRole.SIDE_RIGHT,
                dimensions = Dimension3D(width = t, height = carcassH, depth = d),
                position = Vector3D(x = w - t, y = toeKick, z = 0f),
                materialId = matId,
                edgeTreatment = EdgeTreatment(
                    top = EdgeBandingType.ABS_1MM,
                    bottom = EdgeBandingType.ABS_1MM,
                    left = EdgeBandingType.ABS_2MM, // Front edge
                    right = EdgeBandingType.NONE
                ),
                operations = listOf(
                    CncOperation("op_r_sys32", CncOperationType.BORE_HOLE_32MM_SYSTEM, "Line Boring 32mm System (Ø5mm)", diameterMm = 5f, depthMm = 13f, xMm = 37f, yMm = 100f),
                    CncOperation("op_r_cam", CncOperationType.CAM_LOCK_POCKET_15MM, "Cam Lock Pin Holes (Ø8mm)", diameterMm = 8f, depthMm = 34f, xMm = 50f, yMm = 50f),
                    CncOperation("op_r_rabbet", CncOperationType.RABBET_BACK_PANEL, "Back Panel Groove (6×8mm)", diameterMm = 6f, depthMm = 8f, xMm = d - backInset, lengthMm = carcassH)
                ),
                jointType = params.defaultJoint,
                explosiveOffset = Vector3D(x = 350f, y = 0f, z = 0f)
            )
        )

        // 3. STRUCTURE - Bottom Panel
        list.add(
            FurnitureComponent(
                id = "comp_bottom",
                name = "Bottom Base Panel",
                group = ComponentGroup.STRUCTURE,
                role = ComponentRole.BOTTOM_PANEL,
                dimensions = Dimension3D(width = internalW, height = t, depth = d),
                position = Vector3D(x = t, y = toeKick, z = 0f),
                materialId = matId,
                edgeTreatment = EdgeTreatment(
                    top = EdgeBandingType.NONE,
                    bottom = EdgeBandingType.NONE,
                    left = EdgeBandingType.ABS_2MM, // Front edge
                    right = EdgeBandingType.NONE
                ),
                operations = listOf(
                    CncOperation("op_b_cam", CncOperationType.CAM_LOCK_POCKET_15MM, "Cam Lock Face Pockets (Ø15mm)", diameterMm = 15f, depthMm = 13.5f, xMm = 34f, yMm = 50f)
                ),
                jointType = params.defaultJoint,
                explosiveOffset = Vector3D(x = 0f, y = -200f, z = 0f)
            )
        )

        // 4. STRUCTURE - Top Panel
        list.add(
            FurnitureComponent(
                id = "comp_top",
                name = "Top Crown Panel",
                group = ComponentGroup.STRUCTURE,
                role = ComponentRole.TOP_PANEL,
                dimensions = Dimension3D(width = internalW, height = t, depth = d),
                position = Vector3D(x = t, y = h - t, z = 0f),
                materialId = matId,
                edgeTreatment = EdgeTreatment(
                    top = EdgeBandingType.NONE,
                    bottom = EdgeBandingType.NONE,
                    left = EdgeBandingType.ABS_2MM,
                    right = EdgeBandingType.NONE
                ),
                operations = listOf(
                    CncOperation("op_t_cam", CncOperationType.CAM_LOCK_POCKET_15MM, "Cam Lock Face Pockets (Ø15mm)", diameterMm = 15f, depthMm = 13.5f, xMm = 34f, yMm = 50f)
                ),
                jointType = params.defaultJoint,
                explosiveOffset = Vector3D(x = 0f, y = 300f, z = 0f)
            )
        )

        // 5. STRUCTURE - Back Panel
        if (params.hasBackPanel) {
            val backW = internalW + (2 * 6f) // Inset rabbet overlap
            val backH = internalH + (2 * 6f)
            list.add(
                FurnitureComponent(
                    id = "comp_back",
                    name = "Rear Back Panel (6mm)",
                    group = ComponentGroup.STRUCTURE,
                    role = ComponentRole.BACK_PANEL,
                    dimensions = Dimension3D(width = backW, height = backH, depth = backT),
                    position = Vector3D(x = t - 6f, y = toeKick + t - 6f, z = d - backInset),
                    materialId = "mat_white_melamine",
                    edgeTreatment = EdgeTreatment(EdgeBandingType.NONE, EdgeBandingType.NONE, EdgeBandingType.NONE, EdgeBandingType.NONE),
                    jointType = JointType.DADO_AND_RABBET,
                    explosiveOffset = Vector3D(x = 0f, y = 0f, z = 400f)
                )
            )
        }

        // 6. STRUCTURE - Plinth / Toe Kick
        if (toeKick > 0) {
            list.add(
                FurnitureComponent(
                    id = "comp_plinth_front",
                    name = "Front Plinth / Toe-Kick",
                    group = ComponentGroup.STRUCTURE,
                    role = ComponentRole.TOE_KICK_PLINTH,
                    dimensions = Dimension3D(width = internalW, height = toeKick, depth = t),
                    position = Vector3D(x = t, y = 0f, z = 30f),
                    materialId = matId,
                    edgeTreatment = EdgeTreatment(left = EdgeBandingType.ABS_1MM, top = EdgeBandingType.ABS_1MM),
                    explosiveOffset = Vector3D(x = 0f, y = -150f, z = -150f)
                )
            )
        }

        // 7. INTERIOR - Vertical Dividers
        val numDividers = max(0, params.dividerCount)
        val numBays = numDividers + 1
        val bayWidth = (internalW - (numDividers * t)) / numBays

        val dividerPositions = mutableListOf<Float>()
        for (i in 1..numDividers) {
            val divX = t + (i * bayWidth) + ((i - 1) * t)
            dividerPositions.add(divX)
            list.add(
                FurnitureComponent(
                    id = "comp_divider_$i",
                    name = "Vertical Divider 0$i",
                    group = ComponentGroup.INTERIOR,
                    role = ComponentRole.DIVIDER_VERTICAL,
                    dimensions = Dimension3D(width = t, height = internalH, depth = internalD),
                    position = Vector3D(x = divX, y = toeKick + t, z = 0f),
                    materialId = matId,
                    edgeTreatment = EdgeTreatment(left = EdgeBandingType.ABS_1MM),
                    operations = listOf(
                        CncOperation("op_div_${i}_bore", CncOperationType.BORE_HOLE_32MM_SYSTEM, "Double Sided System 32 Bore (Ø5mm)", diameterMm = 5f, depthMm = 8f)
                    ),
                    explosiveOffset = Vector3D(x = 0f, y = 0f, z = -100f * i)
                )
            )
        }

        // 8. INTERIOR - Shelves
        val shelfCount = params.shelfCount
        if (shelfCount > 0) {
            val shelvesPerBay = max(1, shelfCount / numBays)
            var currentShelfIdx = 1
            for (bay in 0 until numBays) {
                val startX = t + (bay * (bayWidth + t))
                val shelfSpanW = bayWidth - 2f // 2mm clearance for easy pin insertion
                val shelfDepth = internalD - 10f // 10mm setback from front
                val shelfVSpacing = internalH / (shelvesPerBay + 1)

                for (s in 1..shelvesPerBay) {
                    val shelfY = toeKick + t + (s * shelfVSpacing)
                    list.add(
                        FurnitureComponent(
                            id = "comp_shelf_$currentShelfIdx",
                            name = "Adjustable Shelf 0$currentShelfIdx (Bay ${bay + 1})",
                            group = ComponentGroup.INTERIOR,
                            role = ComponentRole.SHELF_ADJUSTABLE,
                            dimensions = Dimension3D(width = shelfSpanW, height = t, depth = shelfDepth),
                            position = Vector3D(x = startX + 1f, y = shelfY, z = 5f),
                            materialId = accentMatId,
                            edgeTreatment = EdgeTreatment(left = EdgeBandingType.ABS_1MM),
                            explosiveOffset = Vector3D(x = 0f, y = 150f + (s * 30f), z = -150f)
                        )
                    )
                    currentShelfIdx++
                }
            }
        }

        // 9. DRAWERS
        val drawerCount = params.drawerCount
        if (params.hasDrawers && drawerCount > 0) {
            val targetBay = 0 // Place drawers in bay 0
            val drawerBayW = bayWidth
            val drawerBayStartX = t
            val drawerH = min(220f, (internalH * 0.45f) / drawerCount)
            val slideLen = when {
                internalD >= 550f -> 500f
                internalD >= 450f -> 450f
                internalD >= 350f -> 350f
                else -> 300f
            }

            for (dIdx in 1..drawerCount) {
                val dY = toeKick + t + ((dIdx - 1) * (drawerH + 6f))
                val frontW = drawerBayW - (2 * params.doorGapMm)
                val frontH = drawerH - params.doorGapMm

                // Drawer Front Facade
                list.add(
                    FurnitureComponent(
                        id = "comp_drawer_front_$dIdx",
                        name = "Drawer Front 0$dIdx",
                        group = ComponentGroup.DRAWERS,
                        role = ComponentRole.DRAWER_FRONT,
                        dimensions = Dimension3D(width = frontW, height = frontH, depth = t),
                        position = Vector3D(x = drawerBayStartX + params.doorGapMm, y = dY + params.doorGapMm / 2f, z = -t),
                        materialId = matId,
                        edgeTreatment = EdgeTreatment(
                            top = EdgeBandingType.ABS_2MM,
                            bottom = EdgeBandingType.ABS_2MM,
                            left = EdgeBandingType.ABS_2MM,
                            right = EdgeBandingType.ABS_2MM
                        ),
                        operations = listOf(
                            CncOperation("op_df_${dIdx}_h", CncOperationType.HANDLE_BORE, "Handle Holes 160mm CC (Ø4.5mm)", diameterMm = 4.5f, depthMm = t)
                        ),
                        explosiveOffset = Vector3D(x = 0f, y = 0f, z = -300f - (dIdx * 60f))
                    )
                )

                // Drawer Internal Box
                val boxSideT = 15f
                val boxBottomT = 6f
                val boxInnerW = frontW - (2 * params.drawerClearanceMm)
                val boxInnerH = frontH - 40f

                list.add(
                    FurnitureComponent(
                        id = "comp_drawer_box_l_$dIdx",
                        name = "Drawer Box Left Side 0$dIdx",
                        group = ComponentGroup.DRAWERS,
                        role = ComponentRole.DRAWER_BOX_SIDE_L,
                        dimensions = Dimension3D(width = boxSideT, height = boxInnerH, depth = slideLen),
                        position = Vector3D(x = drawerBayStartX + params.drawerClearanceMm, y = dY + 20f, z = 0f),
                        materialId = "mat_birch_plywood",
                        edgeTreatment = EdgeTreatment(top = EdgeBandingType.WOOD_VENEER_0_6MM),
                        explosiveOffset = Vector3D(x = -80f, y = 0f, z = -250f - (dIdx * 50f))
                    )
                )

                list.add(
                    FurnitureComponent(
                        id = "comp_drawer_box_r_$dIdx",
                        name = "Drawer Box Right Side 0$dIdx",
                        group = ComponentGroup.DRAWERS,
                        role = ComponentRole.DRAWER_BOX_SIDE_R,
                        dimensions = Dimension3D(width = boxSideT, height = boxInnerH, depth = slideLen),
                        position = Vector3D(x = drawerBayStartX + params.drawerClearanceMm + boxInnerW - boxSideT, y = dY + 20f, z = 0f),
                        materialId = "mat_birch_plywood",
                        edgeTreatment = EdgeTreatment(top = EdgeBandingType.WOOD_VENEER_0_6MM),
                        explosiveOffset = Vector3D(x = 80f, y = 0f, z = -250f - (dIdx * 50f))
                    )
                )
            }
        }

        // 10. DOORS
        val doorCount = params.doorCount
        if (params.hasDoors && doorCount > 0) {
            val totalDoorOpeningW = w - (2 * params.doorGapMm)
            val doorW = (totalDoorOpeningW / doorCount) - params.doorGapMm
            val doorH = carcassH - (2 * params.doorGapMm)
            val doorY = toeKick + params.doorGapMm

            for (doorIdx in 1..doorCount) {
                val doorX = params.doorGapMm + ((doorIdx - 1) * (doorW + params.doorGapMm))
                val isLeft = doorIdx % 2 != 0

                list.add(
                    FurnitureComponent(
                        id = "comp_door_$doorIdx",
                        name = if (doorCount == 1) "Single Facade Door" else if (isLeft) "Left Facade Door 0$doorIdx" else "Right Facade Door 0$doorIdx",
                        group = ComponentGroup.FACADES,
                        role = if (doorCount == 1) ComponentRole.DOOR_SINGLE else if (isLeft) ComponentRole.DOOR_LEFT else ComponentRole.DOOR_RIGHT,
                        dimensions = Dimension3D(width = doorW, height = doorH, depth = t),
                        position = Vector3D(x = doorX, y = doorY, z = -t),
                        materialId = matId,
                        edgeTreatment = EdgeTreatment(
                            top = EdgeBandingType.ABS_2MM,
                            bottom = EdgeBandingType.ABS_2MM,
                            left = EdgeBandingType.ABS_2MM,
                            right = EdgeBandingType.ABS_2MM
                        ),
                        operations = listOf(
                            CncOperation("op_dr_${doorIdx}_cup1", CncOperationType.HINGE_CUP_35MM, "Concealed Hinge Cup (Ø35×12.5mm @ 22.5mm setback)", diameterMm = 35f, depthMm = 12.5f, xMm = 22.5f, yMm = 100f),
                            CncOperation("op_dr_${doorIdx}_cup2", CncOperationType.HINGE_CUP_35MM, "Concealed Hinge Cup (Ø35×12.5mm @ 22.5mm setback)", diameterMm = 35f, depthMm = 12.5f, xMm = 22.5f, yMm = doorH / 2f),
                            CncOperation("op_dr_${doorIdx}_cup3", CncOperationType.HINGE_CUP_35MM, "Concealed Hinge Cup (Ø35×12.5mm @ 22.5mm setback)", diameterMm = 35f, depthMm = 12.5f, xMm = 22.5f, yMm = doorH - 100f)
                        ),
                        explosiveOffset = Vector3D(
                            x = if (isLeft) -250f else 250f,
                            y = 0f,
                            z = -450f
                        )
                    )
                )
            }
        }

        return list
    }

    private fun generateHardware(params: FurnitureParameters, components: List<FurnitureComponent>): List<HardwareItem> {
        val hingeCount = params.doorCount * (if (params.heightMm > 1600f) 4 else 3)
        val drawerCount = if (params.hasDrawers) params.drawerCount else 0
        val shelfCount = params.shelfCount
        val camCount = 16 + (params.dividerCount * 8) + (shelfCount * 4)
        val dowelCount = 24 + (params.dividerCount * 12) + (shelfCount * 4)

        return HardwareCatalog.getDefaultForWardrobe(
            hingeCount = hingeCount,
            drawerCount = drawerCount,
            shelfCount = shelfCount
        ).map { item ->
            when (item.category) {
                HardwareCategory.HINGES -> item.copy(quantity = hingeCount)
                HardwareCategory.DRAWER_SLIDES -> item.copy(quantity = drawerCount)
                HardwareCategory.CAM_LOCKS_DOWELS -> {
                    if (item.id == "hw_cam_lock_dowel") item.copy(quantity = camCount)
                    else item.copy(quantity = dowelCount)
                }
                HardwareCategory.SHELF_PINS -> item.copy(quantity = shelfCount * 4)
                HardwareCategory.HANDLES_KNOBS -> item.copy(quantity = params.doorCount + drawerCount)
                else -> item
            }
        }
    }

    private fun generateBom(
        components: List<FurnitureComponent>,
        hardware: List<HardwareItem>,
        params: FurnitureParameters
    ): List<BomItem> {
        val list = mutableListOf<BomItem>()
        var partNum = 1

        components.groupBy { "${it.name}_${it.dimensions.formatted()}_${it.materialId}" }.forEach { (_, group) ->
            val sample = group.first()
            val qty = group.size
            val mat = MaterialLibrary.findById(sample.materialId)
            val areaM2 = (sample.dimensions.width / 1000f) * (sample.dimensions.height / 1000f) * qty
            val edgeM = ((sample.dimensions.width + sample.dimensions.height) * 2f / 1000f) * qty
            val unitCost = ((sample.dimensions.width / 1000f) * (sample.dimensions.height / 1000f) * mat.costPerM2) + 4.50f
            val totalCost = unitCost * qty

            list.add(
                BomItem(
                    partNumber = "P-${partNum.toString().padStart(3, '0')}",
                    name = sample.name,
                    category = sample.group.name,
                    quantity = qty,
                    materialName = mat.name,
                    dimensions = "${sample.dimensions.width.toInt()} × ${sample.dimensions.height.toInt()}",
                    thicknessMm = sample.dimensions.depth,
                    areaM2 = areaM2,
                    edgeBandingM = edgeM,
                    unitCost = unitCost,
                    totalCost = totalCost
                )
            )
            partNum++
        }

        hardware.forEach { hw ->
            list.add(
                BomItem(
                    partNumber = "HW-${hw.code}",
                    name = hw.name,
                    category = "HARDWARE",
                    quantity = hw.quantity,
                    materialName = hw.mountingType,
                    dimensions = hw.specs,
                    thicknessMm = 0f,
                    areaM2 = 0f,
                    edgeBandingM = 0f,
                    unitCost = hw.unitCost,
                    totalCost = hw.unitCost * hw.quantity
                )
            )
        }

        return list
    }

    private fun generateCutList(components: List<FurnitureComponent>): List<CutListItem> {
        val list = mutableListOf<CutListItem>()
        var partSeq = 1

        components.forEach { comp ->
            val mat = MaterialLibrary.findById(comp.materialId)
            val (length, width) = if (comp.dimensions.height >= comp.dimensions.width) {
                comp.dimensions.height to comp.dimensions.width
            } else {
                comp.dimensions.width to comp.dimensions.height
            }

            list.add(
                CutListItem(
                    partNumber = "CUT-${partSeq.toString().padStart(3, '0')}",
                    componentId = comp.id,
                    name = comp.name,
                    quantity = 1,
                    lengthMm = length,
                    widthMm = width,
                    thicknessMm = comp.dimensions.depth,
                    materialName = mat.name,
                    edgeTreatment = comp.edgeTreatment.summary(),
                    grainDirection = mat.grainDirection,
                    cncOperationsCount = comp.operations.size,
                    sheetAssignment = "Sheet ${(partSeq - 1) / 4 + 1}"
                )
            )
            partSeq++
        }
        return list.sortedByDescending { it.lengthMm * it.widthMm }
    }

    private fun calculateNesting(cutList: List<CutListItem>): List<NestingSheet> {
        val sheets = mutableListOf<NestingSheet>()
        val sheetW = 2440f
        val sheetH = 1220f
        val margin = 15f
        val sawKerf = 4f

        val groupsByMat = cutList.groupBy { "${it.materialName}_${it.thicknessMm}" }

        var sheetCounter = 1
        groupsByMat.forEach { (matKey, items) ->
            val matName = items.first().materialName
            val thick = items.first().thicknessMm

            var currentX = margin
            var currentY = margin
            var rowMaxH = 0f
            var placedList = mutableListOf<PlacedPanel>()
            var sheetUsedArea = 0f

            items.forEach { item ->
                var partW = item.widthMm
                var partH = item.lengthMm
                var rotated = false

                if (currentX + partW + margin > sheetW) {
                    // Try rotating if grain allows
                    if (item.grainDirection == GrainDirection.NONE && currentX + partH + margin <= sheetW) {
                        val temp = partW
                        partW = partH
                        partH = temp
                        rotated = true
                    } else {
                        // Move to next row
                        currentX = margin
                        currentY += rowMaxH + sawKerf
                        rowMaxH = 0f
                    }
                }

                // Check if fits on current sheet
                if (currentY + partH + margin > sheetH) {
                    // Finalize current sheet
                    val totalSheetArea = (sheetW / 1000f) * (sheetH / 1000f)
                    val waste = max(0f, (1f - (sheetUsedArea / totalSheetArea)) * 100f)
                    sheets.add(
                        NestingSheet(
                            sheetIndex = sheetCounter++,
                            materialName = matName,
                            sheetWidthMm = sheetW,
                            sheetHeightMm = sheetH,
                            thicknessMm = thick,
                            placedPanels = placedList,
                            usedAreaM2 = sheetUsedArea,
                            totalAreaM2 = totalSheetArea,
                            wastePercentage = waste
                        )
                    )
                    // Reset for next sheet
                    currentX = margin
                    currentY = margin
                    rowMaxH = 0f
                    placedList = mutableListOf()
                    sheetUsedArea = 0f
                }

                placedList.add(
                    PlacedPanel(
                        cutListItem = item,
                        x = currentX,
                        y = currentY,
                        width = partW,
                        height = partH,
                        isRotated = rotated
                    )
                )

                sheetUsedArea += (partW / 1000f) * (partH / 1000f)
                rowMaxH = max(rowMaxH, partH)
                currentX += partW + sawKerf
            }

            if (placedList.isNotEmpty()) {
                val totalSheetArea = (sheetW / 1000f) * (sheetH / 1000f)
                val waste = max(0f, (1f - (sheetUsedArea / totalSheetArea)) * 100f)
                sheets.add(
                    NestingSheet(
                        sheetIndex = sheetCounter++,
                        materialName = matName,
                        sheetWidthMm = sheetW,
                        sheetHeightMm = sheetH,
                        thicknessMm = thick,
                        placedPanels = placedList,
                        usedAreaM2 = sheetUsedArea,
                        totalAreaM2 = totalSheetArea,
                        wastePercentage = waste
                    )
                )
            }
        }

        return sheets
    }

    private fun generateAssemblySteps(
        components: List<FurnitureComponent>,
        hardware: List<HardwareItem>,
        params: FurnitureParameters
    ): List<AssemblyStep> {
        val steps = mutableListOf<AssemblyStep>()
        var stepNo = 1

        steps.add(
            AssemblyStep(
                stepNumber = stepNo++,
                totalSteps = 6,
                title = "Stage 1: Carcass Base & Levelers Pre-assembly",
                description = "Insert 8×30mm fluted dowels and screw Cam dowel pins into pre-bored pilot holes of the Bottom Panel. Fasten adjustable leveling feet to the underside.",
                involvedComponentIds = listOf("comp_bottom", "comp_plinth_front"),
                hardwareRequired = listOf("8× Wooden Dowels 8×30mm", "4× Cam Dowels TL5", "4× Adjustable Feet"),
                toolsRequired = listOf("Rubber Mallet", "PZ2 Screwdriver"),
                estimatedMinutes = 15,
                explosionHighlightVector = Vector3D(0f, -100f, 0f),
                tip = "Ensure dowels are seated firmly to 20mm depth without excessive mallet force."
            )
        )

        steps.add(
            AssemblyStep(
                stepNumber = stepNo++,
                totalSteps = 6,
                title = "Stage 2: Left & Right Structural Sides Attachment",
                description = "Align Left and Right side panels over the base dowels and cam pins. Rotate cam locks 180° clockwise until fully engaged and flush.",
                involvedComponentIds = listOf("comp_side_left", "comp_side_right", "comp_bottom"),
                hardwareRequired = listOf("8× Cam Locks Ø15mm", "8× Confirmat Screws 7×50mm"),
                toolsRequired = listOf("SW4 Hex Key / Bit", "Flathead Screwdriver"),
                estimatedMinutes = 20,
                explosionHighlightVector = Vector3D(100f, 0f, 0f),
                tip = "Check cabinet squareness diagonally (corner to corner) before final tightening."
            )
        )

        steps.add(
            AssemblyStep(
                stepNumber = stepNo++,
                totalSteps = 6,
                title = "Stage 3: Crown Top Panel & Vertical Dividers",
                description = "Position internal vertical dividers into locator pins, then lower the Top Crown Panel onto the carcass uprights and lock cam assemblies.",
                involvedComponentIds = listOf("comp_top", "comp_divider_1", "comp_divider_2"),
                hardwareRequired = listOf("8× Cam Locks Ø15mm", "12× Wooden Dowels"),
                toolsRequired = listOf("PZ2 Screwdriver", "SW4 Hex Key"),
                estimatedMinutes = 15,
                explosionHighlightVector = Vector3D(0f, 150f, 0f),
                tip = "Ensure 32mm system boring rows on dividers face the correct shelf compartment."
            )
        )

        if (params.hasBackPanel) {
            steps.add(
                AssemblyStep(
                    stepNumber = stepNo++,
                    totalSteps = 6,
                    title = "Stage 4: Rear Back Panel Rabbet Insertion",
                    description = "Slide the 6mm melamine back panel down into the carcass grooves or tack securely with 3×20mm backboard screws at 150mm centers.",
                    involvedComponentIds = listOf("comp_back"),
                    hardwareRequired = listOf("24× Backboard Screws 3×20mm"),
                    toolsRequired = listOf("Cordless Drill / PZ1 Bit"),
                    estimatedMinutes = 10,
                    explosionHighlightVector = Vector3D(0f, 0f, 200f),
                    tip = "The back panel guarantees structural racking rigidity; ensure cabinet is completely square."
                )
            )
        }

        if (params.shelfCount > 0 || params.hasDrawers) {
            steps.add(
                AssemblyStep(
                    stepNumber = stepNo++,
                    totalSteps = 6,
                    title = "Stage 5: Interior Shelving & Drawer Runner Installation",
                    description = "Insert steel anti-tilt shelf studs into desired 32mm system holes. Fasten Dynapro undermount drawer runners to carcass sides with Ø3.5×15mm screws.",
                    involvedComponentIds = listOf("comp_shelf_1", "comp_shelf_2", "comp_shelf_3", "comp_drawer_box_l_1"),
                    hardwareRequired = listOf("${params.shelfCount * 4}× Shelf Pins Ø5mm", "${params.drawerCount}× Runner Pairs 450mm"),
                    toolsRequired = listOf("PZ2 Screwdriver"),
                    estimatedMinutes = 25,
                    explosionHighlightVector = Vector3D(0f, 50f, -100f),
                    tip = "Mount runners using the 3rd hole in the system 32 line for correct 37mm setback."
                )
            )
        }

        if (params.hasDoors || params.hasDrawers) {
            steps.add(
                AssemblyStep(
                    stepNumber = stepNo++,
                    totalSteps = 6,
                    title = "Stage 6: Facades, Concealed Hinges & Handle Fitting",
                    description = "Clip Blum 110° hinge arms into mounting plates. Adjust 3D alignment screws for uniform 2.5mm door reveals. Fasten architectural bar pulls.",
                    involvedComponentIds = listOf("comp_door_1", "comp_door_2", "comp_drawer_front_1"),
                    hardwareRequired = listOf("6× Blum Clip Top Hinges", "5× Bar Pulls 160mm + M4 Screws"),
                    toolsRequired = listOf("PZ2 Screwdriver"),
                    estimatedMinutes = 20,
                    explosionHighlightVector = Vector3D(0f, 0f, -200f),
                    tip = "Use side and depth adjustment screws on hinge arm to calibrate perfectly even shadow gaps."
                )
            )
        }

        return steps
    }

    private fun validateDesign(
        params: FurnitureParameters,
        components: List<FurnitureComponent>,
        hardware: List<HardwareItem>
    ): List<DesignWarning> {
        val warnings = mutableListOf<DesignWarning>()

        // 1. Shelf span deflection check (Sagulator / DIN 68874 standard)
        val numDividers = params.dividerCount
        val internalW = params.widthMm - (2 * params.panelThicknessMm)
        val bayWidth = (internalW - (numDividers * params.panelThicknessMm)) / (numDividers + 1)
        if (bayWidth > 900f && params.panelThicknessMm < 22f) {
            warnings.add(
                DesignWarning(
                    id = "warn_shelf_span",
                    severity = WarningSeverity.WARNING,
                    title = "Shelf Span Exceeds Deflection Limit",
                    message = "Bay width (${bayWidth.toInt()}mm) with ${params.panelThicknessMm.toInt()}mm panel will deflect under standard 25kg load. Consider adding a central divider or upgrading to 22mm / 25mm thickness.",
                    componentId = "comp_shelf_1",
                    canAutoFix = true,
                    fixActionTitle = "Add Vertical Divider"
                )
            )
        }

        // 2. Cabinet Depth vs Drawer Runner matching check
        if (params.hasDrawers && params.drawerCount > 0) {
            val internalD = params.depthMm - params.backPanelInsetMm - params.backPanelThicknessMm
            if (internalD < 350f) {
                warnings.add(
                    DesignWarning(
                        id = "warn_drawer_depth",
                        severity = WarningSeverity.ERROR,
                        title = "Cabinet Depth Inadequate for Standard Slides",
                        message = "Internal depth (${internalD.toInt()}mm) is too shallow for commercial undermount slides (minimum 350mm required).",
                        componentId = "comp_drawer_front_1"
                    )
                )
            }
        }

        // 3. Aspect Ratio / Anti-Tip Tip-Over check (ASTM F2057 safety)
        if (params.heightMm > 1400f && params.depthMm < 400f) {
            warnings.add(
                DesignWarning(
                    id = "warn_anti_tip",
                    severity = WarningSeverity.WARNING,
                    title = "Anti-Tip Wall Bracket Required (ASTM F2057)",
                    message = "Height (${params.heightMm.toInt()}mm) to Depth (${params.depthMm.toInt()}mm) ratio exceeds 3.5:1. Mandatory wall anchoring bracket hardware must be packaged.",
                    canAutoFix = false
                )
            )
        }

        // 4. Door width / hinge count check
        val doorW = if (params.doorCount > 0) params.widthMm / params.doorCount else 0f
        if (doorW > 600f) {
            warnings.add(
                DesignWarning(
                    id = "warn_door_width",
                    severity = WarningSeverity.WARNING,
                    title = "Door Leaf Exceeds 600mm Standard Width",
                    message = "Door width (${doorW.toInt()}mm) creates heavy lever moment on hinges. Recommend splitting into twin doors or adding heavy-duty hinges.",
                    componentId = "comp_door_1"
                )
            )
        }

        // 5. Positive feasibility pass
        if (warnings.none { it.severity == WarningSeverity.ERROR }) {
            warnings.add(
                DesignWarning(
                    id = "info_drc_pass",
                    severity = WarningSeverity.INFO,
                    title = "Design Rule Check Passed (CNC Ready)",
                    message = "All joinery bore centers, 32mm system rows, and panel clearances comply with automated CNC manufacturing tolerances."
                )
            )
        }

        return warnings
    }
}
