'use client';

import React, { useState, useCallback, useMemo } from 'react';
import {
  CameraPreset,
  FurnitureComponent,
  FurnitureProject,
  ParametricConfig,
  ShadingMode,
  UnitSystem,
  ViewportMode,
} from '@/types/furniture';
import { generateParametricComponents } from '@/lib/parametric-engine';
import { CadHeader } from '@/components/header/CadHeader';
import { ComponentTree } from '@/components/tree/ComponentTree';
import { CadViewport } from '@/components/viewport/CadViewport';
import { Technical2DDrawing } from '@/components/viewport/Technical2DDrawing';
import { PropertyInspector } from '@/components/properties/PropertyInspector';
import { BottomDock } from '@/components/dock/BottomDock';
import { HelpModal } from '@/components/modals/HelpModal';
import { exportProjectToJSON } from '@/lib/export-engine';

// Initial Project Definition
const INITIAL_CONFIG: ParametricConfig = {
  width: 2400,
  height: 2200,
  depth: 600,
  carcassThickness: 18,
  backPanelThickness: 6,
  backPanelGrooveDepth: 8,
  backPanelInset: 20,
  plinthHeight: 100,
  plinthSetback: 20,
  jointType: 'cam_lock_dowel',
  defaultCarcassMaterialId: 'mat_oak_natural',
  defaultFrontMaterialId: 'mat_oak_natural',
  defaultBackMaterialId: 'mat_hdf_white',
  baysCount: 3,
  shelvesPerBay: [3, 4, 3],
  shelfSpacingMode: 'equal',
  shelfSetback: 15,
  hasDoors: true,
  doorType: 'slab',
  doorBays: [0, 1, 2],
  doorGap: 2.5,
  doorOpeningAngle: 25,
  hasDrawers: true,
  drawerBays: [0],
  drawersCount: 3,
  drawerClearance: 12.5,
  drawerHeightMm: 180,
  drawerSlideType: 'undermount_soft_close',
};

const initialGen = generateParametricComponents(INITIAL_CONFIG);

const INITIAL_PROJECT: FurnitureProject = {
  id: 'proj_wardrobe_master_001',
  name: 'Parametric Wardrobe System 2400',
  description: 'High-precision modular master wardrobe with 3 bays, interior drawers and adjustable shelving',
  version: '1.0',
  category: 'wardrobe',
  createdAt: '2026-09-06T00:00:00.000Z',
  updatedAt: new Date().toISOString(),
  config: INITIAL_CONFIG,
  components: initialGen.components,
  hardwareItems: initialGen.hardware,
  unitSystem: 'mm',
  variants: [
    {
      id: 'var_standard_oak',
      name: 'Standard 2400 Master (Natural Oak)',
      description: '3-Bay Master Wardrobe with Integrated Drawers',
      configOverrides: {
        width: 2400,
        height: 2200,
        depth: 600,
        baysCount: 3,
        hasDoors: true,
        hasDrawers: true,
        defaultCarcassMaterialId: 'mat_oak_natural',
      },
    },
    {
      id: 'var_compact_white',
      name: 'Compact 1600 Double (Melamine White)',
      description: '2-Bay Minimalist Space-saving System',
      configOverrides: {
        width: 1600,
        height: 2000,
        depth: 550,
        baysCount: 2,
        hasDoors: true,
        hasDrawers: false,
        defaultCarcassMaterialId: 'mat_melamine_white',
      },
    },
    {
      id: 'var_grand_walnut',
      name: 'Grand 3200 Architectural (Walnut)',
      description: '4-Bay Luxury Executive Dressing Suite',
      configOverrides: {
        width: 3200,
        height: 2400,
        depth: 650,
        baysCount: 3,
        hasDoors: false,
        hasDrawers: true,
        defaultCarcassMaterialId: 'mat_walnut_american',
      },
    },
  ],
  activeVariantId: 'var_standard_oak',
};

export default function FlatformProCADPage() {
  // Main Project State
  const [project, setProject] = useState<FurnitureProject>(INITIAL_PROJECT);
  const [history, setHistory] = useState<FurnitureProject[]>([INITIAL_PROJECT]);
  const [historyIndex, setHistoryIndex] = useState(0);

  // Viewport / Selection States
  const [selectedComponentId, setSelectedComponentId] = useState<string | null>(null);
  const [hoveredComponentId, setHoveredComponentId] = useState<string | null>(null);
  const [viewportMode, setViewportMode] = useState<ViewportMode>('3d');
  const [shadingMode, setShadingMode] = useState<ShadingMode>('materials');
  const [explodedDistance, setExplodedDistance] = useState(0);
  const [cameraPreset, setCameraPreset] = useState<CameraPreset>('perspective');
  const [showGrid, setShowGrid] = useState(true);
  const [showHardware, setShowHardware] = useState(true);
  const [showDimensions, setShowDimensions] = useState(true);

  // Workflow states
  const [activeAssemblyStep, setActiveAssemblyStep] = useState(1);
  const [isHelpOpen, setIsHelpOpen] = useState(false);

  // Push State to Undo / Redo History
  const pushState = useCallback(
    (newProject: FurnitureProject) => {
      const newHistory = history.slice(0, historyIndex + 1);
      newHistory.push(newProject);
      setHistory(newHistory);
      setHistoryIndex(newHistory.length - 1);
      setProject(newProject);
    },
    [history, historyIndex]
  );

  // Handle Parametric Configuration Update (Live Recalculation Engine)
  const handleUpdateConfig = useCallback(
    (configDelta: Partial<ParametricConfig>) => {
      setProject((currentProject) => {
        const updatedConfig: ParametricConfig = {
          ...currentProject.config,
          ...configDelta,
        };

        // Recalculate component geometry, joinery, and hardware
        const generated = generateParametricComponents(updatedConfig);

        const updatedProject: FurnitureProject = {
          ...currentProject,
          version: (parseFloat(currentProject.version || '1.0') + 0.1).toFixed(1),
          updatedAt: new Date().toISOString(),
          config: updatedConfig,
          components: generated.components,
          hardwareItems: generated.hardware,
        };

        // Push to undo stack
        const newHistory = history.slice(0, historyIndex + 1);
        newHistory.push(updatedProject);
        setHistory(newHistory);
        setHistoryIndex(newHistory.length - 1);

        return updatedProject;
      });
    },
    [history, historyIndex]
  );

  // Handle Direct Component Editing
  const handleUpdateComponent = useCallback(
    (updatedComp: FurnitureComponent) => {
      setProject((curr) => {
        const updatedComponents = curr.components.map((c) =>
          c.id === updatedComp.id ? updatedComp : c
        );
        const updatedProject: FurnitureProject = {
          ...curr,
          version: (parseFloat(curr.version || '1.0') + 0.1).toFixed(1),
          updatedAt: new Date().toISOString(),
          components: updatedComponents,
        };
        pushState(updatedProject);
        return updatedProject;
      });
    },
    [pushState]
  );

  // Toggle Component Visibility (Eye)
  const handleToggleVisibility = useCallback((componentId: string) => {
    setProject((curr) => ({
      ...curr,
      components: curr.components.map((c) =>
        c.id === componentId ? { ...c, visible: !c.visible } : c
      ),
    }));
  }, []);

  // Toggle Component Lock
  const handleToggleLock = useCallback((componentId: string) => {
    setProject((curr) => ({
      ...curr,
      components: curr.components.map((c) =>
        c.id === componentId ? { ...c, locked: !c.locked } : c
      ),
    }));
  }, []);

  // Apply Design Variant Preset
  const handleApplyVariant = useCallback(
    (variantId: string) => {
      const variant = project.variants.find((v) => v.id === variantId);
      if (!variant) return;

      const updatedConfig: ParametricConfig = {
        ...project.config,
        ...variant.configOverrides,
      };

      const generated = generateParametricComponents(updatedConfig);

      const updatedProject: FurnitureProject = {
        ...project,
        activeVariantId: variantId,
        version: (parseFloat(project.version || '1.0') + 0.1).toFixed(1),
        config: updatedConfig,
        components: generated.components,
        hardwareItems: generated.hardware,
      };

      pushState(updatedProject);
    },
    [project, pushState]
  );

  // Quick Action: Add Shelf
  const handleAddShelf = useCallback(() => {
    const currShelves = [...project.config.shelvesPerBay];
    if (currShelves.length > 0) {
      currShelves[0] = Math.min(10, currShelves[0] + 1);
      handleUpdateConfig({ shelvesPerBay: currShelves });
    }
  }, [project.config.shelvesPerBay, handleUpdateConfig]);

  // Quick Action: Toggle / Add Doors
  const handleAddDoor = useCallback(() => {
    handleUpdateConfig({ hasDoors: !project.config.hasDoors });
  }, [project.config.hasDoors, handleUpdateConfig]);

  // Quick Action: Add Drawer
  const handleAddDrawer = useCallback(() => {
    if (!project.config.hasDrawers) {
      handleUpdateConfig({ hasDrawers: true, drawersCount: 2 });
    } else {
      handleUpdateConfig({
        drawersCount: Math.min(6, (project.config.drawersCount || 2) + 1),
      });
    }
  }, [project.config.hasDrawers, project.config.drawersCount, handleUpdateConfig]);

  // Undo / Redo actions
  const handleUndo = useCallback(() => {
    if (historyIndex > 0) {
      const prevIdx = historyIndex - 1;
      setHistoryIndex(prevIdx);
      setProject(history[prevIdx]);
    }
  }, [history, historyIndex]);

  const handleRedo = useCallback(() => {
    if (historyIndex < history.length - 1) {
      const nextIdx = historyIndex + 1;
      setHistoryIndex(nextIdx);
      setProject(history[nextIdx]);
    }
  }, [history, historyIndex]);

  // Currently Selected Component Object
  const selectedComponent = useMemo(
    () => project.components.find((c) => c.id === selectedComponentId) || null,
    [project.components, selectedComponentId]
  );

  return (
    <div id="flatform_pro_application_root" className="w-screen h-screen flex flex-col bg-[#0F0F11] text-[#E0E0E0] overflow-hidden font-sans antialiased select-none">
      {/* 1. TOP CAD APPLICATION HEADER */}
      <CadHeader
        project={project}
        onUpdateProjectName={(name) =>
          setProject((curr) => ({ ...curr, name }))
        }
        viewportMode={viewportMode}
        onToggleViewportMode={setViewportMode}
        unitSystem={project.unitSystem}
        onToggleUnitSystem={(unitSystem) =>
          setProject((curr) => ({ ...curr, unitSystem }))
        }
        onNewProject={() => {
          setProject(INITIAL_PROJECT);
          setHistory([INITIAL_PROJECT]);
          setHistoryIndex(0);
        }}
        onSaveProject={() => exportProjectToJSON(project)}
        canUndo={historyIndex > 0}
        canRedo={historyIndex < history.length - 1}
        onUndo={handleUndo}
        onRedo={handleRedo}
        showGrid={showGrid}
        onToggleGrid={() => setShowGrid(!showGrid)}
        showHardware={showHardware}
        onToggleHardware={() => setShowHardware(!showHardware)}
        onOpenHelpModal={() => setIsHelpOpen(true)}
      />

      {/* 2. MIDDLE WORKSTATION AREA: Left Tree | Center Viewport | Right Inspector */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Left Component Tree */}
        <ComponentTree
          project={project}
          selectedComponentId={selectedComponentId}
          onSelectComponent={setSelectedComponentId}
          hoveredComponentId={hoveredComponentId}
          onHoverComponent={setHoveredComponentId}
          onToggleVisibility={handleToggleVisibility}
          onToggleLock={handleToggleLock}
          onAddShelf={handleAddShelf}
          onAddDoor={handleAddDoor}
          onAddDrawer={handleAddDrawer}
        />

        {/* Center Viewport Stage (3D / 2D / Split) */}
        <div className="flex-1 h-full relative overflow-hidden flex bg-black">
          {/* 3D WebGL CAD Viewport */}
          {(viewportMode === '3d' || viewportMode === 'split') && (
            <div className={`h-full ${viewportMode === 'split' ? 'w-1/2 border-r border-[#2C2E33]' : 'w-full'}`}>
              <CadViewport
                components={project.components}
                hardwareItems={project.hardwareItems}
                selectedComponentId={selectedComponentId}
                onSelectComponent={setSelectedComponentId}
                hoveredComponentId={hoveredComponentId}
                onHoverComponent={setHoveredComponentId}
                shadingMode={shadingMode}
                onShadingModeChange={setShadingMode}
                explodedDistance={explodedDistance}
                cameraPreset={cameraPreset}
                onCameraPresetChange={setCameraPreset}
                unitSystem={project.unitSystem}
                showDimensions={showDimensions}
                showGrid={showGrid}
                showHardware={showHardware}
              />
            </div>
          )}

          {/* 2D Engineering Orthographic Drawing Viewport */}
          {(viewportMode === '2d_drawing' || viewportMode === 'split') && (
            <div className={`h-full ${viewportMode === 'split' ? 'w-1/2' : 'w-full'}`}>
              <Technical2DDrawing
                project={project}
                selectedComponentId={selectedComponentId}
                onSelectComponent={setSelectedComponentId}
              />
            </div>
          )}
        </div>

        {/* Right Property Inspector & Parametric Configurator */}
        <PropertyInspector
          project={project}
          onUpdateConfig={handleUpdateConfig}
          selectedComponent={selectedComponent}
          onUpdateComponent={handleUpdateComponent}
          onApplyVariant={handleApplyVariant}
        />
      </div>

      {/* 3. BOTTOM ENGINEERING DOCK (BOM, Cut List, Nesting, Assembly, DRC, Kotlin Code) */}
      <BottomDock
        project={project}
        selectedComponentId={selectedComponentId}
        onSelectComponent={setSelectedComponentId}
        activeAssemblyStep={activeAssemblyStep}
        onSelectAssemblyStep={setActiveAssemblyStep}
      />

      {/* 4. HELP / KEYBOARD SHORTCUTS MODAL */}
      <HelpModal isOpen={isHelpOpen} onClose={() => setIsHelpOpen(false)} />
    </div>
  );
}
