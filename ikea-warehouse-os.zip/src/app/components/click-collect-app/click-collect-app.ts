import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { WarehouseStateEngine } from '../../core/services/warehouse-state.service';

@Component({
  selector: 'app-click-collect-app',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 bg-[#F4F4F4] min-h-screen text-slate-900 space-y-6">
      
      <div class="bg-white border border-slate-300 p-5 rounded-lg shadow-sm flex items-center justify-between">
        <div>
          <span class="bg-[#FFDA1A] text-black font-extrabold text-xs px-2.5 py-0.5 rounded uppercase">STORE & DRIVE-THRU PICKUP</span>
          <h2 class="text-2xl font-black text-slate-900 uppercase mt-1">CLICK & COLLECT WORKER APPLICATION</h2>
          <p class="text-xs text-slate-600">Customer Check-in Scanner • Staging Location Retrieval • Vehicle Handover</p>
        </div>

        <span class="bg-emerald-100 text-emerald-800 font-extrabold text-xs px-3 py-1.5 rounded">
          Bay 02 Active Arrival
        </span>
      </div>

      <!-- Active Click & Collect Queue -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        @for (coll of state.collectionOrders(); track coll.collectionId) {
          <div class="bg-white border-2 border-[#0058A3] rounded-lg p-5 shadow-sm space-y-4">
            
            <div class="flex items-center justify-between border-b border-slate-200 pb-3">
              <div>
                <span class="text-xs font-mono font-bold text-[#0058A3]">{{ coll.orderId }} • {{ coll.collectionId }}</span>
                <h3 class="font-extrabold text-slate-900 text-lg mt-0.5">{{ coll.customerName }}</h3>
              </div>
              <span class="bg-[#FFDA1A] text-black font-extrabold text-xs px-3 py-1 rounded shadow">
                {{ coll.bayId }}
              </span>
            </div>

            <div class="grid grid-cols-2 gap-3 text-xs font-mono">
              <div class="bg-slate-50 p-2.5 rounded border border-slate-200">
                <span class="text-slate-500 block text-[10px]">Vehicle License</span>
                <span class="font-bold text-slate-900 text-sm">{{ coll.vehicleLicensePlate || 'Walk-In' }}</span>
              </div>
              <div class="bg-slate-50 p-2.5 rounded border border-slate-200">
                <span class="text-slate-500 block text-[10px]">Slot Time</span>
                <span class="font-bold text-blue-800 text-sm">{{ coll.slotTime }}</span>
              </div>
            </div>

            <!-- Staging Locations & QR Code Verification -->
            <div class="bg-blue-50/60 border border-blue-200 p-3 rounded-lg space-y-2 text-xs">
              <div class="flex items-center justify-between font-bold text-slate-900">
                <span>Staged Packages ({{ coll.packagesCount }} Pkgs)</span>
                <span class="text-[#0058A3] font-mono">STG-03 / STG-04</span>
              </div>
              <p class="text-[11px] text-slate-600">Scan Customer QR Code or enter Code <span class="font-mono font-bold text-slate-900">QR-100042-SWEDEN</span> to verify handover.</p>
            </div>

            <button (click)="completeHandover(coll.collectionId)" 
                    class="w-full bg-[#0058A3] hover:bg-blue-900 text-white font-extrabold text-xs py-3 rounded shadow flex items-center justify-center gap-2 uppercase">
              <mat-icon>check_circle</mat-icon>
              VERIFY QR CODE & CONFIRM VEHICLE HANDOVER
            </button>

          </div>
        }
      </div>

    </div>
  `
})
export class ClickCollectAppComponent {
  readonly state = inject(WarehouseStateEngine);

  completeHandover(collectionId: string) {
    this.state.orders.update(list => list.map(o => o.orderId === 'ORD-100042' ? { ...o, status: 'COMPLETED' } : o));
    alert(`Click & Collect Handover for ${collectionId} confirmed successfully! Inventory ledger updated.`);
  }
}
