import { Component, ChangeDetectionStrategy, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent, ActiveAppView } from './components/header/header';
import { ControlCentreComponent } from './components/control-centre/control-centre';
import { DigitalTwinComponent } from './components/digital-twin/digital-twin';
import { PickerAppComponent } from './components/picker-app/picker-app';
import { ReceivingAppComponent } from './components/receiving-app/receiving-app';
import { DispatchAppComponent } from './components/dispatch-app/dispatch-app';
import { ClickCollectAppComponent } from './components/click-collect-app/click-collect-app';
import { InventoryAppComponent } from './components/inventory-app/inventory-app';
import { LogisticsTowerComponent } from './components/logistics-tower/logistics-tower';
import { CustomerViewComponent } from './components/customer-view/customer-view';
import { AiScenarioStudioComponent } from './components/ai-scenario-studio/ai-scenario-studio';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    HeaderComponent,
    ControlCentreComponent,
    DigitalTwinComponent,
    PickerAppComponent,
    ReceivingAppComponent,
    DispatchAppComponent,
    ClickCollectAppComponent,
    InventoryAppComponent,
    LogisticsTowerComponent,
    CustomerViewComponent,
    AiScenarioStudioComponent
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  readonly activeView = signal<ActiveAppView>('CONTROL_CENTRE');

  onViewChange(view: ActiveAppView) {
    this.activeView.set(view);
  }
}
