import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'FLATFORM PRO — Parametric Flat-Pack Furniture Engineering System',
  description: 'Professional CAD workstation, parametric furniture configurator, manufacturing BOM, cut-list optimization and assembly sequence planner.',
  openGraph: {
    title: 'FLATFORM PRO — Parametric Flat-Pack Furniture Engineering System',
    description: 'Professional CAD workstation, parametric furniture configurator, manufacturing BOM, cut-list optimization and assembly sequence planner.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'FLATFORM PRO — Parametric Flat-Pack Furniture Engineering System',
    description: 'Professional CAD workstation, parametric furniture configurator, manufacturing BOM, cut-list optimization and assembly sequence planner.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
