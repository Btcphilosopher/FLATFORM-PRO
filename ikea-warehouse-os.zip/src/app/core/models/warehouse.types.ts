// IKEA WAREHOUSE OS (AUREOM-WMS)
// Canonical Domain Type Definitions

export type ProductDepartment = 'Living Room' | 'Bedroom' | 'Kitchen' | 'Workspace' | 'Storage' | 'Lighting' | 'Textiles';
export type StorageClass = 'PALLET_RACK' | 'HIGH_BAY' | 'FORWARD_PICK' | 'BULK_FLOOR' | 'SMALL_PARTS' | 'HAZARDOUS' | 'COLD_STORAGE';
export type HandlingClass = 'STANDARD' | 'HEAVY_FLATPACK' | 'FRAGILE' | 'LONG_PACKAGE' | 'MULTI_PACKAGE' | 'TEAM_LIFT';

export interface PackageDimension {
  lengthMeters: number;
  widthMeters: number;
  heightMeters: number;
  weightKg: number;
  volumeM3: number;
}

export interface ProductPackage {
  packageId: string;
  packageNumber: number; // e.g. 1 of 3
  totalPackages: number;
  dimensions: PackageDimension;
  barcode: string;
  handlingClass: HandlingClass;
  fragility: boolean;
  stackingLimit: number;
}

export interface Product {
  sku: string; // e.g. BILLY-SYN-001
  articleNumber: string; // e.g. 802.638.32
  productName: string; // e.g. SYNTHETIC-BILLY-BOOKCASE
  category: string;
  department: ProductDepartment;
  packages: ProductPackage[];
  totalWeightKg: number;
  totalVolumeM3: number;
  reorderPoint: number;
  targetStock: number;
  unitPriceSEK: number;
  imageUrl?: string;
}

export interface WarehouseLocation {
  locationId: string; // e.g. DC01-A04-R12-B02
  warehouseId: string;
  zoneId: string;
  zoneType: 'INBOUND_DOCK' | 'RECEIVING_QC' | 'HIGH_BAY' | 'FORWARD_PICK' | 'STAGING' | 'PACKING' | 'OUTBOUND_DOCK' | 'CLICK_COLLECT' | 'RETURNS' | 'QUARANTINE' | 'CHARGING';
  aisle: string;
  rack: number;
  bay: number;
  level: number;
  bin: string;
  x: number;
  y: number;
  z: number;
  widthM: number;
  lengthM: number;
  heightM: number;
  capacityM3: number;
  capacityKg: number;
  currentUtilisationPct: number;
  allowedClasses: StorageClass[];
  isBlocked: boolean;
}

export type InventoryState = 
  | 'ON_HAND'
  | 'AVAILABLE'
  | 'RESERVED'
  | 'ALLOCATED'
  | 'PICKED'
  | 'STAGED'
  | 'LOADED'
  | 'IN_TRANSIT'
  | 'DAMAGED'
  | 'QUARANTINED'
  | 'RETURNED';

export type InventoryEventType = 
  | 'RECEIVED'
  | 'PUTAWAY'
  | 'TRANSFERRED'
  | 'RESERVED'
  | 'ALLOCATED'
  | 'PICKED'
  | 'STAGED'
  | 'LOADED'
  | 'DISPATCHED'
  | 'DELIVERED'
  | 'RETURNED'
  | 'DAMAGED'
  | 'ADJUSTED'
  | 'COUNTED'
  | 'QUARANTINED'
  | 'RELEASED';

export interface InventoryEvent {
  eventId: string;
  timestamp: string;
  sku: string;
  packageId?: string;
  locationId: string;
  quantity: number;
  previousState: InventoryState;
  newState: InventoryState;
  workerId: string;
  deviceId: string;
  orderId?: string;
  reason: string;
  reference: string;
  correlationId: string;
}

export interface InventoryRecord {
  sku: string;
  locationId: string;
  packageId?: string;
  onHand: number;
  available: number;
  reserved: number;
  allocated: number;
  picked: number;
  staged: number;
  damaged: number;
  quarantined: number;
  lastCountedAt: string;
}

export interface AvailableToPromise {
  sku: string;
  physicalStock: number;
  reservedStock: number;
  allocatedStock: number;
  confirmedInbound: number;
  safetyBuffer: number;
  availableToPromise: number; // ATP formula calculation
}

export type OrderStatus = 
  | 'CREATED'
  | 'CONFIRMED'
  | 'ALLOCATING'
  | 'ALLOCATED'
  | 'PICKING'
  | 'PARTIALLY_PICKED'
  | 'PICKED'
  | 'CONSOLIDATING'
  | 'READY'
  | 'COLLECTION_READY'
  | 'LOADED'
  | 'DISPATCHED'
  | 'IN_TRANSIT'
  | 'DELIVERED'
  | 'COLLECTED'
  | 'COMPLETED'
  | 'CANCELLED'
  | 'RETURN_REQUESTED'
  | 'RETURNED';

export interface OrderLine {
  orderLineId: string;
  sku: string;
  productName: string;
  quantityOrdered: number;
  quantityAllocated: number;
  quantityPicked: number;
  unitPriceSEK: number;
}

export interface OrderPackageStatus {
  packageId: string;
  sku: string;
  packageNumber: number;
  totalPackages: number;
  assignedLocationId: string;
  pickedLocationId?: string;
  status: 'PENDING' | 'ALLOCATED' | 'PICKING' | 'PICKED' | 'STAGED' | 'CONSOLIDATED';
  stagingLocationId?: string;
}

export interface Order {
  orderId: string; // e.g. ORD-100042
  customerId: string;
  customerName: string;
  customerPhone: string;
  orderType: 'CLICK_AND_COLLECT' | 'HOME_DELIVERY' | 'EXPRESS_CURBSIDE';
  destinationAddress?: string;
  createdAt: string;
  promisedDeadline: string;
  status: OrderStatus;
  lines: OrderLine[];
  packages: OrderPackageStatus[];
  allocatedWarehouseId?: string;
  collectionSlot?: string;
  collectionQrCode?: string;
  totalWeightKg: number;
  totalVolumeM3: number;
  riskScore: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  riskReason?: string;
}

export interface PickTask {
  taskId: string;
  pickWaveId: string;
  orderId: string;
  sku: string;
  packageId: string;
  productName: string;
  sourceLocationId: string;
  stagingLocationId: string;
  quantity: number;
  workerId?: string;
  priority: number;
  deadline: string;
  status: 'PENDING' | 'IN_PROGRESS' | 'COMPLETED' | 'PAUSED_EXCEPTION';
  exceptionReason?: 'NOT_FOUND' | 'DAMAGED' | 'WRONG_LOCATION' | 'WRONG_PRODUCT' | 'BLOCKED_LOCATION';
  startedAt?: string;
  completedAt?: string;
  pickingSequence: number;
  optimalRoutePath: { x: number; y: number }[];
}

export interface Worker {
  workerId: string; // e.g. WRK-8042
  name: string;
  role: 'PICKER' | 'RECEIVER' | 'DISPATCHER' | 'SUPERVISOR' | 'INVENTORY_MANAGER';
  skills: ('PICKING' | 'RECEIVING' | 'FORKLIFT' | 'PACKING' | 'DISPATCH' | 'RETURNS')[];
  status: 'AVAILABLE' | 'ON_TASK' | 'ON_BREAK' | 'OFFLINE';
  currentLocation: { x: number; y: number; zone: string };
  assignedTaskId?: string;
  currentShift: 'MORNING' | 'AFTERNOON' | 'NIGHT';
  picksCompletedToday: number;
  speedMetersPerSec: number;
}

export interface Forklift {
  vehicleId: string; // e.g. FL-01
  operatorWorkerId?: string;
  batteryPct: number;
  status: 'AVAILABLE' | 'ASSIGNED' | 'TRAVELLING' | 'CHARGING' | 'MAINTENANCE';
  location: { x: number; y: number };
  currentLoadKg: number;
  maxCapacityKg: number;
}

export interface InboundShipment {
  shipmentId: string;
  asnNumber: string;
  supplierName: string;
  truckLicensePlate: string;
  driverName: string;
  estimatedArrival: string;
  actualArrival?: string;
  dockDoorId?: string;
  status: 'SCHEDULED' | 'ARRIVED' | 'AT_DOCK' | 'UNLOADING' | 'INSPECTING' | 'RECEIVED' | 'PUTAWAY_COMPLETE';
  skusExpected: { sku: string; expectedQty: number; receivedQty: number; damagedQty: number }[];
  putawayTasks: { sku: string; qty: number; recommendedLocationId: string; score: number; status: 'PENDING' | 'DONE' }[];
}

export interface CollectionOrder {
  collectionId: string;
  orderId: string;
  customerName: string;
  vehicleLicensePlate?: string;
  slotTime: string;
  qrCode: string;
  status: 'SCHEDULED' | 'ARRIVED' | 'RETRIEVING_PACKAGES' | 'READY_AT_BAY' | 'COMPLETED';
  bayId: string;
  stagingLocations: string[];
  packagesCount: number;
  verificationCode: string;
}

export interface AIRecommendation {
  id: string;
  timestamp: string;
  category: 'REPLENISHMENT' | 'PUTAWAY' | 'CONGESTION_MITIGATION' | 'ORDER_REROUTE' | 'STOCKOUT_RISK';
  title: string;
  recommendation: string;
  confidenceScore: number;
  evidence: string[];
  modelVersion: string;
  status: 'RECOMMENDED' | 'REVIEWED' | 'APPROVED' | 'EXECUTED' | 'REJECTED';
  actionPayload?: Record<string, unknown>;
}

export interface SustainabilityMetrics {
  electricityKwhToday: number;
  forkliftEnergyKwhToday: number;
  solarGenerationKwhToday: number;
  renewableSharePct: number;
  co2SavedKgToday: number;
  packagingRecycledKgToday: number;
  circularRestockCount: number;
  circularRefurbishCount: number;
}

export interface WhatIfScenarioResult {
  scenarioName: string;
  volumeChangePct: number;
  baselineThroughputOrdersHr: number;
  simulatedThroughputOrdersHr: number;
  baselineAvgPickDistanceM: number;
  simulatedAvgPickDistanceM: number;
  bottleneckZones: string[];
  recommendedActions: string[];
}
