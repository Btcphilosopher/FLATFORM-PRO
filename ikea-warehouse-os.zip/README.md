# IKEA WAREHOUSE OS (AUREOM-WMS)
## Enterprise Warehouse Management, Fulfilment & Distribution Operating System

### Synthetic Engineering Prototype
*Internal Code Name:* `AUREOM-WMS`
*Author:* Principal Warehouse Systems Architect

> **IMPORTANT DISCLAIMER**
> This software is a synthetic/fictional engineering project inspired by publicly observable flat-pack furniture retail, fulfillment, distribution, click-and-collect, and supply chain operational concepts. **It is NOT IKEA internal software.** It does NOT contain proprietary source code, internal warehouse layouts, commercial databases, or confidential algorithms. All data is synthetically generated.

---

### Core Architectural Principle
`AUREOM-WMS` is **not a passive warehouse dashboard**. It is a **computational digital operating model** of a multi-echelon furniture distribution center:
- Every physical flat-pack package has a **digital twin object**.
- Every warehouse movement generates an **immutable, timestamped inventory ledger event**.
- Every customer order has an **optimized package-level allocation and pick wave path**.
- Every worker task is **attributable, tracked, and safety-constrained**.
- Every picking route is calculated via **Dijkstra / A* graph optimization**.

---

### Canonical Fulfilment Graph
```
SUPPLIER
   ↓
INBOUND SHIPMENT (ASN)
   ↓
RECEIVING & QUALITY CHECK
   ↓
PUTAWAY OPTIMIZATION
   ↓
RESERVE / HIGH-BAY STORAGE
   ↓
FORWARD PICK LOCATION
   ↓
CUSTOMER ORDER ALLOCATION
   ↓
PICK WAVE & ROUTE CALCULATOR
   ↓
HANDHELD PICKER APP (BARCODE SCAN)
   ↓
STAGING & PACKAGE CONSOLIDATION
   ↓
CLICK & COLLECT / DELIVERY DISPATCH
   ↓
CUSTOMER HANDOVER / INTRANSIT
   ↓
RETURNS & CIRCULAR REFURBISHMENT
```

---

### Repository Layout
```
ikea-warehouse-os/
├── backend/                  # FastAPI & SQLAlchemy backend models
├── rust-core/                # High-performance Rust pathfinding & simulation engines
├── android/                  # Worker handheld Compose & CameraX apps
├── web/                      # Angular 21 Control Centre, Digital Twin & Consoles
├── database/                 # PostgreSQL migrations, schemas & seeds
├── simulation/               # Discrete-event warehouse traffic simulators
├── openapi/                  # OpenAPI 3.1 API Contracts
├── docs/                     # Technical Architecture & KPI Documentation
└── README.md
```

---

### Applications Suite
1. **Warehouse Control Centre (Wall Display / Manager Ops)**: Live KPIs, Command Screen, Congestion, Alerts, Master Demos.
2. **Interactive 2D Digital Twin Canvas**: Real-time worker positions, forklift vectors, stock heatmaps, location inspection.
3. **Android Worker Handheld Simulator**: Camera barcode reader, route guidance, pick task workflow, exception handling.
4. **Inbound Receiving & Quality Check**: Truck check-in, ASN match, automated putaway scoring.
5. **Outbound Dispatch & 3D Load Planner**: Truck loading optimization and delivery route tracking.
6. **Click & Collect Bay Console**: QR code verification, staging location retrieval, customer vehicle handover.
7. **Inventory Control & Ledger Console**: Immutable audit trail, ATP stock engine, cycle count discrepancy investigation.
8. **Logistics Control Tower**: Multi-warehouse network map, transit tracking, sustainability & circular metrics.
9. **Customer Order Status Simulator**: Real-time tracking and QR pickup code generation for customer orders.
10. **AI & What-If Optimisation Studio**: Gemini AI decision support queue with Human-in-the-Loop approval.

---

### Key Operational KPI Formulas
- **Inventory Accuracy** = $1 - \frac{|\text{Absolute Counted Variance}|}{\text{Expected Inventory}}$
- **Pick Productivity** = $\frac{\text{Units Picked}}{\text{Productive Labour Hours}}$
- **Warehouse Utilisation** = $\frac{\text{Occupied Volume } (m^3)}{\text{Available Capacity } (m^3)}$
- **Available To Promise (ATP)** = $\text{Physical Stock} - \text{Reserved} - \text{Allocated} + \text{Confirmed Inbound} - \text{Safety Buffer}$
- **Putaway Score** = $w_1 \cdot \text{Distance} + w_2 \cdot \text{Congestion} + w_3 \cdot \text{ReplenishCost} - w_4 \cdot \text{Affinity}$

---

### Running the System
```bash
# Start development server
npm run dev

# Compile check
npm run build
```
Access the application at `http://localhost:3000`.
