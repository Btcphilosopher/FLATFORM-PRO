package com.example.domain.materials

import com.example.domain.model.GrainDirection
import com.example.domain.model.Material
import com.example.domain.model.MaterialCategory
import com.example.domain.model.MaterialFinish

object MaterialLibrary {
    val materials: List<Material> = listOf(
        Material(
            id = "mat_oak_veneer",
            name = "Natural White Oak Veneer",
            category = MaterialCategory.SOLID_WOOD,
            finish = MaterialFinish.TEXTURED_VENEER,
            primaryColor = 0xFFD4A373,
            secondaryColor = 0xFFBC8A5F,
            thicknessOptionsMm = listOf(16f, 18f, 19f, 22f, 25f),
            densityKgM3 = 710f,
            costPerM2 = 58.50f,
            grainDirection = GrainDirection.VERTICAL,
            texturePattern = "fine_oak"
        ),
        Material(
            id = "mat_walnut_veneer",
            name = "American Black Walnut",
            category = MaterialCategory.SOLID_WOOD,
            finish = MaterialFinish.SATIN,
            primaryColor = 0xFF58311F,
            secondaryColor = 0xFF43281C,
            thicknessOptionsMm = listOf(18f, 19f, 22f, 25f),
            densityKgM3 = 660f,
            costPerM2 = 82.00f,
            grainDirection = GrainDirection.VERTICAL,
            texturePattern = "rich_walnut"
        ),
        Material(
            id = "mat_birch_plywood",
            name = "Baltic Birch Multi-Ply",
            category = MaterialCategory.PANEL_ENGINEERED,
            finish = MaterialFinish.NATURAL_GRAIN,
            primaryColor = 0xFFE9D8A6,
            secondaryColor = 0xFFD8C28A,
            thicknessOptionsMm = listOf(12f, 15f, 18f, 24f),
            densityKgM3 = 690f,
            costPerM2 = 44.00f,
            grainDirection = GrainDirection.VERTICAL,
            texturePattern = "plywood_layers"
        ),
        Material(
            id = "mat_white_melamine",
            name = "Alpine White MFC 18mm",
            category = MaterialCategory.PANEL_ENGINEERED,
            finish = MaterialFinish.MATT,
            primaryColor = 0xFFF3F4F6,
            secondaryColor = 0xFFE5E7EB,
            thicknessOptionsMm = listOf(16f, 18f),
            densityKgM3 = 650f,
            costPerM2 = 28.00f,
            grainDirection = GrainDirection.NONE,
            texturePattern = "clean_melamine"
        ),
        Material(
            id = "mat_anthracite_mfc",
            name = "Anthracite Matt MFC",
            category = MaterialCategory.PANEL_ENGINEERED,
            finish = MaterialFinish.MATT,
            primaryColor = 0xFF2B2F3A,
            secondaryColor = 0xFF1F232D,
            thicknessOptionsMm = listOf(18f, 22f),
            densityKgM3 = 670f,
            costPerM2 = 34.50f,
            grainDirection = GrainDirection.NONE,
            texturePattern = "matte_slate"
        ),
        Material(
            id = "mat_mdf_raw",
            name = "Industrial Standard MDF",
            category = MaterialCategory.PANEL_ENGINEERED,
            finish = MaterialFinish.MATT,
            primaryColor = 0xFFC9A26B,
            secondaryColor = 0xFFB38D56,
            thicknessOptionsMm = listOf(12f, 16f, 18f, 22f),
            densityKgM3 = 750f,
            costPerM2 = 22.00f,
            grainDirection = GrainDirection.NONE,
            texturePattern = "dense_fiber"
        ),
        Material(
            id = "mat_ash_solid",
            name = "Nordic White Ash",
            category = MaterialCategory.SOLID_WOOD,
            finish = MaterialFinish.NATURAL_GRAIN,
            primaryColor = 0xFFE0C9A6,
            secondaryColor = 0xFFCCB38C,
            thicknessOptionsMm = listOf(19f, 22f, 28f),
            densityKgM3 = 690f,
            costPerM2 = 68.00f,
            grainDirection = GrainDirection.VERTICAL,
            texturePattern = "bold_grain"
        ),
        Material(
            id = "mat_bamboo_pressed",
            name = "Caramel Pressed Bamboo",
            category = MaterialCategory.PANEL_ENGINEERED,
            finish = MaterialFinish.SATIN,
            primaryColor = 0xFFB8860B,
            secondaryColor = 0xFFA07208,
            thicknessOptionsMm = listOf(18f, 20f),
            densityKgM3 = 700f,
            costPerM2 = 62.00f,
            grainDirection = GrainDirection.VERTICAL,
            texturePattern = "bamboo_nodes"
        )
    )

    fun findById(id: String): Material =
        materials.find { it.id == id } ?: materials.first()
}
