import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { WarehouseStateEngine } from '../../core/services/warehouse-state.service';

@Component({
  selector: 'app-logistics-tower',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 bg-[#F4F4F4] min-h-screen text-slate-900 space-y-6">
      
      <div class="bg-white border border-slate-300 p-5 rounded-lg shadow-sm flex items-center justify-between">
        <div>
          <span class="bg-[#0058A3] text-white font-bold text-xs px-2.5 py-0.5 rounded uppercase">NETWORK CONTROL TOWER</span>
          <h2 class="text-2xl font-black text-slate-900 uppercase mt-1">LOGISTICS CONTROL TOWER & SUSTAINABILITY</h2>
          <p class="text-xs text-slate-600">Multi-Warehouse Network Visibility • In-Transit Transport • Renewable Energy Metrics</p>
        </div>

        <div class="flex items-center gap-2">
          <span class="bg-emerald-600 text-white font-extrabold text-xs px-3 py-1.5 rounded flex items-center gap-1">
            <mat-icon class="text-sm">eco</mat-icon>
            84.5% Renewable Electricity
          </span>
        </div>
      </div>

      <!-- Network Hubs Map Overview -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div class="bg-white border border-slate-300 rounded-lg p-5 shadow-sm space-y-2">
          <div class="flex justify-between items-center">
            <h3 class="font-extrabold text-slate-900">DC-01 Älmhult Hub</h3>
            <span class="bg-emerald-100 text-emerald-800 font-bold text-[10px] px-2 py-0.5 rounded">PRIMARY</span>
          </div>
          <p class="text-xs text-slate-600">Capacity: 125,000 m³ • Utilisation: 67.3%</p>
          <div class="w-full bg-slate-200 h-2 rounded-full mt-2">
            <div class="bg-[#0058A3] h-2 rounded-full" style="width: 67.3%"></div>
          </div>
        </div>

        <div class="bg-white border border-slate-300 rounded-lg p-5 shadow-sm space-y-2">
          <div class="flex justify-between items-center">
            <h3 class="font-extrabold text-slate-900">DC-02 London Gateway</h3>
            <span class="bg-blue-100 text-blue-800 font-bold text-[10px] px-2 py-0.5 rounded">REGIONAL</span>
          </div>
          <p class="text-xs text-slate-600">Capacity: 98,000 m³ • Utilisation: 82.1%</p>
          <div class="w-full bg-slate-200 h-2 rounded-full mt-2">
            <div class="bg-[#0058A3] h-2 rounded-full" style="width: 82.1%"></div>
          </div>
        </div>

        <div class="bg-white border border-slate-300 rounded-lg p-5 shadow-sm space-y-2">
          <div class="flex justify-between items-center">
            <h3 class="font-extrabold text-slate-900">DC-03 Hamburg Logistics</h3>
            <span class="bg-blue-100 text-blue-800 font-bold text-[10px] px-2 py-0.5 rounded">REGIONAL</span>
          </div>
          <p class="text-xs text-slate-600">Capacity: 140,000 m³ • Utilisation: 54.8%</p>
          <div class="w-full bg-slate-200 h-2 rounded-full mt-2">
            <div class="bg-[#0058A3] h-2 rounded-full" style="width: 54.8%"></div>
          </div>
        </div>
      </div>

      <!-- Sustainability & Circular Economy Metrics -->
      <div class="bg-white border border-slate-300 rounded-lg p-5 shadow-sm space-y-4">
        <h3 class="font-extrabold text-slate-900 text-base uppercase border-b border-slate-200 pb-2 flex items-center gap-2">
          <mat-icon class="text-emerald-600">nature_people</mat-icon>
          SUSTAINABILITY & CIRCULAR ECONOMY PERFORMANCE
        </h3>

        <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
          <div class="bg-slate-50 p-3 rounded border border-slate-200 space-y-1">
            <span class="text-slate-500 uppercase text-[10px]">Rooftop Solar Generation</span>
            <p class="text-xl font-extrabold text-emerald-700 font-mono">{{ state.sustainability().solarGenerationKwhToday }} kWh</p>
          </div>
          <div class="bg-slate-50 p-3 rounded border border-slate-200 space-y-1">
            <span class="text-slate-500 uppercase text-[10px]">Warehouse CO₂ Saved</span>
            <p class="text-xl font-extrabold text-emerald-700 font-mono">{{ state.sustainability().co2SavedKgToday }} kg</p>
          </div>
          <div class="bg-slate-50 p-3 rounded border border-slate-200 space-y-1">
            <span class="text-slate-500 uppercase text-[10px]">Flat-Pack Packaging Recycled</span>
            <p class="text-xl font-extrabold text-blue-800 font-mono">{{ state.sustainability().packagingRecycledKgToday }} kg</p>
          </div>
          <div class="bg-slate-50 p-3 rounded border border-slate-200 space-y-1">
            <span class="text-slate-500 uppercase text-[10px]">Circular Restocked Items</span>
            <p class="text-xl font-extrabold text-slate-900 font-mono">{{ state.sustainability().circularRestockCount }} Units</p>
          </div>
        </div>
      </div>

    </div>
  `
})
export class LogisticsTowerComponent {
  readonly state = inject(WarehouseStateEngine);
}
