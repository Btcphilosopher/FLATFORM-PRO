package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import com.example.ui.dashboard.DashboardScreen
import com.example.ui.screens.MainDesignerScreen
import com.example.ui.theme.FlatformProTheme
import com.example.ui.viewmodel.DesignerViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: DesignerViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            FlatformProTheme {
                val state by viewModel.uiState.collectAsState()
                val snackbarHostState = remember { SnackbarHostState() }

                LaunchedEffect(state.snackbarMessage) {
                    state.snackbarMessage?.let { msg ->
                        snackbarHostState.showSnackbar(msg)
                        viewModel.clearSnackbar()
                    }
                }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    snackbarHost = { SnackbarHost(snackbarHostState) }
                ) { innerPadding ->
                    Crossfade(
                        targetState = state.currentScreen,
                        modifier = Modifier.padding(innerPadding),
                        label = "screen_transition"
                    ) { screen ->
                        when (screen) {
                            "DASHBOARD" -> {
                                DashboardScreen(
                                    recentProjects = state.projectsList,
                                    onOpenProject = { viewModel.openProject(it) },
                                    onCreateFromTemplate = { viewModel.createFromTemplate(it) },
                                    onDeleteProject = { viewModel.deleteProject(it) },
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                            else -> {
                                MainDesignerScreen(
                                    viewModel = viewModel,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
