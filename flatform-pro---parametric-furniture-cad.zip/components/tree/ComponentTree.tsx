'use client';

import React, { useState } from 'react';
import { FurnitureComponent, FurnitureProject, HardwareItem } from '@/types/furniture';
import {
  Box,
  ChevronDown,
  ChevronRight,
  Eye,
  EyeOff,
  Folder,
  FolderOpen,
  Layers,
  Lock,
  Plus,
  Unlock,
  Wrench,
  DoorClosed,
  Archive,
} from 'lucide-react';
import { getMaterialById } from '@/lib/materials';

interface ComponentTreeProps {
  project: FurnitureProject;
  selectedComponentId: string | null;
  onSelectComponent: (id: string | null) => void;
  hoveredComponentId: string | null;
  onHoverComponent: (id: string | null) => void;
  onToggleVisibility: (componentId: string) => void;
  onToggleLock: (componentId: string) => void;
  onAddShelf: () => void;
  onAddDoor: () => void;
  onAddDrawer: () => void;
}

export function ComponentTree({
  project,
  selectedComponentId,
  onSelectComponent,
  hoveredComponentId,
  onHoverComponent,
  onToggleVisibility,
  onToggleLock,
  onAddShelf,
  onAddDoor,
  onAddDrawer,
}: ComponentTreeProps) {
  const [collapsedCategories, setCollapsedCategories] = useState<Record<string, boolean>>({});
  const [activeTab, setActiveTab] = useState<'hierarchy' | 'materials' | 'hardware'>('hierarchy');

  const toggleCategory = (cat: string) => {
    setCollapsedCategories((prev) => ({
      ...prev,
      [cat]: !prev[cat],
    }));
  };

  const categories: {
    key: 'structure' | 'interior' | 'doors' | 'drawers' | 'hardware';
    name: string;
    icon: React.ReactNode;
  }[] = [
    { key: 'structure', name: 'STRUCTURE (CARCASS)', icon: <Box className="w-3.5 h-3.5 text-blue-400" /> },
    { key: 'interior', name: 'INTERIOR (SHELVES & DIVIDERS)', icon: <Layers className="w-3.5 h-3.5 text-amber-400" /> },
    { key: 'doors', name: 'FRONT DOORS', icon: <DoorClosed className="w-3.5 h-3.5 text-emerald-400" /> },
    { key: 'drawers', name: 'DRAWERS & BOXES', icon: <Archive className="w-3.5 h-3.5 text-purple-400" /> },
    { key: 'hardware', name: 'FASTENERS & HARDWARE', icon: <Wrench className="w-3.5 h-3.5 text-zinc-400" /> },
  ];

  return (
    <div id="component_tree_sidebar" className="w-64 h-full bg-[#16171B] border-r border-[#2C2E33] flex flex-col font-sans text-xs select-none shrink-0">
      {/* Sidebar Header / Tabs */}
      <div className="flex border-b border-[#2C2E33] bg-[#1A1B1E]">
        <button
          id="tab_tree_hierarchy"
          onClick={() => setActiveTab('hierarchy')}
          className={`flex-1 py-2 text-[10px] font-bold text-center uppercase tracking-wider transition-colors ${
            activeTab === 'hierarchy'
              ? 'text-white border-b-2 border-blue-500 bg-[#16171B]'
              : 'text-gray-400 hover:text-gray-200'
          }`}
        >
          Tree ({project.components.length})
        </button>
        <button
          id="tab_tree_materials"
          onClick={() => setActiveTab('materials')}
          className={`flex-1 py-2 text-[10px] font-bold text-center uppercase tracking-wider transition-colors ${
            activeTab === 'materials'
              ? 'text-white border-b-2 border-blue-500 bg-[#16171B]'
              : 'text-gray-400 hover:text-gray-200'
          }`}
        >
          Materials
        </button>
        <button
          id="tab_tree_hardware"
          onClick={() => setActiveTab('hardware')}
          className={`flex-1 py-2 text-[10px] font-bold text-center uppercase tracking-wider transition-colors ${
            activeTab === 'hardware'
              ? 'text-white border-b-2 border-blue-500 bg-[#16171B]'
              : 'text-gray-400 hover:text-gray-200'
          }`}
        >
          Hardware ({project.hardwareItems.length})
        </button>
      </div>

      {/* Main Tree List View */}
      {activeTab === 'hierarchy' && (
        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {/* Project Root Header */}
          <div className="flex items-center justify-between px-2 py-1.5 bg-black/40 rounded border border-[#383A40] text-gray-300">
            <div className="flex items-center gap-1.5 truncate">
              <span className="text-blue-400 font-bold text-xs">▼</span>
              <span className="font-bold text-xs text-blue-400 truncate">{project.name}</span>
            </div>
            <span className="text-[9px] text-gray-400 font-mono px-1.5 py-0.5 bg-[#2C2E33] rounded">
              v{project.version}
            </span>
          </div>

          {/* Quick Add Action Row */}
          <div className="flex items-center gap-1 py-1">
            <button
              onClick={onAddShelf}
              title="Add Shelf"
              className="flex-1 flex items-center justify-center gap-1 py-1 bg-[#222328] hover:bg-[#323439] text-gray-300 rounded border border-[#383A40] text-[10px] transition-colors"
            >
              <Plus className="w-3 h-3 text-amber-400" /> Shelf
            </button>
            <button
              onClick={onAddDoor}
              title="Toggle / Add Doors"
              className="flex-1 flex items-center justify-center gap-1 py-1 bg-[#222328] hover:bg-[#323439] text-gray-300 rounded border border-[#383A40] text-[10px] transition-colors"
            >
              <Plus className="w-3 h-3 text-emerald-400" /> Door
            </button>
            <button
              onClick={onAddDrawer}
              title="Add Drawer"
              className="flex-1 flex items-center justify-center gap-1 py-1 bg-[#222328] hover:bg-[#323439] text-gray-300 rounded border border-[#383A40] text-[10px] transition-colors"
            >
              <Plus className="w-3 h-3 text-purple-400" /> Drawer
            </button>
          </div>

          {/* Category Tree Folders */}
          {categories.map((cat) => {
            const isCollapsed = !!collapsedCategories[cat.key];
            const comps =
              cat.key === 'hardware'
                ? []
                : project.components.filter((c) => c.category === cat.key);

            const hwItems =
              cat.key === 'hardware' ? project.hardwareItems : [];

            const totalItemsCount = cat.key === 'hardware' ? hwItems.length : comps.length;

            return (
              <div key={cat.key} className="space-y-0.5">
                {/* Folder Header */}
                <div
                  onClick={() => toggleCategory(cat.key)}
                  className="flex items-center justify-between px-2 py-1 bg-[#1A1B1E] hover:bg-[#222328] rounded cursor-pointer text-gray-300 transition-colors"
                >
                  <div className="flex items-center gap-1.5">
                    <span className="text-[9px] text-gray-500 font-bold">
                      {isCollapsed ? '▶' : '▼'}
                    </span>
                    {cat.icon}
                    <span className="text-[10px] font-bold tracking-wider">{cat.name}</span>
                  </div>
                  <span className="text-[10px] text-gray-500 font-mono">{totalItemsCount}</span>
                </div>

                {/* Sub-items list */}
                {!isCollapsed && (
                  <div className="pl-3 space-y-0.5 border-l border-[#2C2E33] ml-2">
                    {/* Render Components */}
                    {comps.map((comp) => {
                      const isSelected = selectedComponentId === comp.id;
                      const isHovered = hoveredComponentId === comp.id;
                      const mat = getMaterialById(comp.materialId);

                      return (
                        <div
                          key={comp.id}
                          id={`tree_item_${comp.id}`}
                          onClick={() => onSelectComponent(comp.id)}
                          onMouseEnter={() => onHoverComponent(comp.id)}
                          onMouseLeave={() => onHoverComponent(null)}
                          className={`flex items-center justify-between px-2 py-1 rounded cursor-pointer transition-colors group text-xs ${
                            isSelected
                              ? 'text-white bg-white/5 rounded ring-1 ring-white/10'
                              : isHovered
                              ? 'bg-white/[0.03] text-gray-200'
                              : 'text-gray-400 hover:text-white'
                          }`}
                        >
                          <div className="flex items-center gap-1.5 truncate">
                            <span
                              className="w-2 h-2 rounded-sm shrink-0 shadow-inner"
                              style={{ backgroundColor: mat.color }}
                              title={mat.name}
                            />
                            <span className="truncate text-xs">├─ {comp.name}</span>
                          </div>

                          <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                onToggleVisibility(comp.id);
                              }}
                              className="p-0.5 hover:text-gray-200 text-gray-500"
                              title={comp.visible ? 'Hide part' : 'Show part'}
                            >
                              {comp.visible ? (
                                <Eye className="w-3 h-3" />
                              ) : (
                                <EyeOff className="w-3 h-3 text-red-400" />
                              )}
                            </button>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                onToggleLock(comp.id);
                              }}
                              className="p-0.5 hover:text-gray-200 text-gray-500"
                              title={comp.locked ? 'Unlock part' : 'Lock part'}
                            >
                              {comp.locked ? (
                                <Lock className="w-3 h-3 text-amber-400" />
                              ) : (
                                <Unlock className="w-3 h-3" />
                              )}
                            </button>
                          </div>
                        </div>
                      );
                    })}

                    {/* Render Hardware in tree */}
                    {cat.key === 'hardware' &&
                      hwItems.slice(0, 15).map((hw) => {
                        const isHwSelected = selectedComponentId === hw.id;
                        return (
                          <div
                            key={hw.id}
                            onClick={() => onSelectComponent(hw.id)}
                            className={`flex items-center justify-between px-2 py-1 rounded cursor-pointer truncate text-xs ${
                              isHwSelected
                                ? 'text-white bg-white/5 ring-1 ring-white/10'
                                : 'text-gray-400 hover:text-white'
                            }`}
                          >
                            <span className="truncate text-[11px]">├─ {hw.name}</span>
                            <span className="text-[9px] text-gray-500 font-mono">{(hw.quantity ?? 1)}x</span>
                          </div>
                        );
                      })}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Materials Tab */}
      {activeTab === 'materials' && (
        <div className="flex-1 overflow-y-auto p-3 space-y-3">
          <div className="text-[10px] text-gray-500 uppercase font-bold">Active Project Palette</div>
          <div className="space-y-2">
            {[
              { label: 'Carcass Structural Material', matId: project.config.defaultCarcassMaterialId },
              { label: 'Front Doors & Drawer Faces', matId: project.config.defaultFrontMaterialId },
              { label: 'Back Panel / Bottom Slots', matId: project.config.defaultBackMaterialId },
            ].map((slot, idx) => {
              const mat = getMaterialById(slot.matId);
              return (
                <div key={idx} className="p-2 bg-black border border-[#383A40] rounded space-y-1">
                  <div className="text-[9px] text-gray-500 uppercase">{slot.label}</div>
                  <div className="flex items-center gap-2">
                    <span className="w-4 h-4 rounded-sm border border-gray-600 shrink-0" style={{ backgroundColor: mat.color }} />
                    <span className="text-[11px] text-gray-200 font-medium truncate">{mat.name}</span>
                  </div>
                  <div className="flex items-center justify-between text-[10px] text-gray-400 pt-1 font-mono">
                    <span>${mat.costPerM2}/m²</span>
                    <span>{mat.densityKgM3} kg/m³</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Hardware Tab */}
      {activeTab === 'hardware' && (
        <div className="flex-1 overflow-y-auto p-3 space-y-2">
          <div className="text-[10px] text-gray-500 uppercase font-bold">Connected Hardware Connectors</div>
          <div className="space-y-1.5">
            {project.hardwareItems.map((hw) => (
              <div
                key={hw.id}
                onClick={() => onSelectComponent(hw.id)}
                className="p-2 bg-black hover:border-gray-500 border border-[#383A40] rounded cursor-pointer space-y-1 transition-colors"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[11px] text-gray-200 font-medium truncate">{hw.name}</span>
                  <span className="text-[10px] text-emerald-400 font-mono">${hw.unitCost.toFixed(2)}</span>
                </div>
                <div className="text-[9px] text-gray-400 truncate">{hw.description}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Sidebar Footer Stats */}
      <div className="p-2.5 bg-[#16171B] border-t border-[#2C2E33] text-[10px] text-gray-400 flex items-center justify-between font-mono">
        <span>Parts: {project.components.length}</span>
        <span className="text-blue-400">BOM Ready</span>
      </div>
    </div>
  );
}
