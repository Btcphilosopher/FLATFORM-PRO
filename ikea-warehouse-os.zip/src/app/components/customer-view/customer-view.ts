import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { WarehouseStateEngine } from '../../core/services/warehouse-state.service';

@Component({
  selector: 'app-customer-view',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 bg-slate-100 min-h-screen flex justify-center items-start">
      
      <!-- Customer Mobile Order Tracker Simulator Card -->
      <div class="w-full max-w-lg bg-white border border-slate-300 rounded-2xl shadow-xl overflow-hidden text-slate-900 space-y-6">
        
        <!-- IKEA-style Blue Header -->
        <div class="bg-[#0058A3] text-white p-5 space-y-2">
          <div class="flex items-center justify-between">
            <span class="bg-[#FFDA1A] text-black font-black text-xs px-2.5 py-0.5 rounded tracking-tight">IKEA CLICK & COLLECT</span>
            <span class="text-xs text-blue-200 font-mono">ORDER #ORD-100042</span>
          </div>
          <h2 class="text-2xl font-black uppercase tracking-tight">TRACK YOUR FURNITURE ORDER</h2>
          <p class="text-xs text-blue-100">Älmhult Store Collection Point • Bay 02</p>
        </div>

        <div class="p-6 space-y-6">
          
          <!-- Live Order Status Progress Stepper -->
          <div class="space-y-3">
            <div class="flex justify-between text-xs font-bold uppercase text-slate-500">
              <span>Order Created</span>
              <span>Picking</span>
              <span class="text-[#0058A3] font-black">Ready for Pickup</span>
              <span>Collected</span>
            </div>
            
            <div class="w-full bg-slate-200 h-3 rounded-full overflow-hidden">
              <div class="bg-[#0058A3] h-3 rounded-full transition-all duration-500" style="width: 75%"></div>
            </div>
          </div>

          <!-- Customer Collection QR Code Pass Card -->
          <div class="bg-blue-50 border-2 border-[#0058A3] p-5 rounded-xl text-center space-y-3 shadow-inner">
            <span class="bg-[#0058A3] text-white font-extrabold text-[10px] px-3 py-1 rounded-full uppercase tracking-wider inline-block">
              SHOW QR CODE AT COLLECTION BAY 02
            </span>
            
            <!-- Simulated High-Contrast QR Code Visual -->
            <div class="bg-white p-4 inline-block rounded-lg border-2 border-slate-900 shadow">
              <div class="w-32 h-32 bg-slate-900 p-2 flex flex-col justify-between text-[8px] text-white font-mono">
                <div class="flex justify-between">
                  <span class="w-6 h-6 bg-white block border-2 border-slate-900"></span>
                  <span class="w-6 h-6 bg-white block border-2 border-slate-900"></span>
                </div>
                <p class="text-center font-bold text-yellow-300">QR-100042-SWEDEN</p>
                <div class="flex justify-between">
                  <span class="w-6 h-6 bg-white block border-2 border-slate-900"></span>
                  <span class="w-2 h-2 bg-white block"></span>
                </div>
              </div>
            </div>

            <div>
              <p class="text-xs font-bold text-slate-900">Customer: Astrid Bergman</p>
              <p class="text-xs text-slate-600 font-mono">3 Flat-Pack Packages Ready in Staging Bay STG-04</p>
            </div>
          </div>

          <!-- Flat-Pack Packages Breakdown -->
          <div class="space-y-3 border-t border-slate-200 pt-4 text-xs">
            <h4 class="font-extrabold uppercase text-slate-800">Your Flat-Pack Packages (1 Product • 3 Packages)</h4>
            
            <div class="space-y-2">
              <div class="bg-slate-50 border border-slate-200 p-3 rounded flex justify-between items-center">
                <div>
                  <span class="font-bold text-slate-900 block">SYNTHETIC-PAX-WARDROBE</span>
                  <span class="text-[10px] text-slate-500">Package 1 of 3 • 2.38m × 0.61m × 0.08m (42kg)</span>
                </div>
                <span class="text-emerald-700 font-extrabold text-[10px]">READY ✓</span>
              </div>
              <div class="bg-slate-50 border border-slate-200 p-3 rounded flex justify-between items-center">
                <div>
                  <span class="font-bold text-slate-900 block">SYNTHETIC-PAX-WARDROBE</span>
                  <span class="text-[10px] text-slate-500">Package 2 of 3 • 2.38m × 0.61m × 0.08m (38kg)</span>
                </div>
                <span class="text-emerald-700 font-extrabold text-[10px]">READY ✓</span>
              </div>
              <div class="bg-slate-50 border border-slate-200 p-3 rounded flex justify-between items-center">
                <div>
                  <span class="font-bold text-slate-900 block">SYNTHETIC-PAX-WARDROBE</span>
                  <span class="text-[10px] text-slate-500">Package 3 of 3 • 0.98m × 0.58m × 0.04m (17kg)</span>
                </div>
                <span class="text-emerald-700 font-extrabold text-[10px]">READY ✓</span>
              </div>
            </div>
          </div>

        </div>

      </div>

    </div>
  `
})
export class CustomerViewComponent {
  readonly state = inject(WarehouseStateEngine);
}
