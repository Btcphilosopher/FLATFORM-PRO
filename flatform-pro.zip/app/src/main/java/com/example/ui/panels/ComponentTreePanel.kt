package com.example.ui.panels

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.ComponentGroup
import com.example.domain.model.FurnitureComponent
import com.example.domain.model.FurnitureProject
import com.example.ui.theme.*

@Composable
fun ComponentTreePanel(
    project: FurnitureProject,
    selectedComponentId: String?,
    onSelectComponent: (String?) -> Unit,
    onToggleVisibility: (String) -> Unit,
    onAddComponent: (ComponentGroup) -> Unit,
    onDeleteComponent: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var expandedGroups by remember {
        mutableStateOf(setOf(ComponentGroup.STRUCTURE, ComponentGroup.INTERIOR, ComponentGroup.FACADES, ComponentGroup.DRAWERS))
    }

    Column(
        modifier = modifier
            .fillMaxHeight()
            .background(CadSurface)
            .testTag("component_tree_panel")
    ) {
        // Panel Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "COMPONENT HIERARCHY",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = CadAccentBlue,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "${project.components.size} Parametric Parts",
                    fontSize = 10.sp,
                    color = CadTextMuted
                )
            }

            // Quick Add Menu
            var menuExpanded by remember { mutableStateOf(false) }
            Box {
                IconButton(
                    onClick = { menuExpanded = true },
                    modifier = Modifier.size(24.dp).testTag("btn_add_component_menu")
                ) {
                    Icon(Icons.Default.AddCircleOutline, contentDescription = "Add Component", tint = CadAccentBlue, modifier = Modifier.size(18.dp))
                }

                DropdownMenu(
                    expanded = menuExpanded,
                    onDismissRequest = { menuExpanded = false },
                    modifier = Modifier.background(CadSurfaceElevated)
                ) {
                    DropdownMenuItem(
                        text = { Text("Add Adjustable Shelf", fontSize = 12.sp, color = CadTextPrimary) },
                        leadingIcon = { Icon(Icons.Default.TableRows, contentDescription = null, tint = CadAccentBlue, modifier = Modifier.size(16.dp)) },
                        onClick = {
                            onAddComponent(ComponentGroup.INTERIOR)
                            menuExpanded = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Add Drawer Bay", fontSize = 12.sp, color = CadTextPrimary) },
                        leadingIcon = { Icon(Icons.Default.Inbox, contentDescription = null, tint = CadAccentBlue, modifier = Modifier.size(16.dp)) },
                        onClick = {
                            onAddComponent(ComponentGroup.DRAWERS)
                            menuExpanded = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Add Vertical Divider", fontSize = 12.sp, color = CadTextPrimary) },
                        leadingIcon = { Icon(Icons.Default.Splitscreen, contentDescription = null, tint = CadAccentBlue, modifier = Modifier.size(16.dp)) },
                        onClick = {
                            onAddComponent(ComponentGroup.STRUCTURE)
                            menuExpanded = false
                        }
                    )
                }
            }
        }

        HorizontalDivider(color = CadBorder)

        // Tree List
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(vertical = 4.dp)
        ) {
            ComponentGroup.values().forEach { group ->
                val groupComponents = project.components.filter { it.group == group }
                if (groupComponents.isNotEmpty() || group != ComponentGroup.HARDWARE) {
                    val isExpanded = expandedGroups.contains(group)

                    // Group Header Row
                    item(key = "group_${group.name}") {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    expandedGroups = if (isExpanded) expandedGroups - group else expandedGroups + group
                                }
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (isExpanded) Icons.Default.KeyboardArrowDown else Icons.Default.KeyboardArrowRight,
                                contentDescription = null,
                                tint = CadTextSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(Modifier.width(4.dp))
                            Icon(
                                imageVector = when (group) {
                                    ComponentGroup.STRUCTURE -> Icons.Default.ViewInAr
                                    ComponentGroup.INTERIOR -> Icons.Default.TableRows
                                    ComponentGroup.FACADES -> Icons.Default.SensorDoor
                                    ComponentGroup.DRAWERS -> Icons.Default.Inbox
                                    ComponentGroup.HARDWARE -> Icons.Default.Build
                                },
                                contentDescription = null,
                                tint = CadAccentCyan,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                text = group.name,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = CadTextPrimary,
                                modifier = Modifier.weight(1f)
                            )
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = CadSurfaceVariant
                            ) {
                                Text(
                                    text = "${groupComponents.size}",
                                    fontSize = 9.sp,
                                    color = CadTextSecondary,
                                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                                )
                            }
                        }
                    }

                    // Children Rows
                    if (isExpanded) {
                        items(groupComponents, key = { it.id }) { comp ->
                            val isSelected = comp.id == selectedComponentId
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(
                                        if (isSelected) CadAccentBlue.copy(alpha = 0.18f) else Color.Transparent
                                    )
                                    .clickable { onSelectComponent(comp.id) }
                                    .padding(start = 28.dp, end = 8.dp, top = 4.dp, bottom = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Component Name & Dim
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = comp.name,
                                        fontSize = 11.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) CadAccentBlue else CadTextPrimary
                                    )
                                    Text(
                                        text = "${comp.dimensions.width.toInt()}×${comp.dimensions.height.toInt()}×${comp.dimensions.depth.toInt()} mm",
                                        fontSize = 9.sp,
                                        color = CadTextMuted
                                    )
                                }

                                // Visibility Toggle
                                IconButton(
                                    onClick = { onToggleVisibility(comp.id) },
                                    modifier = Modifier.size(22.dp)
                                ) {
                                    Icon(
                                        imageVector = if (comp.isVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                        contentDescription = "Toggle Visibility",
                                        tint = if (comp.isVisible) CadTextSecondary else CadTextMuted,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
