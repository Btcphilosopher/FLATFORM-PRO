'use client';

import React from 'react';
import {
  EdgeBandingType,
  FurnitureComponent,
  FurnitureProject,
  JointType,
  ParametricConfig,
} from '@/types/furniture';
import { MATERIALS_DATABASE, getMaterialById } from '@/lib/materials';
import {
  Activity,
  AlertTriangle,
  CheckCircle2,
  Cpu,
  Layers,
  Palette,
  Ruler,
  Settings,
  ShieldAlert,
  Sparkles,
  Wrench,
} from 'lucide-react';

interface PropertyInspectorProps {
  project: FurnitureProject;
  onUpdateConfig: (newConfig: Partial<ParametricConfig>) => void;
  selectedComponent: FurnitureComponent | null;
  onUpdateComponent: (updated: FurnitureComponent) => void;
  onApplyVariant: (variantId: string) => void;
}

export function PropertyInspector({
  project,
  onUpdateConfig,
  selectedComponent,
  onUpdateComponent,
  onApplyVariant,
}: PropertyInspectorProps) {
  const { config } = project;

  return (
    <div id="property_inspector_sidebar" className="w-80 h-full bg-[#16171B] border-l border-[#2C2E33] flex flex-col font-sans text-xs select-none shrink-0">
      {/* Header */}
      <div className="p-3 border-b border-[#2C2E33] bg-[#1A1B1E] flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Settings className="w-4 h-4 text-blue-400" />
          <span className="font-bold text-gray-200 text-xs tracking-wider uppercase">
            {selectedComponent ? 'Component Inspector' : 'Parametric Inspector'}
          </span>
        </div>
        {selectedComponent && (
          <span className="px-1.5 py-0.5 bg-blue-900/40 text-blue-400 text-[9px] font-mono rounded border border-blue-700/50">
            ACTIVE PART
          </span>
        )}
      </div>

      {/* Main Inspector Scrollable Area */}
      <div className="flex-1 overflow-y-auto p-3 space-y-3">
        {/* If a Component is Selected, Show Component-Level CNC / Edge-Banding Inspector */}
        {selectedComponent ? (
          <div className="space-y-3 animate-in fade-in duration-150">
            {/* Component Header Card */}
            <div className="p-3 bg-black/40 border border-[#2C2E33] rounded-lg space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-blue-400 text-xs truncate">
                  {selectedComponent.name}
                </span>
                <span className="text-[10px] text-gray-400 font-mono">
                  ID: {selectedComponent.id.replace('comp_', '')}
                </span>
              </div>
              <div className="text-[11px] text-gray-300">
                Type:{' '}
                <span className="text-gray-100 font-semibold uppercase">
                  {selectedComponent.type.replace(/_/g, ' ')}
                </span>
              </div>
            </div>

            {/* Local Dimensions & Coordinates */}
            <div className="p-3 bg-black/40 border border-[#2C2E33] rounded-lg space-y-2.5">
              <div className="text-[10px] text-gray-400 font-bold uppercase tracking-wider flex items-center gap-1.5">
                <Ruler className="w-3.5 h-3.5 text-blue-400" /> 3D Part Dimensions (mm)
              </div>
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="text-[9px] text-gray-500 uppercase block font-medium">Width (X)</label>
                  <input
                    type="number"
                    value={Math.round(selectedComponent.dimensions.width)}
                    onChange={(e) => {
                      const val = Number(e.target.value);
                      onUpdateComponent({
                        ...selectedComponent,
                        dimensions: { ...selectedComponent.dimensions, width: val },
                      });
                    }}
                    className="w-full bg-[#1A1B1E] border border-[#2C2E33] rounded px-2 py-1 text-gray-100 font-mono text-xs focus:border-blue-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-[9px] text-gray-500 uppercase block font-medium">Height (Y)</label>
                  <input
                    type="number"
                    value={Math.round(selectedComponent.dimensions.height)}
                    onChange={(e) => {
                      const val = Number(e.target.value);
                      onUpdateComponent({
                        ...selectedComponent,
                        dimensions: { ...selectedComponent.dimensions, height: val },
                      });
                    }}
                    className="w-full bg-[#1A1B1E] border border-[#2C2E33] rounded px-2 py-1 text-gray-100 font-mono text-xs focus:border-blue-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-[9px] text-gray-500 uppercase block font-medium">Thick (T)</label>
                  <input
                    type="number"
                    value={selectedComponent.thicknessMm}
                    onChange={(e) => {
                      const val = Number(e.target.value);
                      onUpdateComponent({
                        ...selectedComponent,
                        thicknessMm: val,
                      });
                    }}
                    className="w-full bg-[#1A1B1E] border border-[#2C2E33] rounded px-2 py-1 text-gray-100 font-mono text-xs focus:border-blue-500 focus:outline-none"
                  />
                </div>
              </div>
            </div>

            {/* Edge Banding Treatment Matrix */}
            <div className="p-3 bg-black/40 border border-[#2C2E33] rounded-lg space-y-2.5">
              <div className="text-[10px] text-gray-400 font-bold uppercase tracking-wider flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-amber-400" /> Edge Banding Application
              </div>
              <div className="grid grid-cols-2 gap-2 text-[10px]">
                {(['top', 'bottom', 'left', 'right'] as (keyof typeof selectedComponent.edgeTreatments)[]).map(
                  (edge) => (
                    <div key={edge} className="space-y-1">
                      <span className="text-gray-500 uppercase">{edge} Edge</span>
                      <select
                        value={selectedComponent.edgeTreatments[edge]}
                        onChange={(e) => {
                          const val = e.target.value as EdgeBandingType;
                          onUpdateComponent({
                            ...selectedComponent,
                            edgeTreatments: {
                              ...selectedComponent.edgeTreatments,
                              [edge]: val,
                            },
                          });
                        }}
                        className="w-full bg-[#1A1B1E] border border-[#2C2E33] rounded px-1.5 py-1 text-gray-200 text-[10px] focus:border-blue-500 focus:outline-none"
                      >
                        <option value="none">None (Raw)</option>
                        <option value="0.4mm_pvc">0.4mm PVC</option>
                        <option value="1.0mm_abs">1.0mm ABS Pro</option>
                        <option value="2.0mm_abs">2.0mm ABS Radius</option>
                        <option value="wood_veneer">Natural Veneer</option>
                      </select>
                    </div>
                  )
                )}
              </div>
            </div>

            {/* CNC Machining Operations on this Panel */}
            <div className="p-3 bg-black/40 border border-[#2C2E33] rounded-lg space-y-2">
              <div className="text-[10px] text-gray-400 font-bold uppercase tracking-wider flex items-center gap-1.5">
                <Cpu className="w-3.5 h-3.5 text-emerald-400" /> CNC Tooling Operations (
                {selectedComponent.machiningHoles.length + selectedComponent.machiningGrooves.length})
              </div>

              {selectedComponent.machiningHoles.length > 0 ||
              selectedComponent.machiningGrooves.length > 0 ? (
                <div className="space-y-1 text-[10px]">
                  {selectedComponent.machiningGrooves.map((g) => (
                    <div key={g.id} className="p-1.5 bg-[#1A1B1E] rounded border border-[#2C2E33] flex items-center justify-between">
                      <span className="text-amber-300 truncate">{g.name}</span>
                      <span className="text-gray-400 font-mono">{g.widthMm}×{g.depthMm}mm</span>
                    </div>
                  ))}
                  {selectedComponent.machiningHoles.map((h) => (
                    <div key={h.id} className="p-1.5 bg-[#1A1B1E] rounded border border-[#2C2E33] flex items-center justify-between">
                      <span className="text-blue-300 truncate">Ø{h.diameterMm}mm Drill ({h.purpose})</span>
                      <span className="text-gray-400 font-mono">Depth: {h.depthMm}mm</span>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-[10px] text-gray-500 italic">No custom CNC milling required for this flat panel.</div>
              )}
            </div>
          </div>
        ) : (
          /* Global Parametric Furniture Configuration */
          <div className="space-y-3">
            {/* Primary Carcass Dimensions */}
            <div className="p-3 bg-black/40 border border-[#2C2E33] rounded-lg space-y-3">
              <div className="text-[10px] text-blue-400 font-bold uppercase tracking-wider flex items-center gap-1.5">
                <Ruler className="w-3.5 h-3.5" /> Overall Dimensions (mm)
              </div>

              {/* Width Slider + Number Input */}
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <label className="text-[10px] text-gray-400 uppercase font-medium">Width</label>
                  <span className="text-blue-400 font-bold font-mono">{config.width} mm</span>
                </div>
                <input
                  id="input_param_width"
                  type="range"
                  min="600"
                  max="3600"
                  step="50"
                  value={config.width}
                  onChange={(e) => onUpdateConfig({ width: Number(e.target.value) })}
                  className="w-full h-1.5 bg-[#2C2E33] rounded-lg appearance-none cursor-pointer accent-[#3B82F6]"
                />
                <div className="flex justify-between text-[9px] text-gray-500 font-mono">
                  <span>600mm</span>
                  <span>1200mm</span>
                  <span>2400mm</span>
                  <span>3600mm</span>
                </div>
              </div>

              {/* Height Slider + Number Input */}
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <label className="text-[10px] text-gray-400 uppercase font-medium">Height</label>
                  <span className="text-blue-400 font-bold font-mono">{config.height} mm</span>
                </div>
                <input
                  id="input_param_height"
                  type="range"
                  min="600"
                  max="2800"
                  step="50"
                  value={config.height}
                  onChange={(e) => onUpdateConfig({ height: Number(e.target.value) })}
                  className="w-full h-1.5 bg-[#2C2E33] rounded-lg appearance-none cursor-pointer accent-[#3B82F6]"
                />
                <div className="flex justify-between text-[9px] text-gray-500 font-mono">
                  <span>600mm</span>
                  <span>1400mm</span>
                  <span>2200mm</span>
                  <span>2800mm</span>
                </div>
              </div>

              {/* Depth Slider */}
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <label className="text-[10px] text-gray-400 uppercase font-medium">Depth</label>
                  <span className="text-blue-400 font-bold font-mono">{config.depth} mm</span>
                </div>
                <input
                  id="input_param_depth"
                  type="range"
                  min="300"
                  max="900"
                  step="25"
                  value={config.depth}
                  onChange={(e) => onUpdateConfig({ depth: Number(e.target.value) })}
                  className="w-full h-1.5 bg-[#2C2E33] rounded-lg appearance-none cursor-pointer accent-[#3B82F6]"
                />
                <div className="flex justify-between text-[9px] text-gray-500 font-mono">
                  <span>300mm</span>
                  <span>450mm</span>
                  <span>600mm</span>
                  <span>900mm</span>
                </div>
              </div>
            </div>

            {/* Construction Rules & Panel Thickness */}
            <div className="p-3 bg-black/40 border border-[#2C2E33] rounded-lg space-y-2.5">
              <div className="text-[10px] text-gray-400 font-bold uppercase tracking-wider flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-amber-400" /> Carcass & Plinth Specs
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[9px] text-gray-500 uppercase block font-medium">Carcass Thick</label>
                  <select
                    value={config.carcassThickness}
                    onChange={(e) => onUpdateConfig({ carcassThickness: Number(e.target.value) })}
                    className="w-full bg-[#1A1B1E] border border-[#2C2E33] rounded px-2 py-1 text-gray-200 text-xs focus:border-blue-500 focus:outline-none"
                  >
                    <option value={16}>16 mm (Standard)</option>
                    <option value={18}>18 mm (Heavy Duty)</option>
                    <option value={19}>19 mm (3/4 in)</option>
                    <option value={25}>25 mm (Architectural)</option>
                  </select>
                </div>

                <div>
                  <label className="text-[9px] text-gray-500 uppercase block font-medium">Back Panel</label>
                  <select
                    value={config.backPanelThickness}
                    onChange={(e) => onUpdateConfig({ backPanelThickness: Number(e.target.value) })}
                    className="w-full bg-[#1A1B1E] border border-[#2C2E33] rounded px-2 py-1 text-gray-200 text-xs focus:border-blue-500 focus:outline-none"
                  >
                    <option value={4}>4 mm MDF</option>
                    <option value={6}>6 mm Grooved HDF</option>
                    <option value={8}>8 mm Rigid</option>
                    <option value={18}>18 mm Solid Back</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[9px] text-gray-500 uppercase block font-medium">Plinth Height</label>
                  <input
                    type="number"
                    value={config.plinthHeight}
                    onChange={(e) => onUpdateConfig({ plinthHeight: Number(e.target.value) })}
                    className="w-full bg-[#1A1B1E] border border-[#2C2E33] rounded px-2 py-1 text-gray-200 text-xs focus:border-blue-500 focus:outline-none font-mono"
                  />
                </div>
                <div>
                  <label className="text-[9px] text-gray-500 uppercase block font-medium">Bays (Sections)</label>
                  <select
                    value={config.baysCount}
                    onChange={(e) => {
                      const count = Number(e.target.value);
                      onUpdateConfig({
                        baysCount: count,
                        shelvesPerBay: Array(count).fill(3),
                        doorBays: Array.from({ length: count }, (_, i) => i),
                      });
                    }}
                    className="w-full bg-[#1A1B1E] border border-[#2C2E33] rounded px-2 py-1 text-gray-200 text-xs focus:border-blue-500 focus:outline-none"
                  >
                    <option value={1}>1 Bay (Single)</option>
                    <option value={2}>2 Bays (Dual)</option>
                    <option value={3}>3 Bays (Master)</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Joinery System Selector */}
            <div className="p-3 bg-black/40 border border-[#2C2E33] rounded-lg space-y-2">
              <div className="text-[10px] text-gray-400 font-bold uppercase tracking-wider flex items-center gap-1.5">
                <Wrench className="w-3.5 h-3.5 text-gray-300" /> Joinery & Fastening System
              </div>
              <select
                value={config.jointType}
                onChange={(e) => onUpdateConfig({ jointType: e.target.value as JointType })}
                className="w-full bg-[#1A1B1E] border border-[#2C2E33] rounded px-2 py-1.5 text-gray-200 text-xs focus:border-blue-500 focus:outline-none"
              >
                <option value="cam_lock_dowel">Häfele Minifix 15 + Hardwood Dowels</option>
                <option value="confirmat_screw">Confirmat 7×50mm Direct Screws</option>
                <option value="wood_dowel_only">Fluted Beech Dowels (Glued)</option>
                <option value="pocket_screw">Kreg Pocket Hole Fasteners</option>
                <option value="dado_groove">Milled Housing Dados & Rabbets</option>
              </select>
            </div>

            {/* Doors & Drawers Toggle */}
            <div className="p-3 bg-black/40 border border-[#2C2E33] rounded-lg space-y-3">
              <div className="text-[10px] text-gray-400 font-bold uppercase tracking-wider flex items-center gap-1.5">
                <Cpu className="w-3.5 h-3.5 text-emerald-400" /> Fronts & Hardware
              </div>

              {/* Doors Toggle & Opening Angle */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="flex items-center gap-2 text-gray-300 text-xs cursor-pointer">
                    <input
                      type="checkbox"
                      checked={config.hasDoors}
                      onChange={(e) => onUpdateConfig({ hasDoors: e.target.checked })}
                      className="rounded bg-[#1A1B1E] border-[#2C2E33] text-blue-500 focus:ring-0"
                    />
                    Enable Front Doors
                  </label>
                  {config.hasDoors && (
                    <span className="text-gray-400 text-[10px] font-mono">{config.doorOpeningAngle}° Swing</span>
                  )}
                </div>

                {config.hasDoors && (
                  <div className="pt-1">
                    <label className="text-[9px] text-gray-500 uppercase block">Door Swing Angle Preview</label>
                    <input
                      type="range"
                      min="0"
                      max="110"
                      value={config.doorOpeningAngle}
                      onChange={(e) => onUpdateConfig({ doorOpeningAngle: Number(e.target.value) })}
                      className="w-full h-1 bg-[#2C2E33] rounded appearance-none cursor-pointer accent-emerald-500"
                    />
                  </div>
                )}
              </div>

              {/* Drawers Toggle */}
              <div className="space-y-1.5 pt-2 border-t border-[#2C2E33]">
                <div className="flex items-center justify-between">
                  <label className="flex items-center gap-2 text-gray-300 text-xs cursor-pointer">
                    <input
                      type="checkbox"
                      checked={config.hasDrawers}
                      onChange={(e) => onUpdateConfig({ hasDrawers: e.target.checked })}
                      className="rounded bg-[#1A1B1E] border-[#2C2E33] text-blue-500 focus:ring-0"
                    />
                    Interior Drawer Stack
                  </label>
                  {config.hasDrawers && (
                    <select
                      value={config.drawersCount}
                      onChange={(e) => onUpdateConfig({ drawersCount: Number(e.target.value) })}
                      className="bg-[#1A1B1E] border border-[#2C2E33] rounded px-1.5 py-0.5 text-gray-200 text-[10px]"
                    >
                      <option value={2}>2 Drawers</option>
                      <option value={3}>3 Drawers</option>
                      <option value={4}>4 Drawers</option>
                    </select>
                  )}
                </div>
              </div>
            </div>

            {/* Material Swapper */}
            <div className="p-3 bg-black/40 border border-[#2C2E33] rounded-lg space-y-2">
              <div className="text-[10px] text-gray-400 font-bold uppercase tracking-wider flex items-center gap-1.5">
                <Palette className="w-3.5 h-3.5 text-blue-400" /> Primary Carcass Material
              </div>
              <div className="grid grid-cols-2 gap-1.5">
                {MATERIALS_DATABASE.slice(0, 6).map((mat) => (
                  <button
                    key={mat.id}
                    onClick={() =>
                      onUpdateConfig({
                        defaultCarcassMaterialId: mat.id,
                        defaultFrontMaterialId: mat.id,
                      })
                    }
                    className={`flex items-center gap-1.5 p-1.5 rounded border text-left text-[10px] transition-colors ${
                      config.defaultCarcassMaterialId === mat.id
                        ? 'border-blue-500 bg-blue-950/40 text-blue-200'
                        : 'border-[#2C2E33] hover:bg-[#222328] text-gray-400'
                    }`}
                  >
                    <span className="w-3.5 h-3.5 rounded-sm shrink-0" style={{ backgroundColor: mat.color }} />
                    <span className="truncate">{mat.name.split('(')[0]}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Design Variants Selector */}
            <div className="p-3 bg-black/40 border border-[#2C2E33] rounded-lg space-y-2">
              <div className="text-[10px] text-gray-400 font-bold uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" /> Design Variants
              </div>
              <div className="space-y-1">
                {project.variants.map((v) => (
                  <button
                    key={v.id}
                    onClick={() => onApplyVariant(v.id)}
                    className={`w-full text-left p-2 rounded border text-[10px] transition-colors ${
                      project.activeVariantId === v.id
                        ? 'border-blue-500 bg-blue-950/50 text-blue-200 font-bold'
                        : 'border-[#2C2E33] hover:bg-[#222328] text-gray-400'
                    }`}
                  >
                    <div className="text-gray-200 font-medium">{v.name}</div>
                    <div className="text-[9px] text-gray-500">{v.description}</div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Footer Info */}
      <div className="p-2.5 bg-[#1A1B1E] border-t border-[#2C2E33] text-[10px] text-gray-400 flex items-center justify-between font-mono">
        <span>Parametric Engine</span>
        <span className="text-emerald-400 flex items-center gap-1">
          <CheckCircle2 className="w-3 h-3" /> DRC Online
        </span>
      </div>
    </div>
  );
}
