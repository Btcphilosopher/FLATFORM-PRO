'use client';

import React from 'react';
import { Box, Code2, Cpu, Keyboard, Layers, X } from 'lucide-react';

interface HelpModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function HelpModal({ isOpen, onClose }: HelpModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 font-mono text-xs select-none">
      <div className="w-full max-w-2xl bg-[#14171e] border border-[#2d3545] rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 bg-[#181c25] border-b border-[#242b38]">
          <div className="flex items-center gap-2">
            <Box className="w-4 h-4 text-blue-400" />
            <span className="font-bold text-zinc-100 text-sm">
              FLATFORM PRO — Engineering Guide & Quick Keys
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-zinc-400 hover:text-white rounded hover:bg-[#232936]"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-4 space-y-4 overflow-y-auto">
          {/* Section 1: 3D Viewport Controls */}
          <div className="space-y-2">
            <div className="text-blue-400 font-bold uppercase tracking-wider flex items-center gap-1.5 text-[11px]">
              <Keyboard className="w-3.5 h-3.5" /> 3D CAD Navigation & Mouse Controls
            </div>
            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <div className="p-2 bg-[#181c26] border border-[#272f3f] rounded flex justify-between">
                <span className="text-zinc-400">Orbit / Rotate</span>
                <span className="font-bold text-zinc-200">Left Click + Drag</span>
              </div>
              <div className="p-2 bg-[#181c26] border border-[#272f3f] rounded flex justify-between">
                <span className="text-zinc-400">Pan View</span>
                <span className="font-bold text-zinc-200">Right Click OR Shift + Drag</span>
              </div>
              <div className="p-2 bg-[#181c26] border border-[#272f3f] rounded flex justify-between">
                <span className="text-zinc-400">Zoom In / Out</span>
                <span className="font-bold text-zinc-200">Mouse Scroll Wheel</span>
              </div>
              <div className="p-2 bg-[#181c26] border border-[#272f3f] rounded flex justify-between">
                <span className="text-zinc-400">Select Component</span>
                <span className="font-bold text-zinc-200">Direct Click on Panel</span>
              </div>
            </div>
          </div>

          {/* Section 2: Parametric Architecture */}
          <div className="space-y-2">
            <div className="text-amber-400 font-bold uppercase tracking-wider flex items-center gap-1.5 text-[11px]">
              <Cpu className="w-3.5 h-3.5" /> Parametric Engineering Engine
            </div>
            <p className="text-zinc-300 leading-relaxed text-[11px]">
              FLATFORM PRO employs a non-destructive parametric constraint engine. Any dimension
              change (e.g. Width from 2400 to 2800 mm) immediately propagates through the mathematical
              matrix to recalculate:
            </p>
            <ul className="list-disc list-inside text-zinc-400 text-[11px] space-y-1 pl-1">
              <li>Exact panel bounding boxes (width, height, thickness)</li>
              <li>Cabinet joinery locations (System 32 Minifix cam-locks & dowels)</li>
              <li>Door swing clearances and drawer front gap calculations</li>
              <li>Live Design Rule Checks (DRC) preventing structural sagging or collisions</li>
              <li>2D Sheet nesting optimization, total yield percentage, and BOM cost estimates</li>
            </ul>
          </div>

          {/* Section 3: Kotlin / Compose Desktop Architecture */}
          <div className="space-y-2">
            <div className="text-cyan-400 font-bold uppercase tracking-wider flex items-center gap-1.5 text-[11px]">
              <Code2 className="w-3.5 h-3.5" /> Kotlin / Compose Multiplatform Desktop Codebase
            </div>
            <p className="text-zinc-300 text-[11px] leading-relaxed">
              Included in the project is a production-ready Kotlin 2.0 / Compose Multiplatform desktop
              architecture adhering to Clean Architecture (MVI / StateFlow / Domain Models). You can
              inspect the raw Kotlin source code and export a ready-to-build Gradle project bundle via the
              top <strong className="text-cyan-300">File &gt; Download Kotlin Project (.ZIP)</strong> menu!
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 bg-[#181c25] border-t border-[#242b38] flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded text-xs font-semibold transition-colors"
          >
            Got It
          </button>
        </div>
      </div>
    </div>
  );
}
