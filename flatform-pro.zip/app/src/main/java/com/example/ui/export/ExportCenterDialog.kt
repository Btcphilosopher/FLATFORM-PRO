package com.example.ui.export

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.domain.model.FurnitureProject
import com.example.ui.theme.*

@Composable
fun ExportCenterDialog(
    project: FurnitureProject,
    onDismiss: () -> Unit,
    onShowSnackbar: (String) -> Unit
) {
    var selectedFormat by remember { mutableStateOf("GCODE") }
    var includeDrillings by remember { mutableStateOf(true) }
    var includeEdgeBanding by remember { mutableStateOf(true) }
    var isExporting by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .width(520.dp)
                .border(1.dp, CadAccentBlue, RoundedCornerShape(12.dp))
                .testTag("export_center_dialog"),
            colors = CardDefaults.cardColors(containerColor = CadSurface),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.Download, contentDescription = null, tint = CadAccentBlue, modifier = Modifier.size(22.dp))
                        Text("PRODUCTION EXPORT CENTER", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = CadTextPrimary)
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = CadTextSecondary, modifier = Modifier.size(18.dp))
                    }
                }

                Text(
                    text = "Generate CAM/CNC machine code, nesting cut sheets, and enterprise BOM packages.",
                    fontSize = 11.sp,
                    color = CadTextSecondary
                )

                Divider(color = CadBorder)

                // Format Cards Grid
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Select Target Output Format:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CadTextSecondary)

                    ExportFormatRow(
                        title = "CNC Machine G-Code (.nc / .iso / .mpr)",
                        desc = "Pre-configured for Homag, Biesse, SCM flatbed routers",
                        icon = Icons.Default.PrecisionManufacturing,
                        isSelected = selectedFormat == "GCODE",
                        onClick = { selectedFormat = "GCODE" }
                    )

                    ExportFormatRow(
                        title = "AutoCAD 2D / 3D DXF Polylines (.dxf)",
                        desc = "Layered drillings (DRILL_5MM, DRILL_35MM, POCKET_15MM)",
                        icon = Icons.Default.Architecture,
                        isSelected = selectedFormat == "DXF",
                        onClick = { selectedFormat = "DXF" }
                    )

                    ExportFormatRow(
                        title = "Manufacturing BOM & Cut-List (.csv / .xlsx)",
                        desc = "Full ERP pricing, panel areas, edge banding linear meters",
                        icon = Icons.Default.TableChart,
                        isSelected = selectedFormat == "CSV",
                        onClick = { selectedFormat = "CSV" }
                    )

                    ExportFormatRow(
                        title = "Native Project File (.flatform)",
                        desc = "Full parametric schema with variant snapshot & history",
                        icon = Icons.Default.Code,
                        isSelected = selectedFormat == "FLATFORM",
                        onClick = { selectedFormat = "FLATFORM" }
                    )
                }

                // Options Checkboxes
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = includeDrillings,
                            onCheckedChange = { includeDrillings = it },
                            colors = CheckboxDefaults.colors(checkedColor = CadAccentBlue)
                        )
                        Text("Include System 32 Boring", fontSize = 11.sp, color = CadTextPrimary)
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = includeEdgeBanding,
                            onCheckedChange = { includeEdgeBanding = it },
                            colors = CheckboxDefaults.colors(checkedColor = CadAccentBlue)
                        )
                        Text("Include Edge Tape Codes", fontSize = 11.sp, color = CadTextPrimary)
                    }
                }

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel", color = CadTextSecondary)
                    }
                    Spacer(Modifier.width(8.dp))
                    Button(
                        onClick = {
                            isExporting = true
                            onShowSnackbar("Successfully exported package for ${project.name} ($selectedFormat format).")
                            onDismiss()
                        },
                        shape = RoundedCornerShape(6.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = CadAccentBlue, contentColor = Color.Black),
                        modifier = Modifier.testTag("btn_confirm_export")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                            Text("Download Package", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ExportFormatRow(
    title: String,
    desc: String,
    icon: ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(8.dp),
        color = if (isSelected) CadAccentBlue.copy(alpha = 0.15f) else CadSurfaceVariant,
        border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) CadAccentBlue else CadBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(icon, contentDescription = null, tint = if (isSelected) CadAccentBlue else CadTextSecondary, modifier = Modifier.size(20.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = if (isSelected) CadAccentBlue else CadTextPrimary)
                Text(desc, fontSize = 10.sp, color = CadTextMuted)
            }
            if (isSelected) {
                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = CadAccentBlue, modifier = Modifier.size(16.dp))
            }
        }
    }
}
