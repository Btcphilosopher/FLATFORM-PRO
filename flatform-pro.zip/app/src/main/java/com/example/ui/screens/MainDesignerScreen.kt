package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.materials.MaterialLibrary
import com.example.domain.model.WarningSeverity
import com.example.ui.assembly.AssemblyPlannerScreen
import com.example.ui.export.ExportCenterDialog
import com.example.ui.manufacturing.ManufacturingOverviewScreen
import com.example.ui.panels.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.*
import com.example.ui.viewport.Engineering2DView
import com.example.ui.viewport.MeasurementToolDialog
import com.example.ui.viewport.Viewport3D

@Composable
fun MainDesignerScreen(
    viewModel: DesignerViewModel,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsState()
    val project = state.activeProject
    val selectedComp = project.components.find { it.id == state.selectedComponentId }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(CadBackground)
            .testTag("main_designer_screen")
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // 1. EDITORIAL TOP HEADER
            EditorialTopHeader(
                projectTitle = project.name,
                onNavigateToDashboard = { viewModel.navigateToDashboard() },
                onOpenExportModal = { viewModel.openExportDialog() },
                onQuickSave = { viewModel.showSnackbar("Project '${project.name}' saved.") }
            )

            // 2. EDITORIAL PILL NAVIGATION BAR
            EditorialPillNav(
                activeMode = state.activeMode,
                onSelectMode = { viewModel.setWorkspaceMode(it) }
            )

            HorizontalDivider(color = CadBorder)

            // 3. MAIN WORKSPACE BODY
            Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                when (state.activeMode) {
                    WorkspaceMode.CAD_3D_DESIGNER -> {
                        Row(modifier = Modifier.fillMaxSize()) {
                            // Slim Editorial Vertical CAD Toolstrip
                            EditorialVerticalToolbar(
                                activeTool = state.activeTool,
                                onSelectTool = { viewModel.setActiveTool(it) },
                                isLeftPanelOpen = state.isLeftPanelExpanded,
                                onToggleLeftPanel = { viewModel.toggleLeftPanel() },
                                activeLeftTab = state.activeLeftTab,
                                onSelectLeftTab = { viewModel.setLeftTab(it) }
                            )

                            // Left Column Panel (Collapsible Hierarchy / Materials / Hardware / Variants)
                            AnimatedVisibility(
                                visible = state.isLeftPanelExpanded,
                                enter = expandHorizontally(),
                                exit = shrinkHorizontally()
                            ) {
                                Box(
                                    modifier = Modifier
                                        .width(280.dp)
                                        .fillMaxHeight()
                                        .background(CadSurface)
                                        .border(1.dp, CadBorder)
                                ) {
                                    when (state.activeLeftTab) {
                                        LeftPanelTab.COMPONENT_TREE -> {
                                            ComponentTreePanel(
                                                project = project,
                                                selectedComponentId = state.selectedComponentId,
                                                onSelectComponent = { viewModel.selectComponent(it) },
                                                onToggleVisibility = { viewModel.toggleComponentVisibility(it) },
                                                onAddComponent = { viewModel.addComponentGroup(it) },
                                                onDeleteComponent = {}
                                            )
                                        }
                                        LeftPanelTab.MATERIALS -> {
                                            MaterialsCatalogPanel(
                                                selectedMaterialId = project.parameters.primaryMaterialId,
                                                onSelectMaterial = {
                                                    viewModel.updateParameters(project.parameters.copy(primaryMaterialId = it))
                                                },
                                                onApplyToAll = { viewModel.applyMaterialToProject(it) }
                                            )
                                        }
                                        LeftPanelTab.HARDWARE -> {
                                            HardwareCatalogPanel(project = project)
                                        }
                                        LeftPanelTab.VARIANTS_HISTORY -> {
                                            DesignHistoryAndVariantsPanel(
                                                project = project,
                                                historyStack = state.undoStack,
                                                canUndo = state.undoStack.isNotEmpty(),
                                                canRedo = state.redoStack.isNotEmpty(),
                                                onUndo = { viewModel.undo() },
                                                onRedo = { viewModel.redo() },
                                                onApplyVariant = { viewModel.applyVariant(it) }
                                            )
                                        }
                                    }
                                }
                            }

                            // Center 3D Viewport with Floating Editorial Badges
                            Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                                Viewport3D(
                                    project = project,
                                    selectedComponentId = state.selectedComponentId,
                                    onSelectComponent = { viewModel.selectComponent(it) },
                                    cameraState = state.cameraState,
                                    onUpdateCamera = { viewModel.updateCamera(it) },
                                    shadingMode = state.shadingMode,
                                    onShadingModeChange = { viewModel.setShadingMode(it) },
                                    explodedFactor = state.explodedFactor,
                                    onExplodedFactorChange = { viewModel.setExplodedFactor(it) },
                                    showDimensions = state.showDimensions,
                                    onToggleDimensions = { viewModel.toggleDimensions() },
                                    showHardware = state.showHardware,
                                    onToggleHardware = { viewModel.toggleHardware() },
                                    activeTool = state.activeTool,
                                    modifier = Modifier.fillMaxSize()
                                )

                                // Floating Editorial "Selected Component" Badge (Top-Left)
                                Surface(
                                    modifier = Modifier
                                        .align(Alignment.TopStart)
                                        .padding(14.dp),
                                    shape = RoundedCornerShape(10.dp),
                                    color = CadSurface.copy(alpha = 0.88f),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, CadBorder)
                                ) {
                                    Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                                        Text(
                                            text = "SELECTED COMPONENT",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            letterSpacing = 1.2.sp,
                                            color = CadTextMuted
                                        )
                                        Text(
                                            text = selectedComp?.name ?: "OVERALL CARCASS ENVELOPE",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            fontFamily = FontFamily.Monospace,
                                            color = CadAccentLavender
                                        )
                                    }
                                }

                                // Floating Editorial "Properties" Plum Overlay (Bottom-Right)
                                Surface(
                                    modifier = Modifier
                                        .align(Alignment.BottomEnd)
                                        .padding(14.dp)
                                        .width(170.dp),
                                    shape = RoundedCornerShape(16.dp),
                                    color = CadSurfacePlum,
                                    border = androidx.compose.foundation.BorderStroke(1.dp, CadBorder)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(12.dp),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = "PROPERTIES",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            letterSpacing = 1.5.sp,
                                            color = CadAccentLavender
                                        )
                                        PropertyRow("Width", "${project.parameters.widthMm.toInt()} mm")
                                        PropertyRow("Height", "${project.parameters.heightMm.toInt()} mm")
                                        PropertyRow("Depth", "${project.parameters.depthMm.toInt()} mm")
                                    }
                                }
                            }

                            // Right Column Panel (Collapsible Inspector / Live DRC Checks)
                            AnimatedVisibility(
                                visible = state.isRightPanelExpanded,
                                enter = expandHorizontally(expandFrom = Alignment.End),
                                exit = shrinkHorizontally(shrinkTowards = Alignment.End)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .width(320.dp)
                                        .fillMaxHeight()
                                        .background(CadSurface)
                                        .border(1.dp, CadBorder)
                                ) {
                                    when (state.activeRightTab) {
                                        RightPanelTab.PARAMETRIC_PROPERTIES -> {
                                            ParametricPropertiesPanel(
                                                project = project,
                                                selectedComponentId = state.selectedComponentId,
                                                onUpdateParameters = { viewModel.updateParameters(it) },
                                                onUpdateComponentEdge = { _, _ -> },
                                                onUpdateComponentJoint = { _, _ -> }
                                            )
                                        }
                                        RightPanelTab.DRC_VALIDATION -> {
                                            DesignValidationPanel(
                                                project = project,
                                                onAutoFixWarning = { viewModel.autoFixWarning(it) },
                                                onSelectComponent = { viewModel.selectComponent(it) }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    WorkspaceMode.DRAFTING_2D -> {
                        Engineering2DView(
                            project = project,
                            selectedComponentId = state.selectedComponentId,
                            onSelectComponent = { viewModel.selectComponent(it) },
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    WorkspaceMode.MANUFACTURING_CAM -> {
                        ManufacturingOverviewScreen(
                            project = project,
                            onOpenExportModal = { viewModel.openExportDialog() },
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    WorkspaceMode.ASSEMBLY_PLANNER -> {
                        AssemblyPlannerScreen(
                            project = project,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            }

            HorizontalDivider(color = CadBorder)

            // 4. EDITORIAL 4-COLUMN FOOTER NAVIGATION / STATUS
            EditorialFooterNav(
                activeMode = state.activeMode,
                onSelectMode = { viewModel.setWorkspaceMode(it) },
                warningsCount = project.warnings.count { it.severity == WarningSeverity.WARNING || it.severity == WarningSeverity.ERROR },
                isRightPanelOpen = state.isRightPanelExpanded,
                onToggleRightPanel = { viewModel.toggleRightPanel() },
                onSelectRightTab = { viewModel.setRightTab(it) }
            )
        }

        // Floating Precision Measurement Dialog
        if (state.isMeasureDialogOpen) {
            Box(modifier = Modifier.align(Alignment.Center).padding(16.dp)) {
                MeasurementToolDialog(
                    project = project,
                    selectedCompId = state.selectedComponentId,
                    onClose = { viewModel.closeMeasureDialog() }
                )
            }
        }

        // Export Center Modal Dialog
        if (state.isExportDialogOpen) {
            ExportCenterDialog(
                project = project,
                onDismiss = { viewModel.closeExportDialog() },
                onShowSnackbar = { viewModel.showSnackbar(it) }
            )
        }
    }
}

@Composable
private fun EditorialTopHeader(
    projectTitle: String,
    onNavigateToDashboard: () -> Unit,
    onOpenExportModal: () -> Unit,
    onQuickSave: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(CadSurface)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // App Title and Subheading
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            IconButton(
                onClick = onNavigateToDashboard,
                modifier = Modifier.size(36.dp).testTag("btn_back_dashboard")
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Dashboard", tint = CadTextSecondary, modifier = Modifier.size(18.dp))
            }

            Column {
                Text(
                    text = "FLATFORM PRO",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp,
                    color = CadAccentLavender
                )
                Text(
                    text = projectTitle,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = CadTextPrimary
                )
            }
        }

        // Circular Action Buttons (SAVE & + Export)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(
                onClick = onQuickSave,
                shape = CircleShape,
                color = CadSurfaceVariant,
                modifier = Modifier.size(38.dp).testTag("btn_header_save")
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text("SAVE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = CadTextPrimary)
                }
            }

            Surface(
                onClick = onOpenExportModal,
                shape = CircleShape,
                color = CadAccentLavender,
                modifier = Modifier.size(38.dp).testTag("btn_header_export")
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text("+", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFF381E72))
                }
            }
        }
    }
}

@Composable
private fun EditorialPillNav(
    activeMode: WorkspaceMode,
    onSelectMode: (WorkspaceMode) -> Unit
) {
    val scrollState = rememberScrollState()

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(CadSurface)
            .horizontalScroll(scrollState)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val modes = listOf(
            WorkspaceMode.CAD_3D_DESIGNER to "3D View",
            WorkspaceMode.DRAFTING_2D to "2D Plan",
            WorkspaceMode.MANUFACTURING_CAM to "BOM & CAM",
            WorkspaceMode.ASSEMBLY_PLANNER to "Assembly Guide"
        )

        modes.forEach { (mode, label) ->
            val isSel = activeMode == mode
            Surface(
                onClick = { onSelectMode(mode) },
                shape = CircleShape,
                color = if (isSel) CadPillActive else Color.Transparent,
                modifier = Modifier.testTag("nav_pill_${mode.name.lowercase()}")
            ) {
                Text(
                    text = label,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = if (isSel) CadTextPrimary else CadTextSecondary,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                )
            }
        }
    }
}

@Composable
private fun EditorialVerticalToolbar(
    activeTool: String,
    onSelectTool: (String) -> Unit,
    isLeftPanelOpen: Boolean,
    onToggleLeftPanel: () -> Unit,
    activeLeftTab: LeftPanelTab,
    onSelectLeftTab: (LeftPanelTab) -> Unit
) {
    Column(
        modifier = Modifier
            .width(52.dp)
            .fillMaxHeight()
            .background(CadSurface)
            .border(1.dp, CadBorder)
            .padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        EditorialToolButton("SEL", isSelected = activeTool == "select", onClick = { onSelectTool("select") })
        EditorialToolButton("MS", isSelected = false, onClick = { onSelectTool("measure") })
        EditorialToolButton("ROT", isSelected = activeTool == "orbit", onClick = { onSelectTool("orbit") })
        EditorialToolButton("PAN", isSelected = activeTool == "pan", onClick = { onSelectTool("pan") })

        Spacer(modifier = Modifier.weight(1f))

        // Layers / Hierarchy panel toggle
        Surface(
            onClick = {
                if (isLeftPanelOpen) onToggleLeftPanel() else {
                    onSelectLeftTab(LeftPanelTab.COMPONENT_TREE)
                }
            },
            shape = RoundedCornerShape(4.dp),
            color = if (isLeftPanelOpen) CadSurfaceVariant else Color.Transparent,
            modifier = Modifier.size(32.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text("LAY", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (isLeftPanelOpen) CadAccentLavender else CadTextMuted)
            }
        }
    }
}

@Composable
private fun EditorialToolButton(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(4.dp),
        color = if (isSelected) CadAccentLavender.copy(alpha = 0.15f) else Color.Transparent,
        border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, CadAccentLavender) else null,
        modifier = Modifier.size(32.dp)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                text = label,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = if (isSelected) CadAccentLavender else CadTextSecondary
            )
        }
    }
}

@Composable
private fun PropertyRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, fontSize = 10.sp, color = CadTextMuted)
        Text(value, fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = CadTextPrimary)
    }
}

@Composable
private fun EditorialFooterNav(
    activeMode: WorkspaceMode,
    onSelectMode: (WorkspaceMode) -> Unit,
    warningsCount: Int,
    isRightPanelOpen: Boolean,
    onToggleRightPanel: () -> Unit,
    onSelectRightTab: (RightPanelTab) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
            .background(CadSurface),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        FooterItem(
            label = "DESIGN",
            isSelected = activeMode == WorkspaceMode.CAD_3D_DESIGNER,
            onClick = { onSelectMode(WorkspaceMode.CAD_3D_DESIGNER) }
        )
        FooterItem(
            label = "ENGINEER",
            isSelected = activeMode == WorkspaceMode.DRAFTING_2D,
            onClick = { onSelectMode(WorkspaceMode.DRAFTING_2D) }
        )
        FooterItem(
            label = "MANUFACT",
            isSelected = activeMode == WorkspaceMode.MANUFACTURING_CAM,
            onClick = { onSelectMode(WorkspaceMode.MANUFACTURING_CAM) }
        )
        FooterItem(
            label = "ERRORS",
            isSelected = isRightPanelOpen,
            badgeCount = warningsCount,
            isErrorTab = true,
            onClick = {
                onSelectRightTab(RightPanelTab.DRC_VALIDATION)
            }
        )
    }
}

@Composable
private fun RowScope.FooterItem(
    label: String,
    isSelected: Boolean,
    badgeCount: Int = 0,
    isErrorTab: Boolean = false,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .weight(1f)
            .fillMaxHeight()
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(20.dp)
                    .border(
                        1.5.dp,
                        if (isErrorTab && badgeCount > 0) CadAccentRed else if (isSelected) CadAccentLavender else CadTextSecondary,
                        RoundedCornerShape(3.dp)
                    )
            )
            Text(
                text = label,
                fontSize = 9.sp,
                fontWeight = FontWeight.Medium,
                color = if (isErrorTab && badgeCount > 0) CadAccentRed else if (isSelected) CadAccentLavender else CadTextSecondary
            )
        }

        if (badgeCount > 0 && isErrorTab) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .offset(x = 18.dp, y = 6.dp)
                    .size(8.dp)
                    .background(Color(0xFFB3261E), CircleShape)
            )
        }
    }
}
