'use client';

import React, { useState } from 'react';
import { FurnitureComponent, FurnitureProject } from '@/types/furniture';

interface Technical2DDrawingProps {
  project: FurnitureProject;
  selectedComponentId: string | null;
  onSelectComponent: (id: string | null) => void;
}

type ProjectionView = 'front' | 'rear' | 'left' | 'right' | 'top' | 'bottom';

export function Technical2DDrawing({
  project,
  selectedComponentId,
  onSelectComponent,
}: Technical2DDrawingProps) {
  const [activeView, setActiveView] = useState<ProjectionView>('front');
  const [showCenterlines, setShowCenterlines] = useState(true);
  const [showHoles, setShowHoles] = useState(true);
  const [zoomLevel, setZoomLevel] = useState(1);

  const { config, components } = project;
  const { width: W, height: H, depth: D, carcassThickness: t, plinthHeight: plinth } = config;

  // Viewport dimensions for SVG scale
  const svgWidth = 800;
  const svgHeight = 600;
  const padding = 80;

  // Determine active view bounding box (width & height in 2D projection)
  let projWidth = W;
  let projHeight = H;

  if (activeView === 'left' || activeView === 'right') {
    projWidth = D;
    projHeight = H;
  } else if (activeView === 'top' || activeView === 'bottom') {
    projWidth = W;
    projHeight = D;
  }

  // Scale to fit canvas
  const scale = Math.min((svgWidth - padding * 2) / projWidth, (svgHeight - padding * 2) / projHeight) * zoomLevel;
  const originX = svgWidth / 2 - (projWidth * scale) / 2;
  const originY = svgHeight / 2 + (projHeight * scale) / 2;

  // Transform model coordinate (X, Y in mm) to SVG pixel coordinate
  const toSvgCoords = (xMm: number, yMm: number) => {
    return {
      x: originX + xMm * scale,
      y: originY - yMm * scale,
    };
  };

  return (
    <div id="technical_2d_drawing_container" className="relative w-full h-full bg-[#101216] flex flex-col font-mono select-none">
      {/* Top Technical Header Controls */}
      <div className="flex items-center justify-between px-4 py-2 bg-[#171a21] border-b border-[#262c38] text-xs">
        <div className="flex items-center gap-2">
          <span className="text-zinc-400 font-bold uppercase text-[11px] tracking-wider">
            2D CAD Projection:
          </span>
          {(['front', 'rear', 'left', 'right', 'top', 'bottom'] as ProjectionView[]).map((v) => (
            <button
              key={v}
              id={`btn_2d_view_${v}`}
              onClick={() => setActiveView(v)}
              className={`px-2.5 py-1 rounded text-[11px] uppercase font-medium transition-colors ${
                activeView === v
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'bg-[#212631] text-zinc-400 hover:text-white hover:bg-[#2c3342]'
              }`}
            >
              {v}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-3">
          <label className="flex items-center gap-1.5 text-zinc-300 text-[11px] cursor-pointer">
            <input
              type="checkbox"
              checked={showCenterlines}
              onChange={(e) => setShowCenterlines(e.target.checked)}
              className="rounded bg-zinc-800 border-zinc-600 text-blue-600 focus:ring-0"
            />
            Centerlines (CL)
          </label>

          <label className="flex items-center gap-1.5 text-zinc-300 text-[11px] cursor-pointer">
            <input
              type="checkbox"
              checked={showHoles}
              onChange={(e) => setShowHoles(e.target.checked)}
              className="rounded bg-zinc-800 border-zinc-600 text-blue-600 focus:ring-0"
            />
            Drill Holes & Slots
          </label>

          <div className="flex items-center gap-1 bg-[#212631] rounded p-0.5 border border-[#2e3646]">
            <button
              onClick={() => setZoomLevel((z) => Math.max(0.6, z - 0.1))}
              className="px-2 py-0.5 text-zinc-400 hover:text-white"
            >
              -
            </button>
            <span className="text-[10px] text-zinc-300 w-10 text-center">
              {Math.round(zoomLevel * 100)}%
            </span>
            <button
              onClick={() => setZoomLevel((z) => Math.min(2.5, z + 0.1))}
              className="px-2 py-0.5 text-zinc-400 hover:text-white"
            >
              +
            </button>
          </div>
        </div>
      </div>

      {/* SVG CAD Drawing Canvas */}
      <div className="flex-1 flex items-center justify-center p-4 overflow-auto">
        <svg
          viewBox={`0 0 ${svgWidth} ${svgHeight}`}
          className="w-full h-full max-w-4xl max-h-[600px] border border-[#222834] bg-[#0d0f13] rounded-lg shadow-2xl"
        >
          {/* Blueprint Grid Lines */}
          <defs>
            <pattern id="cadGrid" width="20" height="20" patternUnits="userSpaceOnUse">
              <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#181c24" strokeWidth="0.5" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#cadGrid)" />

          {/* Render 2D Components for Front/Rear View */}
          {(activeView === 'front' || activeView === 'rear') && (
            <g id="svg_projection_front">
              {/* Outer Carcass Boundary */}
              <rect
                x={toSvgCoords(0, H).x}
                y={toSvgCoords(0, H).y}
                width={W * scale}
                height={H * scale}
                fill="none"
                stroke="#3b82f6"
                strokeWidth="1.5"
                strokeDasharray="4 2"
                opacity="0.3"
              />

              {/* Left Side Panel */}
              <rect
                x={toSvgCoords(0, H).x}
                y={toSvgCoords(0, H).y}
                width={t * scale}
                height={(H - plinth) * scale}
                fill="#202530"
                stroke="#60a5fa"
                strokeWidth="1.2"
                className="cursor-pointer hover:fill-blue-900/40 transition-colors"
                onClick={() => onSelectComponent('comp_side_left')}
              />

              {/* Right Side Panel */}
              <rect
                x={toSvgCoords(W - t, H).x}
                y={toSvgCoords(W - t, H).y}
                width={t * scale}
                height={(H - plinth) * scale}
                fill="#202530"
                stroke="#60a5fa"
                strokeWidth="1.2"
                className="cursor-pointer hover:fill-blue-900/40 transition-colors"
                onClick={() => onSelectComponent('comp_side_right')}
              />

              {/* Top Panel */}
              <rect
                x={toSvgCoords(t, H).x}
                y={toSvgCoords(t, H).y}
                width={(W - 2 * t) * scale}
                height={t * scale}
                fill="#1e232e"
                stroke="#60a5fa"
                strokeWidth="1.2"
                className="cursor-pointer hover:fill-blue-900/40 transition-colors"
                onClick={() => onSelectComponent('comp_top_panel')}
              />

              {/* Bottom Panel */}
              <rect
                x={toSvgCoords(t, plinth + t).x}
                y={toSvgCoords(t, plinth + t).y}
                width={(W - 2 * t) * scale}
                height={t * scale}
                fill="#1e232e"
                stroke="#60a5fa"
                strokeWidth="1.2"
                className="cursor-pointer hover:fill-blue-900/40 transition-colors"
                onClick={() => onSelectComponent('comp_bottom_panel')}
              />

              {/* Plinth */}
              {plinth > 0 && (
                <rect
                  x={toSvgCoords(t, plinth).x}
                  y={toSvgCoords(t, plinth).y}
                  width={(W - 2 * t) * scale}
                  height={plinth * scale}
                  fill="#181b22"
                  stroke="#475569"
                  strokeWidth="1"
                />
              )}

              {/* Vertical Divider Partitions */}
              {config.baysCount > 1 &&
                Array.from({ length: config.baysCount - 1 }).map((_, pIdx) => {
                  const bayW = (W - 2 * t - (config.baysCount - 1) * t) / config.baysCount;
                  const px = t + (pIdx + 1) * bayW + pIdx * t;
                  return (
                    <rect
                      key={pIdx}
                      x={toSvgCoords(px, H - t).x}
                      y={toSvgCoords(px, H - t).y}
                      width={t * scale}
                      height={(H - plinth - 2 * t) * scale}
                      fill="#252a36"
                      stroke="#94a3b8"
                      strokeWidth="1"
                    />
                  );
                })}

              {/* Shelves */}
              {components
                .filter((c) => c.category === 'interior')
                .map((shelf) => {
                  const xMm = shelf.position.x + W / 2 - shelf.dimensions.width / 2;
                  const yMm = shelf.position.y + shelf.dimensions.height / 2;
                  return (
                    <g key={shelf.id}>
                      <rect
                        x={toSvgCoords(xMm, yMm).x}
                        y={toSvgCoords(xMm, yMm).y}
                        width={shelf.dimensions.width * scale}
                        height={shelf.dimensions.height * scale}
                        fill="#2a303e"
                        stroke="#94a3b8"
                        strokeWidth="0.8"
                        strokeDasharray={shelf.type === 'shelf_adjustable' ? '2 1' : 'none'}
                        className="cursor-pointer hover:fill-blue-800/40"
                        onClick={() => onSelectComponent(shelf.id)}
                      />
                    </g>
                  );
                })}

              {/* Drill Holes (Hinges / Pins) */}
              {showHoles && (
                <g id="svg_drill_holes">
                  {/* Left Side Shelf Pin System-32 column */}
                  {Array.from({ length: 8 }).map((_, i) => (
                    <circle
                      key={`lh_${i}`}
                      cx={toSvgCoords(t + 25, plinth + t + 100 + i * 64).x}
                      cy={toSvgCoords(t + 25, plinth + t + 100 + i * 64).y}
                      r={2.5}
                      fill="#38bdf8"
                      stroke="#0284c7"
                      strokeWidth="0.5"
                    />
                  ))}
                  {/* Right Side Shelf Pin column */}
                  {Array.from({ length: 8 }).map((_, i) => (
                    <circle
                      key={`rh_${i}`}
                      cx={toSvgCoords(W - t - 25, plinth + t + 100 + i * 64).x}
                      cy={toSvgCoords(W - t - 25, plinth + t + 100 + i * 64).y}
                      r={2.5}
                      fill="#38bdf8"
                      stroke="#0284c7"
                      strokeWidth="0.5"
                    />
                  ))}
                </g>
              )}

              {/* Centerlines (CL) */}
              {showCenterlines && (
                <g id="svg_centerlines" opacity="0.6">
                  {/* Vertical Symmetrical Axis */}
                  <line
                    x1={toSvgCoords(W / 2, H + 30).x}
                    y1={toSvgCoords(W / 2, H + 30).y}
                    x2={toSvgCoords(W / 2, -30).x}
                    y2={toSvgCoords(W / 2, -30).y}
                    stroke="#ef4444"
                    strokeWidth="0.8"
                    strokeDasharray="12 3 3 3"
                  />
                  <text
                    x={toSvgCoords(W / 2, H + 45).x}
                    y={toSvgCoords(W / 2, H + 45).y}
                    fill="#ef4444"
                    fontSize="9"
                    textAnchor="middle"
                  >
                    ℄
                  </text>
                </g>
              )}

              {/* Dimension Annotations with CAD Leader Lines & Ticks */}
              {/* Overall Width (Top) */}
              <g id="svg_dim_width">
                <line
                  x1={toSvgCoords(0, H + 35).x}
                  y1={toSvgCoords(0, H + 35).y}
                  x2={toSvgCoords(W, H + 35).x}
                  y2={toSvgCoords(W, H + 35).y}
                  stroke="#38bdf8"
                  strokeWidth="1"
                />
                {/* Left Tick */}
                <line
                  x1={toSvgCoords(0, H + 30).x}
                  y1={toSvgCoords(0, H + 30).y}
                  x2={toSvgCoords(0, H + 40).x}
                  y2={toSvgCoords(0, H + 40).y}
                  stroke="#38bdf8"
                  strokeWidth="1.5"
                />
                {/* Right Tick */}
                <line
                  x1={toSvgCoords(W, H + 30).x}
                  y1={toSvgCoords(W, H + 30).y}
                  x2={toSvgCoords(W, H + 40).x}
                  y2={toSvgCoords(W, H + 40).y}
                  stroke="#38bdf8"
                  strokeWidth="1.5"
                />
                {/* Leader Extension Lines */}
                <line
                  x1={toSvgCoords(0, H).x}
                  y1={toSvgCoords(0, H).y}
                  x2={toSvgCoords(0, H + 45).x}
                  y2={toSvgCoords(0, H + 45).y}
                  stroke="#475569"
                  strokeWidth="0.75"
                />
                <line
                  x1={toSvgCoords(W, H).x}
                  y1={toSvgCoords(W, H).y}
                  x2={toSvgCoords(W, H + 45).x}
                  y2={toSvgCoords(W, H + 45).y}
                  stroke="#475569"
                  strokeWidth="0.75"
                />
                {/* Text Badge */}
                <rect
                  x={toSvgCoords(W / 2, H + 35).x - 30}
                  y={toSvgCoords(W / 2, H + 35).y - 8}
                  width="60"
                  height="16"
                  fill="#0d0f13"
                  stroke="#38bdf8"
                  strokeWidth="0.5"
                  rx="2"
                />
                <text
                  x={toSvgCoords(W / 2, H + 35).x}
                  y={toSvgCoords(W / 2, H + 35).y + 4}
                  fill="#38bdf8"
                  fontSize="11"
                  fontWeight="bold"
                  textAnchor="middle"
                >
                  {W} mm
                </text>
              </g>

              {/* Overall Height (Right Side) */}
              <g id="svg_dim_height">
                <line
                  x1={toSvgCoords(W + 35, H).x}
                  y1={toSvgCoords(W + 35, H).y}
                  x2={toSvgCoords(W + 35, 0).x}
                  y2={toSvgCoords(W + 35, 0).y}
                  stroke="#38bdf8"
                  strokeWidth="1"
                />
                {/* Top Tick */}
                <line
                  x1={toSvgCoords(W + 30, H).x}
                  y1={toSvgCoords(W + 30, H).y}
                  x2={toSvgCoords(W + 40, H).x}
                  y2={toSvgCoords(W + 40, H).y}
                  stroke="#38bdf8"
                  strokeWidth="1.5"
                />
                {/* Bottom Tick */}
                <line
                  x1={toSvgCoords(W + 30, 0).x}
                  y1={toSvgCoords(W + 30, 0).y}
                  x2={toSvgCoords(W + 40, 0).x}
                  y2={toSvgCoords(W + 40, 0).y}
                  stroke="#38bdf8"
                  strokeWidth="1.5"
                />
                {/* Extension Lines */}
                <line
                  x1={toSvgCoords(W, H).x}
                  y1={toSvgCoords(W, H).y}
                  x2={toSvgCoords(W + 45, H).x}
                  y2={toSvgCoords(W + 45, H).y}
                  stroke="#475569"
                  strokeWidth="0.75"
                />
                <line
                  x1={toSvgCoords(W, 0).x}
                  y1={toSvgCoords(W, 0).y}
                  x2={toSvgCoords(W + 45, 0).x}
                  y2={toSvgCoords(W + 45, 0).y}
                  stroke="#475569"
                  strokeWidth="0.75"
                />
                {/* Text Badge */}
                <rect
                  x={toSvgCoords(W + 35, H / 2).x - 30}
                  y={toSvgCoords(W + 35, H / 2).y - 8}
                  width="60"
                  height="16"
                  fill="#0d0f13"
                  stroke="#38bdf8"
                  strokeWidth="0.5"
                  rx="2"
                />
                <text
                  x={toSvgCoords(W + 35, H / 2).x}
                  y={toSvgCoords(W + 35, H / 2).y + 4}
                  fill="#38bdf8"
                  fontSize="11"
                  fontWeight="bold"
                  textAnchor="middle"
                >
                  {H} mm
                </text>
              </g>
            </g>
          )}

          {/* Render 2D Components for Left/Right Profile View */}
          {(activeView === 'left' || activeView === 'right') && (
            <g id="svg_projection_side">
              {/* Carcass Side Outline */}
              <rect
                x={toSvgCoords(0, H).x}
                y={toSvgCoords(0, H).y}
                width={D * scale}
                height={(H - plinth) * scale}
                fill="#202530"
                stroke="#60a5fa"
                strokeWidth="1.5"
              />

              {/* Back panel groove location */}
              <line
                x1={toSvgCoords(config.backPanelInset, H).x}
                y1={toSvgCoords(config.backPanelInset, H).y}
                x2={toSvgCoords(config.backPanelInset, plinth).x}
                y2={toSvgCoords(config.backPanelInset, plinth).y}
                stroke="#f59e0b"
                strokeWidth="1.2"
                strokeDasharray="4 2"
              />

              {/* Depth Dimension (Top) */}
              <g id="svg_dim_depth">
                <line
                  x1={toSvgCoords(0, H + 35).x}
                  y1={toSvgCoords(0, H + 35).y}
                  x2={toSvgCoords(D, H + 35).x}
                  y2={toSvgCoords(D, H + 35).y}
                  stroke="#38bdf8"
                  strokeWidth="1"
                />
                <rect
                  x={toSvgCoords(D / 2, H + 35).x - 26}
                  y={toSvgCoords(D / 2, H + 35).y - 8}
                  width="52"
                  height="16"
                  fill="#0d0f13"
                  stroke="#38bdf8"
                  strokeWidth="0.5"
                  rx="2"
                />
                <text
                  x={toSvgCoords(D / 2, H + 35).x}
                  y={toSvgCoords(D / 2, H + 35).y + 4}
                  fill="#38bdf8"
                  fontSize="11"
                  fontWeight="bold"
                  textAnchor="middle"
                >
                  {D} mm
                </text>
              </g>
            </g>
          )}

          {/* Render 2D Components for Top/Bottom Plan View */}
          {(activeView === 'top' || activeView === 'bottom') && (
            <g id="svg_projection_top">
              <rect
                x={toSvgCoords(0, D).x}
                y={toSvgCoords(0, D).y}
                width={W * scale}
                height={D * scale}
                fill="#202530"
                stroke="#60a5fa"
                strokeWidth="1.5"
              />
              <text
                x={toSvgCoords(W / 2, D / 2).x}
                y={toSvgCoords(W / 2, D / 2).y}
                fill="#94a3b8"
                fontSize="12"
                textAnchor="middle"
              >
                TOP STRUCTURAL VIEW: {W} × {D} mm
              </text>
            </g>
          )}

          {/* Engineering Title Block (Bottom Right CAD Stamp) */}
          <g id="cad_title_block" transform={`translate(${svgWidth - 240}, ${svgHeight - 75})`}>
            <rect width="230" height="65" fill="#14171e" stroke="#2e3646" strokeWidth="1" rx="3" />
            <text x="10" y="18" fill="#e2e8f0" fontSize="10" fontWeight="bold">
              {project.name}
            </text>
            <text x="10" y="32" fill="#94a3b8" fontSize="9">
              DRAWING NO: FLT-2026-001 | REV {project.version}
            </text>
            <text x="10" y="46" fill="#38bdf8" fontSize="8.5">
              PROJECTION: {activeView.toUpperCase()} ORTHOGRAPHIC
            </text>
            <text x="10" y="58" fill="#64748b" fontSize="8">
              SCALE: 1:{(1 / scale).toFixed(1)} | ALL DIMS IN MM
            </text>
          </g>
        </svg>
      </div>
    </div>
  );
}
