package com.example.domain.hardware

import com.example.domain.model.HardwareCategory
import com.example.domain.model.HardwareItem

object HardwareCatalog {
    val presets: List<HardwareItem> = listOf(
        HardwareItem(
            id = "hw_hinge_concealed",
            name = "Blum Clip Top 110° Soft-Close Hinge",
            category = HardwareCategory.HINGES,
            code = "BLUM-71B3550",
            quantity = 6,
            unitCost = 4.85f,
            mountingType = "Ø35mm Cup + Ø5mm Sys32 Plate",
            specs = "Full overlay, 110° opening, integrated BLUMOTION dampening"
        ),
        HardwareItem(
            id = "hw_drawer_slide_softclose",
            name = "Dynapro 450mm Soft-Close Undermount Slide",
            category = HardwareCategory.DRAWER_SLIDES,
            code = "GRASS-F130107",
            quantity = 3,
            unitCost = 16.50f,
            mountingType = "Side Carcass Screws Ø3.5×15mm",
            specs = "40kg load capacity, synchronized full extension, 3D adjustment"
        ),
        HardwareItem(
            id = "hw_cam_lock_dowel",
            name = "Titus Quickfit TL5 Cam & Dowel Set Ø15mm",
            category = HardwareCategory.CAM_LOCKS_DOWELS,
            code = "TITUS-EXP-15",
            quantity = 24,
            unitCost = 0.45f,
            mountingType = "Face Ø15×13.5mm / Edge Ø8×34mm",
            specs = "Expanding dowel for high vibration resistance and rapid flat-pack locking"
        ),
        HardwareItem(
            id = "hw_wooden_dowel",
            name = "FSC Beech Fluted Dowels 8×30mm",
            category = HardwareCategory.CAM_LOCKS_DOWELS,
            code = "DOW-8X30-FSC",
            quantity = 36,
            unitCost = 0.08f,
            mountingType = "Bored Hole Ø8×20mm depth",
            specs = "Fluted longitudinal channels for optimal glue retention and precision alignment"
        ),
        HardwareItem(
            id = "hw_confirmat_screw",
            name = "Heco Confirmat Carcass Screws 7×50mm",
            category = HardwareCategory.CONNECTORS_SCREWS,
            code = "CONF-7X50-ZN",
            quantity = 20,
            unitCost = 0.22f,
            mountingType = "Step Bored Hole Ø5/Ø7mm, SW4 Drive",
            specs = "High tensile direct-wood structural connection"
        ),
        HardwareItem(
            id = "hw_handle_bar_black",
            name = "Precision Architectural Bar Pull 160mm",
            category = HardwareCategory.HANDLES_KNOBS,
            code = "ARCH-BP-160-MB",
            quantity = 5,
            unitCost = 7.20f,
            mountingType = "Through Hole 2× Ø4.5mm @ 160mm CC",
            specs = "Solid extruded aluminum, electro-coated matte black finish"
        ),
        HardwareItem(
            id = "hw_shelf_support_pin",
            name = "Häfele Duomatic Steel Shelf Pins Ø5mm",
            category = HardwareCategory.SHELF_PINS,
            code = "HAF-282.04.711",
            quantity = 24,
            unitCost = 0.18f,
            mountingType = "32mm System Line Holes Ø5×10mm",
            specs = "Anti-tilt locking tooth with nickel plated steel pin"
        ),
        HardwareItem(
            id = "hw_adjustable_foot",
            name = "Camar Leveling Plinth Foot 80-120mm",
            category = HardwareCategory.LEVELLERS_FEET,
            code = "CAM-305-ADJ",
            quantity = 6,
            unitCost = 2.10f,
            mountingType = "Base Bottom Screwed Ø10mm sockets",
            specs = "Reinforced polymer, 300kg/foot capacity, top-adjustment access"
        )
    )

    fun getDefaultForWardrobe(hingeCount: Int, drawerCount: Int, shelfCount: Int): List<HardwareItem> {
        return listOf(
            presets[0].copy(quantity = hingeCount),
            presets[1].copy(quantity = drawerCount),
            presets[2].copy(quantity = 16 + shelfCount * 4),
            presets[3].copy(quantity = 24 + shelfCount * 4),
            presets[4].copy(quantity = 12),
            presets[5].copy(quantity = (hingeCount / 3) + drawerCount),
            presets[6].copy(quantity = shelfCount * 4),
            presets[7].copy(quantity = 6)
        )
    }
}
