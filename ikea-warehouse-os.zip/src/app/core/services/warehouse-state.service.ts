import { Injectable, signal, computed } from '@angular/core';
import {
  Product,
  WarehouseLocation,
  InventoryRecord,
  InventoryEvent,
  AvailableToPromise,
  Order,
  PickTask,
  Worker,
  Forklift,
  InboundShipment,
  CollectionOrder,
  AIRecommendation,
  SustainabilityMetrics,
  WhatIfScenarioResult
} from '../models/warehouse.types';

@Injectable({
  providedIn: 'root'
})
export class WarehouseStateEngine {
  // --- Signals for Primary State ---
  readonly activeWarehouse = signal({
    id: 'DC-01',
    name: 'SYNTHETIC DISTRIBUTION CENTRE 01',
    code: 'AUREOM-DC01',
    location: 'ÄLMHULT LOGISTICS HUB',
    totalCapacityM3: 125000,
    currentOccupiedM3: 84200,
  });

  readonly simulationClock = signal<{
    mode: 'REAL_TIME' | 'FAST_FORWARD' | 'PAUSED';
    speedMultiplier: number;
    simulatedTime: Date;
  }>({
    mode: 'REAL_TIME',
    speedMultiplier: 1,
    simulatedTime: new Date()
  });

  readonly products = signal<Product[]>(this.generateSyntheticProducts());
  readonly locations = signal<WarehouseLocation[]>(this.generateSyntheticLocations());
  readonly inventory = signal<InventoryRecord[]>(this.generateSyntheticInventory());
  readonly inventoryLedger = signal<InventoryEvent[]>([]);
  readonly orders = signal<Order[]>(this.generateSyntheticOrders());
  readonly pickTasks = signal<PickTask[]>(this.generateSyntheticPickTasks());
  readonly workers = signal<Worker[]>(this.generateSyntheticWorkers());
  readonly forklifts = signal<Forklift[]>(this.generateSyntheticForklifts());
  readonly inboundShipments = signal<InboundShipment[]>(this.generateSyntheticInbound());
  readonly collectionOrders = signal<CollectionOrder[]>(this.generateSyntheticCollections());
  readonly aiRecommendations = signal<AIRecommendation[]>(this.generateSyntheticAIRecommendations());
  readonly sustainability = signal<SustainabilityMetrics>({
    electricityKwhToday: 1420,
    forkliftEnergyKwhToday: 380,
    solarGenerationKwhToday: 950,
    renewableSharePct: 84.5,
    co2SavedKgToday: 1840,
    packagingRecycledKgToday: 620,
    circularRestockCount: 42,
    circularRefurbishCount: 18
  });

  // Active Master Demo Log for Live Step Display
  readonly activeDemoLog = signal<{ timestamp: string; step: number; title: string; detail: string; status: 'SUCCESS' | 'INFO' | 'WARN' | 'EXEC' }[]>([]);

  // What-If Simulation Result state
  readonly activeWhatIfResult = signal<WhatIfScenarioResult | null>(null);

  // --- Computed Metrics & Formulas ---
  readonly totalOrdersToday = computed(() => this.orders().length);
  readonly ordersPicking = computed(() => this.orders().filter(o => o.status === 'PICKING' || o.status === 'ALLOCATED').length);
  readonly ordersReady = computed(() => this.orders().filter(o => o.status === 'READY' || o.status === 'COLLECTION_READY').length);
  readonly ordersAtRisk = computed(() => this.orders().filter(o => o.riskScore === 'HIGH' || o.riskScore === 'CRITICAL').length);

  readonly inventoryAccuracy = computed(() => {
    // Formula: 1 - (absolute counted variance / expected inventory)
    // Synthetic calculated accuracy
    return 99.42; 
  });

  readonly pickProductivity = computed(() => {
    // Formula: units picked / productive labour hours
    const totalPicked = this.pickTasks().filter(t => t.status === 'COMPLETED').length;
    return Math.max(28.5, Math.round((totalPicked + 140) / 6 * 10) / 10);
  });

  readonly warehouseUtilisationPct = computed(() => {
    // Formula: occupied capacity / available capacity
    const locs = this.locations();
    if (locs.length === 0) return 67.36;
    const avg = locs.reduce((sum, l) => sum + l.currentUtilisationPct, 0) / locs.length;
    return Math.round(avg * 100) / 100;
  });

  readonly availableToPromiseList = computed<AvailableToPromise[]>(() => {
    const prods = this.products();
    const invs = this.inventory();
    
    return prods.map(p => {
      const pInvs = invs.filter(i => i.sku === p.sku);
      const physical = pInvs.reduce((s, i) => s + i.onHand, 0);
      const reserved = pInvs.reduce((s, i) => s + i.reserved, 0);
      const allocated = pInvs.reduce((s, i) => s + i.allocated, 0);
      const confirmedInbound = 15; // From synthetic ASNs
      const safetyBuffer = 5;
      
      // ATP = PhysicalStock - ReservedStock - AllocatedStock + ConfirmedInbound - SafetyBuffer
      const atp = Math.max(0, physical - reserved - allocated + confirmedInbound - safetyBuffer);

      return {
        sku: p.sku,
        physicalStock: physical,
        reservedStock: reserved,
        allocatedStock: allocated,
        confirmedInbound,
        safetyBuffer,
        availableToPromise: atp
      };
    });
  });

  readonly congestionScore = computed(() => {
    // Calculates worker density and pick activity per aisle
    const tasks = this.pickTasks().filter(t => t.status === 'IN_PROGRESS' || t.status === 'PENDING');
    if (tasks.length > 25) return 82; // High congestion
    if (tasks.length > 12) return 54; // Moderate
    return 24; // Low
  });

  constructor() {
    this.seedInitialLedger();
  }

  // --- Master Scenario Launchers ---

  /**
   * Scenario 1: Master Flow (Complete End-to-End Fulfilment Journey)
   */
  async runMasterDemoScenario() {
    this.activeDemoLog.set([]);
    this.addLog(1, 'CUSTOMER ORDER CREATED', 'Order #ORD-100099 created for 2x BILLY-SYN-001, 1x KALLAX-SYN-002, 1x LAMP-SYN-004', 'INFO');
    await this.delay(800);

    // 1. Create order
    const newOrder: Order = {
      orderId: 'ORD-100099',
      customerId: 'CUST-8841',
      customerName: 'Sven Lindqvist',
      customerPhone: '+46 70 123 4567',
      orderType: 'CLICK_AND_COLLECT',
      createdAt: new Date().toISOString(),
      promisedDeadline: new Date(Date.now() + 3600000 * 2).toISOString(),
      status: 'CREATED',
      lines: [
        { orderLineId: 'L1', sku: 'BILLY-SYN-001', productName: 'SYNTHETIC-BILLY-BOOKCASE', quantityOrdered: 2, quantityAllocated: 0, quantityPicked: 0, unitPriceSEK: 699 },
        { orderLineId: 'L2', sku: 'KALLAX-SYN-002', productName: 'SYNTHETIC-KALLAX-SHELVING', quantityOrdered: 1, quantityAllocated: 0, quantityPicked: 0, unitPriceSEK: 499 },
        { orderLineId: 'L3', sku: 'LAMP-SYN-004', productName: 'SYNTHETIC-TERTIAL-LAMP', quantityOrdered: 1, quantityAllocated: 0, quantityPicked: 0, unitPriceSEK: 149 }
      ],
      packages: [],
      totalWeightKg: 89.5,
      totalVolumeM3: 0.28,
      riskScore: 'LOW'
    };

    this.orders.update(o => [newOrder, ...o]);
    this.addLog(2, 'STOCK CHECK & WAREHOUSE SELECTION', 'Checking ATP for Älmhult Hub DC-01. Sufficient stock verified.', 'SUCCESS');
    await this.delay(800);

    // 2. Allocation
    this.addLog(3, 'PACKAGE ALLOCATION & INVENTORY RESERVATION', 'Decomposing products into 5 physical flat-pack packages. Reserving inventory in Forward Pick Aisle A02 & A04.', 'EXEC');
    this.allocateOrder('ORD-100099');
    await this.delay(1000);

    // 3. Generate Pick Wave
    this.addLog(4, 'PICK WAVE GENERATED & DIJKSTRA ROUTE OPTIMIZED', 'Wave W-092 generated. Shortest path calculated: 142 meters travel distance. Assigned to Picker WRK-8042.', 'SUCCESS');
    await this.delay(1000);

    // 4. Picker Workflow Simulation
    const task = this.pickTasks().find(t => t.orderId === 'ORD-100099');
    if (task) {
      this.addLog(5, 'HANDHELD SCANNER: LOCATION SCAN', `Worker WRK-8042 arrived at Location ${task.sourceLocationId}. Scanned barcode LOC-DC01-A02-R04-B01.`, 'EXEC');
      await this.delay(900);

      this.addLog(6, 'HANDHELD SCANNER: PRODUCT SCAN', `Scanned Package EAN-BILLY-001-P1. Quantity 2 confirmed.`, 'SUCCESS');
      this.processPickTask(task.taskId, 'COMPLETED');
      await this.delay(900);
    }

    // 5. Consolidation & Staging
    this.addLog(7, 'STAGING & CONSOLIDATION', 'All 5 packages consolidated at Staging Bay STG-04. Status set to COLLECTION_READY.', 'SUCCESS');
    this.orders.update(list => list.map(o => o.orderId === 'ORD-100099' ? { ...o, status: 'COLLECTION_READY', collectionSlot: 'BAY-02 (14:30 - 15:00)', collectionQrCode: 'QR-100099-SWEDEN' } : o));
    await this.delay(1000);

    // 6. Customer Check-In & Verification
    this.addLog(8, 'CLICK & COLLECT CHECK-IN', 'Customer Sven Lindqvist checked in via QR Code QR-100099-SWEDEN at Bay 02.', 'INFO');
    await this.delay(900);

    // 7. Handover & Ledger Close
    this.addLog(9, 'HANDOVER COMPLETE & LEDGER CLOSED', 'Worker verified license plate & handed over 5 packages. Order completed. Immutable ledger event DISPATCHED recorded.', 'SUCCESS');
    this.orders.update(list => list.map(o => o.orderId === 'ORD-100099' ? { ...o, status: 'COMPLETED' } : o));
  }

  /**
   * Scenario 2: Failure Scenario (Missing SKU Exception & Auto Re-Allocation)
   */
  async runFailureDemoScenario() {
    this.activeDemoLog.set([]);
    this.addLog(1, 'PICK TASK STARTED', 'Picker WRK-8044 arrived at Forward Pick Location DC01-A03-R02-B01 for SKU PAX-SYN-003.', 'INFO');
    await this.delay(900);

    this.addLog(2, 'EXCEPTION REPORTED: NOT_FOUND', 'Picker reports item missing/damaged at bin location. System pauses task.', 'WARN');
    
    // Create new order with exception
    const orderId = 'ORD-EX-9921';
    const exceptionTask: PickTask = {
      taskId: 'TASK-EX-01',
      pickWaveId: 'WAVE-EX',
      orderId: orderId,
      sku: 'PAX-SYN-003',
      packageId: 'PKG-PAX-01',
      productName: 'SYNTHETIC-PAX-WARDROBE (Package 1)',
      sourceLocationId: 'DC01-A03-R02-B01',
      stagingLocationId: 'STG-02',
      quantity: 1,
      workerId: 'WRK-8044',
      priority: 1,
      deadline: new Date(Date.now() + 1800000).toISOString(),
      status: 'PAUSED_EXCEPTION',
      exceptionReason: 'NOT_FOUND',
      pickingSequence: 1,
      optimalRoutePath: [{ x: 120, y: 150 }]
    };

    this.pickTasks.update(t => [exceptionTask, ...t]);
    await this.delay(1000);

    this.addLog(3, 'SYSTEM REACTION: INVENTORY INVESTIGATION CREATED', 'Location DC01-A03-R02-B01 flagged for cycle count audit. Order risk escalated to HIGH.', 'WARN');
    this.locations.update(locs => locs.map(l => l.locationId === 'DC01-A03-R02-B01' ? { ...l, isBlocked: true } : l));
    await this.delay(1100);

    this.addLog(4, 'RE-ALLOCATION ENGINE: SEARCHING RESERVE STORAGE', 'Reserve High-Bay Location DC01-HBA-08 identified with 12 units available.', 'EXEC');
    await this.delay(1000);

    this.addLog(5, 'NEW PICK TASK GENERATED & RE-ROUTED', 'Re-allocated pick task TASK-EX-01-R assigned to reserve picker with forklift FL-02. Customer ETA updated +12 mins.', 'SUCCESS');
    
    this.pickTasks.update(tasks => tasks.map(t => t.taskId === 'TASK-EX-01' ? {
      ...t,
      status: 'IN_PROGRESS',
      sourceLocationId: 'DC01-HBA-08',
      exceptionReason: undefined
    } : t));
  }

  /**
   * Scenario 3: Warehouse Congestion & What-If Optimisation
   */
  async runCongestionDemoScenario() {
    this.activeDemoLog.set([]);
    this.addLog(1, 'CONGESTION SIMULATION INITIATED', 'Simulating +50% Order Volume Spike across Forward Pick Aisles A01-A04.', 'WARN');
    await this.delay(800);

    this.addLog(2, 'BOTTLENECK DETECTED', 'Congestion Score escalated to 88/100. Aisle A02 travel delay estimated at +18 minutes per wave.', 'WARN');
    await this.delay(1000);

    this.addLog(3, 'RUST OPTIMIZATION KERNEL RUNNING', 'Evaluating alternative batch picking, zone splitting & forklift lane reassignment.', 'EXEC');
    
    const result: WhatIfScenarioResult = {
      scenarioName: '+50% Volume Spike Mitigation',
      volumeChangePct: 50,
      baselineThroughputOrdersHr: 120,
      simulatedThroughputOrdersHr: 172,
      baselineAvgPickDistanceM: 210,
      simulatedAvgPickDistanceM: 148,
      bottleneckZones: ['Forward Pick Aisle A02', 'Packing Bay 03'],
      recommendedActions: [
        'Split Pick Wave W-093 into 3 Zone-Specific Batches',
        'Re-route Forklift FL-03 to Cross-Aisle North bypass',
        'Trigger automatic replenishment from High-Bay HBA-02 to Forward Pick A08'
      ]
    };

    this.activeWhatIfResult.set(result);
    await this.delay(1000);

    this.addLog(4, 'OPTIMISATION APPLIED', 'Throughput restored to 172 orders/hr (-29.5% travel distance). Before/After KPIs updated.', 'SUCCESS');
  }

  /**
   * Scenario 4: Inbound Truck Arrival & Putaway Scoring
   */
  async runInboundDemoScenario() {
    this.activeDemoLog.set([]);
    this.addLog(1, 'INBOUND TRUCK CHECK-IN', 'Truck AB-982-SE (Supplier: IKEA Components Älmhult) arrived at Gate North.', 'INFO');
    await this.delay(800);

    this.addLog(2, 'DOCK ASSIGNED & UNLOAD STARTED', 'Assigned to Dock Door DOCK-02. Unloading 24 pallets of KALLAX-SYN-002.', 'EXEC');
    await this.delay(1000);

    this.addLog(3, 'QUALITY CHECK (QC) PASSED', '24/24 pallets inspected. 0 damaged. ASN match 100%.', 'SUCCESS');
    await this.delay(900);

    this.addLog(4, 'PUTAWAY SCORING ENGINE', 'Location Scoring formula evaluated: Distance + Congestion + Demand Frequency - Affinity. Selected Bin DC01-HBA-04.', 'EXEC');
    await this.delay(900);

    this.addLog(5, 'PUTAWAY COMPLETE & INVENTORY LEDGER UPDATED', 'Pallets put away. Available stock increased by +240 units. Inventory Event RECEIVED logged.', 'SUCCESS');
    
    // Add inventory event
    this.recordEvent({
      eventId: 'EVT-' + Math.floor(Math.random() * 899999 + 100000),
      timestamp: new Date().toISOString(),
      sku: 'KALLAX-SYN-002',
      locationId: 'DC01-HBA-04',
      quantity: 240,
      previousState: 'IN_TRANSIT',
      newState: 'AVAILABLE',
      workerId: 'WRK-RECEIVER-01',
      deviceId: 'AND-REC-02',
      reason: 'Inbound Shipment ASN-9021 Receiving',
      reference: 'ASN-9021',
      correlationId: 'CORR-INBOUND-01'
    });
  }

  // --- Core Domain Helper Methods ---

  recordEvent(evt: InventoryEvent) {
    this.inventoryLedger.update(ledger => [evt, ...ledger]);
    
    // Update inventory balance
    this.inventory.update(invs => {
      const existing = invs.find(i => i.sku === evt.sku && i.locationId === evt.locationId);
      if (existing) {
        return invs.map(i => {
          if (i.sku === evt.sku && i.locationId === evt.locationId) {
            let available = i.available;
            const onHand = i.onHand;
            if (evt.newState === 'AVAILABLE') available += evt.quantity;
            if (evt.newState === 'PICKED') available -= evt.quantity;
            return { ...i, available, onHand };
          }
          return i;
        });
      } else {
        return [...invs, {
          sku: evt.sku,
          locationId: evt.locationId,
          onHand: evt.quantity,
          available: evt.quantity,
          reserved: 0,
          allocated: 0,
          picked: 0,
          staged: 0,
          damaged: 0,
          quarantined: 0,
          lastCountedAt: new Date().toISOString()
        }];
      }
    });
  }

  allocateOrder(orderId: string) {
    this.orders.update(list => list.map(o => {
      if (o.orderId === orderId) {
        const pkgs: {
          packageId: string;
          sku: string;
          packageNumber: number;
          totalPackages: number;
          assignedLocationId: string;
          status: 'ALLOCATED' | 'PICKING' | 'PICKED' | 'PENDING' | 'STAGED' | 'CONSOLIDATED';
          stagingLocationId: string;
        }[] = [];
        o.lines.forEach(l => {
          const prod = this.products().find(p => p.sku === l.sku);
          if (prod) {
            prod.packages.forEach((p) => {
              pkgs.push({
                packageId: `${l.sku}-P${p.packageNumber}`,
                sku: l.sku,
                packageNumber: p.packageNumber,
                totalPackages: p.totalPackages,
                assignedLocationId: 'DC01-A02-R04-B01',
                status: 'ALLOCATED',
                stagingLocationId: 'STG-04'
              });
            });
          }
        });

        return {
          ...o,
          status: 'ALLOCATED',
          packages: pkgs
        };
      }
      return o;
    }));

    // Generate pick wave tasks
    const newPickTask: PickTask = {
      taskId: 'TASK-' + Math.floor(Math.random() * 8999 + 1000),
      pickWaveId: 'WAVE-092',
      orderId: orderId,
      sku: 'BILLY-SYN-001',
      packageId: 'PKG-BILLY-01',
      productName: 'SYNTHETIC-BILLY-BOOKCASE (Package 1/2)',
      sourceLocationId: 'DC01-A02-R04-B01',
      stagingLocationId: 'STG-04',
      quantity: 2,
      workerId: 'WRK-8042',
      priority: 1,
      deadline: new Date(Date.now() + 3600000).toISOString(),
      status: 'PENDING',
      pickingSequence: 1,
      optimalRoutePath: [{ x: 40, y: 80 }, { x: 100, y: 80 }, { x: 100, y: 220 }]
    };

    this.pickTasks.update(t => [newPickTask, ...t]);
  }

  processPickTask(
    taskId: string, 
    status: 'COMPLETED' | 'PAUSED_EXCEPTION', 
    reason?: 'NOT_FOUND' | 'DAMAGED' | 'WRONG_LOCATION' | 'WRONG_PRODUCT' | 'BLOCKED_LOCATION'
  ) {
    this.pickTasks.update(tasks => tasks.map(t => {
      if (t.taskId === taskId) {
        return {
          ...t,
          status,
          exceptionReason: reason,
          completedAt: status === 'COMPLETED' ? new Date().toISOString() : undefined
        };
      }
      return t;
    }));
  }

  applyAiRecommendation(id: string) {
    this.aiRecommendations.update(recs => recs.map(r => r.id === id ? { ...r, status: 'EXECUTED' } : r));
    this.addLog(0, 'AI RECOMMENDATION EXECUTED', `Human operator approved AI action ${id}. Executed securely.`, 'SUCCESS');
  }

  private addLog(step: number, title: string, detail: string, status: 'SUCCESS' | 'INFO' | 'WARN' | 'EXEC') {
    const entry = {
      timestamp: new Date().toLocaleTimeString(),
      step,
      title,
      detail,
      status
    };
    this.activeDemoLog.update(logs => [...logs, entry]);
  }

  private delay(ms: number) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  // --- Synthetic Data Generators ---

  private generateSyntheticProducts(): Product[] {
    return [
      {
        sku: 'BILLY-SYN-001',
        articleNumber: '802.638.32',
        productName: 'SYNTHETIC-BILLY-BOOKCASE',
        category: 'Bookcases & Shelving',
        department: 'Living Room',
        totalWeightKg: 38.5,
        totalVolumeM3: 0.082,
        reorderPoint: 25,
        targetStock: 120,
        unitPriceSEK: 699,
        imageUrl: 'https://picsum.photos/seed/billy1/400/300',
        packages: [
          { packageId: 'P01-BILLY', packageNumber: 1, totalPackages: 2, dimensions: { lengthMeters: 2.08, widthMeters: 0.38, heightMeters: 0.06, weightKg: 22.0, volumeM3: 0.047 }, barcode: 'EAN-BILLY-001-P1', handlingClass: 'HEAVY_FLATPACK', fragility: false, stackingLimit: 8 },
          { packageId: 'P02-BILLY', packageNumber: 2, totalPackages: 2, dimensions: { lengthMeters: 0.82, widthMeters: 0.38, heightMeters: 0.11, weightKg: 16.5, volumeM3: 0.035 }, barcode: 'EAN-BILLY-001-P2', handlingClass: 'STANDARD', fragility: false, stackingLimit: 12 }
        ]
      },
      {
        sku: 'KALLAX-SYN-002',
        articleNumber: '202.758.85',
        productName: 'SYNTHETIC-KALLAX-SHELVING',
        category: 'Shelving Units',
        department: 'Storage',
        totalWeightKg: 17.8,
        totalVolumeM3: 0.054,
        reorderPoint: 30,
        targetStock: 150,
        unitPriceSEK: 499,
        imageUrl: 'https://picsum.photos/seed/kallax2/400/300',
        packages: [
          { packageId: 'P01-KALLAX', packageNumber: 1, totalPackages: 1, dimensions: { lengthMeters: 1.48, widthMeters: 0.41, heightMeters: 0.09, weightKg: 17.8, volumeM3: 0.054 }, barcode: 'EAN-KALLAX-002', handlingClass: 'STANDARD', fragility: false, stackingLimit: 10 }
        ]
      },
      {
        sku: 'PAX-SYN-003',
        articleNumber: '690.257.23',
        productName: 'SYNTHETIC-PAX-WARDROBE',
        category: 'Wardrobes',
        department: 'Bedroom',
        totalWeightKg: 97.0,
        totalVolumeM3: 0.24,
        reorderPoint: 15,
        targetStock: 60,
        unitPriceSEK: 3499,
        imageUrl: 'https://picsum.photos/seed/pax3/400/300',
        packages: [
          { packageId: 'P01-PAX', packageNumber: 1, totalPackages: 3, dimensions: { lengthMeters: 2.38, widthMeters: 0.61, heightMeters: 0.08, weightKg: 42.0, volumeM3: 0.11 }, barcode: 'EAN-PAX-003-P1', handlingClass: 'HEAVY_FLATPACK', fragility: false, stackingLimit: 5 },
          { packageId: 'P02-PAX', packageNumber: 2, totalPackages: 3, dimensions: { lengthMeters: 2.38, widthMeters: 0.61, heightMeters: 0.08, weightKg: 38.0, volumeM3: 0.11 }, barcode: 'EAN-PAX-003-P2', handlingClass: 'HEAVY_FLATPACK', fragility: false, stackingLimit: 5 },
          { packageId: 'P03-PAX', packageNumber: 3, totalPackages: 3, dimensions: { lengthMeters: 0.98, widthMeters: 0.58, heightMeters: 0.04, weightKg: 17.0, volumeM3: 0.02 }, barcode: 'EAN-PAX-003-P3', handlingClass: 'STANDARD', fragility: true, stackingLimit: 8 }
        ]
      },
      {
        sku: 'LAMP-SYN-004',
        articleNumber: '603.728.01',
        productName: 'SYNTHETIC-TERTIAL-LAMP',
        category: 'Workplace Lighting',
        department: 'Lighting',
        totalWeightKg: 1.2,
        totalVolumeM3: 0.008,
        reorderPoint: 50,
        targetStock: 300,
        unitPriceSEK: 149,
        imageUrl: 'https://picsum.photos/seed/lamp4/400/300',
        packages: [
          { packageId: 'P01-LAMP', packageNumber: 1, totalPackages: 1, dimensions: { lengthMeters: 0.35, widthMeters: 0.18, heightMeters: 0.12, weightKg: 1.2, volumeM3: 0.008 }, barcode: 'EAN-LAMP-004', handlingClass: 'FRAGILE', fragility: true, stackingLimit: 15 }
        ]
      },
      {
        sku: 'MALM-SYN-005',
        articleNumber: '002.145.43',
        productName: 'SYNTHETIC-MALM-BEDFRAME',
        category: 'Beds & Mattresses',
        department: 'Bedroom',
        totalWeightKg: 54.0,
        totalVolumeM3: 0.16,
        reorderPoint: 20,
        targetStock: 80,
        unitPriceSEK: 2199,
        imageUrl: 'https://picsum.photos/seed/malm5/400/300',
        packages: [
          { packageId: 'P01-MALM', packageNumber: 1, totalPackages: 2, dimensions: { lengthMeters: 2.08, widthMeters: 0.42, heightMeters: 0.09, weightKg: 32.0, volumeM3: 0.08 }, barcode: 'EAN-MALM-005-P1', handlingClass: 'HEAVY_FLATPACK', fragility: false, stackingLimit: 6 },
          { packageId: 'P02-MALM', packageNumber: 2, totalPackages: 2, dimensions: { lengthMeters: 1.68, widthMeters: 0.82, heightMeters: 0.06, weightKg: 22.0, volumeM3: 0.08 }, barcode: 'EAN-MALM-005-P2', handlingClass: 'HEAVY_FLATPACK', fragility: false, stackingLimit: 6 }
        ]
      }
    ];
  }

  private generateSyntheticLocations(): WarehouseLocation[] {
    const locs: WarehouseLocation[] = [];
    const zones = [
      { id: 'Z-INBOUND', type: 'INBOUND_DOCK', prefix: 'DC01-DOCK-IN', count: 4 },
      { id: 'Z-FORWARD-A', type: 'FORWARD_PICK', prefix: 'DC01-A01', count: 12 },
      { id: 'Z-FORWARD-B', type: 'FORWARD_PICK', prefix: 'DC01-A02', count: 12 },
      { id: 'Z-HIGHBAY', type: 'HIGH_BAY', prefix: 'DC01-HBA', count: 20 },
      { id: 'Z-STAGING', type: 'STAGING', prefix: 'DC01-STG', count: 8 },
      { id: 'Z-CLICKCOLLECT', type: 'CLICK_COLLECT', prefix: 'DC01-BAY', count: 6 },
      { id: 'Z-RETURNS', type: 'RETURNS', prefix: 'DC01-RET', count: 2 }
    ];

    let idIdx = 1;
    zones.forEach(z => {
      for (let i = 1; i <= z.count; i++) {
        locs.push({
          locationId: `${z.prefix}-R${String(i).padStart(2, '0')}-B01`,
          warehouseId: 'DC-01',
          zoneId: z.id,
          zoneType: z.type as WarehouseLocation['zoneType'],
          aisle: z.prefix.split('-').pop() || 'A01',
          rack: i,
          bay: 1,
          level: 1,
          bin: 'B01',
          x: 40 + (idIdx % 10) * 80,
          y: 60 + Math.floor(idIdx / 10) * 90,
          z: 0,
          widthM: 2.8,
          lengthM: 1.2,
          heightM: 2.4,
          capacityM3: 8.0,
          capacityKg: 1500,
          currentUtilisationPct: Math.floor(Math.random() * 40 + 45),
          allowedClasses: ['PALLET_RACK', 'FORWARD_PICK'],
          isBlocked: false
        });
        idIdx++;
      }
    });

    return locs;
  }

  private generateSyntheticInventory(): InventoryRecord[] {
    return [
      { sku: 'BILLY-SYN-001', locationId: 'DC01-A02-R04-B01', onHand: 84, available: 72, reserved: 8, allocated: 4, picked: 0, staged: 0, damaged: 0, quarantined: 0, lastCountedAt: new Date().toISOString() },
      { sku: 'KALLAX-SYN-002', locationId: 'DC01-A01-R02-B01', onHand: 112, available: 95, reserved: 10, allocated: 7, picked: 0, staged: 0, damaged: 0, quarantined: 0, lastCountedAt: new Date().toISOString() },
      { sku: 'PAX-SYN-003', locationId: 'DC01-HBA-R08-B01', onHand: 42, available: 32, reserved: 6, allocated: 4, picked: 0, staged: 0, damaged: 0, quarantined: 0, lastCountedAt: new Date().toISOString() },
      { sku: 'LAMP-SYN-004', locationId: 'DC01-A01-R01-B01', onHand: 240, available: 210, reserved: 15, allocated: 15, picked: 0, staged: 0, damaged: 0, quarantined: 0, lastCountedAt: new Date().toISOString() },
      { sku: 'MALM-SYN-005', locationId: 'DC01-HBA-R12-B01', onHand: 55, available: 48, reserved: 4, allocated: 3, picked: 0, staged: 0, damaged: 0, quarantined: 0, lastCountedAt: new Date().toISOString() }
    ];
  }

  private generateSyntheticOrders(): Order[] {
    return [
      {
        orderId: 'ORD-100042',
        customerId: 'CUST-3901',
        customerName: 'Astrid Bergman',
        customerPhone: '+46 73 987 6543',
        orderType: 'CLICK_AND_COLLECT',
        createdAt: new Date(Date.now() - 3600000 * 3).toISOString(),
        promisedDeadline: new Date(Date.now() + 3600000 * 1.5).toISOString(),
        status: 'PICKING',
        totalWeightKg: 97.0,
        totalVolumeM3: 0.24,
        riskScore: 'LOW',
        lines: [
          { orderLineId: 'L10', sku: 'PAX-SYN-003', productName: 'SYNTHETIC-PAX-WARDROBE', quantityOrdered: 1, quantityAllocated: 1, quantityPicked: 0, unitPriceSEK: 3499 }
        ],
        packages: [
          { packageId: 'PKG-PAX-01', sku: 'PAX-SYN-003', packageNumber: 1, totalPackages: 3, assignedLocationId: 'DC01-HBA-R08-B01', status: 'PICKING' },
          { packageId: 'PKG-PAX-02', sku: 'PAX-SYN-003', packageNumber: 2, totalPackages: 3, assignedLocationId: 'DC01-HBA-R08-B01', status: 'PICKING' },
          { packageId: 'PKG-PAX-03', sku: 'PAX-SYN-003', packageNumber: 3, totalPackages: 3, assignedLocationId: 'DC01-HBA-R08-B01', status: 'PICKING' }
        ]
      },
      {
        orderId: 'ORD-100045',
        customerId: 'CUST-4102',
        customerName: 'Lars Nilsson',
        customerPhone: '+46 76 555 1234',
        orderType: 'HOME_DELIVERY',
        destinationAddress: 'Kungsgatan 14, 111 35 Stockholm',
        createdAt: new Date(Date.now() - 3600000 * 5).toISOString(),
        promisedDeadline: new Date(Date.now() + 3600000 * 4).toISOString(),
        status: 'READY',
        totalWeightKg: 56.3,
        totalVolumeM3: 0.136,
        riskScore: 'MEDIUM',
        lines: [
          { orderLineId: 'L11', sku: 'BILLY-SYN-001', productName: 'SYNTHETIC-BILLY-BOOKCASE', quantityOrdered: 1, quantityAllocated: 1, quantityPicked: 1, unitPriceSEK: 699 },
          { orderLineId: 'L12', sku: 'KALLAX-SYN-002', productName: 'SYNTHETIC-KALLAX-SHELVING', quantityOrdered: 1, quantityAllocated: 1, quantityPicked: 1, unitPriceSEK: 499 }
        ],
        packages: [
          { packageId: 'PKG-BILLY-01', sku: 'BILLY-SYN-001', packageNumber: 1, totalPackages: 2, assignedLocationId: 'DC01-A02-R04-B01', status: 'CONSOLIDATED', stagingLocationId: 'STG-01' },
          { packageId: 'PKG-BILLY-02', sku: 'BILLY-SYN-001', packageNumber: 2, totalPackages: 2, assignedLocationId: 'DC01-A02-R04-B01', status: 'CONSOLIDATED', stagingLocationId: 'STG-01' },
          { packageId: 'PKG-KALLAX-01', sku: 'KALLAX-SYN-002', packageNumber: 1, totalPackages: 1, assignedLocationId: 'DC01-A01-R02-B01', status: 'CONSOLIDATED', stagingLocationId: 'STG-01' }
        ]
      }
    ];
  }

  private generateSyntheticPickTasks(): PickTask[] {
    return [
      {
        taskId: 'TASK-7710',
        pickWaveId: 'WAVE-088',
        orderId: 'ORD-100042',
        sku: 'PAX-SYN-003',
        packageId: 'PKG-PAX-01',
        productName: 'SYNTHETIC-PAX-WARDROBE (Package 1/3)',
        sourceLocationId: 'DC01-HBA-R08-B01',
        stagingLocationId: 'STG-03',
        quantity: 1,
        workerId: 'WRK-8042',
        priority: 1,
        deadline: new Date(Date.now() + 3600000).toISOString(),
        status: 'IN_PROGRESS',
        startedAt: new Date(Date.now() - 600000).toISOString(),
        pickingSequence: 1,
        optimalRoutePath: [{ x: 40, y: 60 }, { x: 180, y: 150 }]
      }
    ];
  }

  private generateSyntheticWorkers(): Worker[] {
    return [
      { workerId: 'WRK-8042', name: 'Erik Johansson', role: 'PICKER', skills: ['PICKING', 'FORKLIFT'], status: 'ON_TASK', currentLocation: { x: 180, y: 150, zone: 'Z-HIGHBAY' }, assignedTaskId: 'TASK-7710', currentShift: 'MORNING', picksCompletedToday: 42, speedMetersPerSec: 1.4 },
      { workerId: 'WRK-8043', name: 'Freja Lindholm', role: 'PICKER', skills: ['PICKING', 'PACKING'], status: 'AVAILABLE', currentLocation: { x: 100, y: 80, zone: 'Z-FORWARD-A' }, currentShift: 'MORNING', picksCompletedToday: 38, speedMetersPerSec: 1.5 },
      { workerId: 'WRK-8044', name: 'Oskar Wallin', role: 'RECEIVER', skills: ['RECEIVING', 'FORKLIFT'], status: 'AVAILABLE', currentLocation: { x: 40, y: 60, zone: 'Z-INBOUND' }, currentShift: 'MORNING', picksCompletedToday: 15, speedMetersPerSec: 1.2 }
    ];
  }

  private generateSyntheticForklifts(): Forklift[] {
    return [
      { vehicleId: 'FL-01', operatorWorkerId: 'WRK-8042', batteryPct: 88, status: 'ASSIGNED', location: { x: 180, y: 150 }, currentLoadKg: 42.0, maxCapacityKg: 1200 },
      { vehicleId: 'FL-02', batteryPct: 94, status: 'AVAILABLE', location: { x: 40, y: 60 }, currentLoadKg: 0, maxCapacityKg: 1200 },
      { vehicleId: 'FL-03', batteryPct: 22, status: 'CHARGING', location: { x: 300, y: 300 }, currentLoadKg: 0, maxCapacityKg: 1500 }
    ];
  }

  private generateSyntheticInbound(): InboundShipment[] {
    return [
      {
        shipmentId: 'INB-9021',
        asnNumber: 'ASN-SWEDEN-9021',
        supplierName: 'IKEA Components AB (Älmhult)',
        truckLicensePlate: 'AB-982-SE',
        driverName: 'Matthias Braun',
        estimatedArrival: new Date().toISOString(),
        dockDoorId: 'DOCK-02',
        status: 'ARRIVED',
        skusExpected: [
          { sku: 'KALLAX-SYN-002', expectedQty: 240, receivedQty: 0, damagedQty: 0 }
        ],
        putawayTasks: [
          { sku: 'KALLAX-SYN-002', qty: 240, recommendedLocationId: 'DC01-HBA-04', score: 92.4, status: 'PENDING' }
        ]
      }
    ];
  }

  private generateSyntheticCollections(): CollectionOrder[] {
    return [
      {
        collectionId: 'CNC-8821',
        orderId: 'ORD-100042',
        customerName: 'Astrid Bergman',
        vehicleLicensePlate: 'KJL-492',
        slotTime: '14:30 - 15:00 Today',
        qrCode: 'QR-100042-SWEDEN',
        status: 'SCHEDULED',
        bayId: 'BAY-02',
        stagingLocations: ['STG-03'],
        packagesCount: 3,
        verificationCode: '8042'
      }
    ];
  }

  private generateSyntheticAIRecommendations(): AIRecommendation[] {
    return [
      {
        id: 'AI-REC-001',
        timestamp: new Date().toISOString(),
        category: 'CONGESTION_MITIGATION',
        title: 'Aisle A02 Congestion Mitigation',
        recommendation: 'Shift Pick Wave W-089 to Forward Pick Aisle A08 to reduce travel latency by 14 minutes.',
        confidenceScore: 0.94,
        evidence: ['3 pickers currently in Aisle A02', 'High-bay HBA-02 has 100% stock affinity'],
        modelVersion: 'Gemini-3.7-WarehouseOpt-v2',
        status: 'RECOMMENDED'
      },
      {
        id: 'AI-REC-002',
        timestamp: new Date().toISOString(),
        category: 'REPLENISHMENT',
        title: 'Forward Pick Replenishment Alert',
        recommendation: 'Trigger immediate transfer of 40 units BILLY-SYN-001 from Reserve HBA-04 to Forward Pick A02.',
        confidenceScore: 0.91,
        evidence: ['ATP expected to breach safety threshold in 42 minutes'],
        modelVersion: 'Gemini-3.7-InventoryPredict-v1',
        status: 'RECOMMENDED'
      }
    ];
  }

  private seedInitialLedger() {
    this.recordEvent({
      eventId: 'EVT-INIT-01',
      timestamp: new Date(Date.now() - 86400000).toISOString(),
      sku: 'BILLY-SYN-001',
      locationId: 'DC01-A02-R04-B01',
      quantity: 100,
      previousState: 'IN_TRANSIT',
      newState: 'AVAILABLE',
      workerId: 'SYSTEM_SEED',
      deviceId: 'SRV-01',
      reason: 'Initial Warehouse Inventory Seeding',
      reference: 'SEED-DC01',
      correlationId: 'CORR-001'
    });
  }
}
