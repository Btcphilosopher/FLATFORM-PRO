import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { WarehouseStateEngine } from '../../core/services/warehouse-state.service';

@Component({
  selector: 'app-control-centre',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 bg-[#F4F4F4] min-h-screen text-slate-900 space-y-6">
      
      <!-- Top Title & Operations Display Banner -->
      <div class="bg-white border border-slate-300 p-5 rounded-lg shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="bg-[#0058A3] text-white font-bold text-xs px-2.5 py-0.5 rounded uppercase">DC-01 OPERATIONS</span>
            <span class="text-xs font-semibold text-slate-500">AUREOM-WMS CORE KERNEL</span>
          </div>
          <h2 class="text-2xl font-black text-slate-900 tracking-tight uppercase mt-1">WAREHOUSE CONTROL CENTRE</h2>
          <p class="text-xs text-slate-600 font-medium">Real-time computational operating model • Synthetic Distribution Centre Älmhult Hub</p>
        </div>

        <div class="flex items-center gap-4">
          <button (click)="state.runMasterDemoScenario()" 
                  class="bg-[#0058A3] hover:bg-blue-900 text-white font-extrabold text-xs px-4 py-2.5 rounded shadow flex items-center gap-2 transition-all">
            <mat-icon class="text-base">play_circle_filled</mat-icon>
            EXECUTE MASTER DEMO SCENARIO
          </button>
        </div>
      </div>

      <!-- Live Scenario Demo Log Banner (Shows when running demos) -->
      @if (state.activeDemoLog().length > 0) {
        <div class="bg-slate-900 text-white border-2 border-[#FFDA1A] p-4 rounded-lg shadow-md space-y-3">
          <div class="flex items-center justify-between border-b border-slate-800 pb-2">
            <div class="flex items-center gap-2">
              <span class="relative flex h-2.5 w-2.5">
                <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#FFDA1A] opacity-75"></span>
                <span class="relative inline-flex rounded-full h-2.5 w-2.5 bg-[#FFDA1A]"></span>
              </span>
              <h3 class="font-extrabold text-sm uppercase text-[#FFDA1A] tracking-wider">LIVE SCENARIO DEMONSTRATION IN PROGRESS</h3>
            </div>
            <span class="text-xs text-slate-400 font-mono">{{ state.activeDemoLog().length }} Events Logged</span>
          </div>

          <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 max-h-48 overflow-y-auto pr-1">
            @for (log of state.activeDemoLog(); track $index) {
              <div class="bg-slate-800/80 border border-slate-700 p-2.5 rounded text-xs space-y-1">
                <div class="flex items-center justify-between">
                  <span class="font-mono text-[10px] text-blue-400">Step {{ log.step }} • {{ log.timestamp }}</span>
                  <span [class]="getLogBadgeClass(log.status)">{{ log.status }}</span>
                </div>
                <h4 class="font-bold text-white uppercase">{{ log.title }}</h4>
                <p class="text-slate-300 text-[11px] leading-snug">{{ log.detail }}</p>
              </div>
            }
          </div>
        </div>
      }

      <!-- Top Primary Metric Cards Grid -->
      <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
        
        <!-- Metric 1: Orders Today -->
        <div class="bg-white border border-slate-300 p-4 rounded-lg shadow-sm">
          <div class="flex items-center justify-between text-slate-500 mb-1">
            <span class="text-[11px] font-bold uppercase tracking-wider">Orders Today</span>
            <mat-icon class="text-base text-[#0058A3]">shopping_cart</mat-icon>
          </div>
          <p class="text-2xl font-black text-slate-900 font-mono">{{ state.totalOrdersToday() }}</p>
          <p class="text-[10px] text-emerald-600 font-bold mt-1">↑ +14.2% vs yesterday</p>
        </div>

        <!-- Metric 2: Picking -->
        <div class="bg-white border border-slate-300 p-4 rounded-lg shadow-sm">
          <div class="flex items-center justify-between text-slate-500 mb-1">
            <span class="text-[11px] font-bold uppercase tracking-wider">Active Picking</span>
            <mat-icon class="text-base text-amber-500">directions_run</mat-icon>
          </div>
          <p class="text-2xl font-black text-amber-600 font-mono">{{ state.ordersPicking() }}</p>
          <p class="text-[10px] text-slate-500 mt-1">In 3 pick waves</p>
        </div>

        <!-- Metric 3: Ready / Staged -->
        <div class="bg-white border border-slate-300 p-4 rounded-lg shadow-sm">
          <div class="flex items-center justify-between text-slate-500 mb-1">
            <span class="text-[11px] font-bold uppercase tracking-wider">Ready / Staged</span>
            <mat-icon class="text-base text-emerald-600">inventory</mat-icon>
          </div>
          <p class="text-2xl font-black text-emerald-600 font-mono">{{ state.ordersReady() }}</p>
          <p class="text-[10px] text-emerald-600 font-bold mt-1">100% consolidated</p>
        </div>

        <!-- Metric 4: Orders At Risk -->
        <div class="bg-white border border-slate-300 p-4 rounded-lg shadow-sm">
          <div class="flex items-center justify-between text-slate-500 mb-1">
            <span class="text-[11px] font-bold uppercase tracking-wider">Orders At Risk</span>
            <mat-icon class="text-base text-red-600">warning</mat-icon>
          </div>
          <p class="text-2xl font-black text-red-600 font-mono">{{ state.ordersAtRisk() }}</p>
          <p class="text-[10px] text-red-600 font-bold mt-1">Deadline SLA risk</p>
        </div>

        <!-- Metric 5: Inventory Accuracy -->
        <div class="bg-white border border-slate-300 p-4 rounded-lg shadow-sm">
          <div class="flex items-center justify-between text-slate-500 mb-1">
            <span class="text-[11px] font-bold uppercase tracking-wider">Stock Accuracy</span>
            <mat-icon class="text-base text-[#0058A3]">fact_check</mat-icon>
          </div>
          <p class="text-2xl font-black text-slate-900 font-mono">{{ state.inventoryAccuracy() }}%</p>
          <p class="text-[10px] text-slate-500 mt-1">Formula: 1 - (var/exp)</p>
        </div>

        <!-- Metric 6: Pick Rate -->
        <div class="bg-white border border-slate-300 p-4 rounded-lg shadow-sm">
          <div class="flex items-center justify-between text-slate-500 mb-1">
            <span class="text-[11px] font-bold uppercase tracking-wider">Pick Productivity</span>
            <mat-icon class="text-base text-purple-600">speed</mat-icon>
          </div>
          <p class="text-2xl font-black text-purple-700 font-mono">{{ state.pickProductivity() }}</p>
          <p class="text-[10px] text-slate-500 mt-1">Units / Labour Hour</p>
        </div>
      </div>

      <!-- Main Operational Dashboard Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        <!-- Left 2 Cols: Orders & Fulfilment Control Tower -->
        <div class="lg:col-span-2 space-y-6">
          
          <!-- Orders Lifecycle & Risk Status Table -->
          <div class="bg-white border border-slate-300 rounded-lg shadow-sm overflow-hidden">
            <div class="bg-slate-900 text-white px-5 py-3 flex items-center justify-between">
              <div class="flex items-center gap-2">
                <mat-icon class="text-[#FFDA1A]">format_list_bulleted</mat-icon>
                <h3 class="font-extrabold text-sm uppercase tracking-wider">LIVE CUSTOMER ORDERS FULFILMENT QUEUE</h3>
              </div>
              <span class="text-xs text-slate-400 font-mono">{{ state.orders().length }} Active Orders</span>
            </div>

            <div class="overflow-x-auto">
              <table class="w-full text-left border-collapse text-xs">
                <thead>
                  <tr class="bg-slate-100 text-slate-700 font-extrabold uppercase border-b border-slate-300">
                    <th class="p-3">Order ID</th>
                    <th class="p-3">Customer</th>
                    <th class="p-3">Type</th>
                    <th class="p-3">Status</th>
                    <th class="p-3">Packages</th>
                    <th class="p-3">Risk Level</th>
                    <th class="p-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-slate-200">
                  @for (ord of state.orders(); track ord.orderId) {
                    <tr class="hover:bg-blue-50/50 transition-colors">
                      <td class="p-3 font-mono font-bold text-[#0058A3]">{{ ord.orderId }}</td>
                      <td class="p-3 font-semibold">{{ ord.customerName }}</td>
                      <td class="p-3">
                        <span class="bg-slate-200 text-slate-800 font-bold text-[10px] px-2 py-0.5 rounded">
                          {{ ord.orderType }}
                        </span>
                      </td>
                      <td class="p-3">
                        <span [class]="getOrderStatusBadgeClass(ord.status)">
                          {{ ord.status }}
                        </span>
                      </td>
                      <td class="p-3 font-mono text-slate-700 font-bold">
                        {{ ord.packages.length > 0 ? ord.packages.length + ' Pkgs' : 'Pending' }}
                      </td>
                      <td class="p-3">
                        <span [class]="getRiskBadgeClass(ord.riskScore)">
                          {{ ord.riskScore }}
                        </span>
                      </td>
                      <td class="p-3 text-right">
                        @if (ord.status === 'CREATED') {
                          <button (click)="state.allocateOrder(ord.orderId)" 
                                  class="bg-[#0058A3] hover:bg-blue-900 text-white font-bold text-[10px] px-2.5 py-1 rounded">
                            ALLOCATE
                          </button>
                        } @else {
                          <span class="text-slate-400 font-mono text-[10px]">IN PROGRESS</span>
                        }
                      </td>
                    </tr>
                  }
                </tbody>
              </table>
            </div>
          </div>

          <!-- Active Workers & Equipment Operational Status -->
          <div class="bg-white border border-slate-300 rounded-lg shadow-sm p-5 space-y-4">
            <div class="flex items-center justify-between border-b border-slate-200 pb-3">
              <div class="flex items-center gap-2">
                <mat-icon class="text-[#0058A3]">engineering</mat-icon>
                <h3 class="font-extrabold text-sm uppercase text-slate-900 tracking-wider">WORKFORCE & FORKLIFT FLEET AT WORK</h3>
              </div>
              <span class="text-xs text-slate-500 font-semibold">Shift: MORNING • 100% Active</span>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
              <!-- Workers List -->
              <div class="space-y-2">
                <h4 class="text-xs font-extrabold text-slate-700 uppercase">Active Pickers & Operators</h4>
                @for (wrk of state.workers(); track wrk.workerId) {
                  <div class="bg-slate-50 border border-slate-200 p-2.5 rounded flex items-center justify-between text-xs">
                    <div>
                      <span class="font-bold text-slate-900">{{ wrk.name }}</span>
                      <span class="text-[10px] text-slate-500 block font-mono">{{ wrk.workerId }} • Zone {{ wrk.currentLocation.zone }}</span>
                    </div>
                    <div class="text-right">
                      <span class="bg-emerald-100 text-emerald-800 font-bold text-[10px] px-2 py-0.5 rounded">
                        {{ wrk.status }}
                      </span>
                      <span class="text-[10px] text-slate-600 block mt-0.5">{{ wrk.picksCompletedToday }} picks today</span>
                    </div>
                  </div>
                }
              </div>

              <!-- Forklift Fleet List -->
              <div class="space-y-2">
                <h4 class="text-xs font-extrabold text-slate-700 uppercase">Forklift Vehicles & Battery</h4>
                @for (fl of state.forklifts(); track fl.vehicleId) {
                  <div class="bg-slate-50 border border-slate-200 p-2.5 rounded flex items-center justify-between text-xs">
                    <div class="flex items-center gap-2">
                      <mat-icon class="text-slate-700 text-base">forklift</mat-icon>
                      <div>
                        <span class="font-bold text-slate-900">{{ fl.vehicleId }}</span>
                        <span class="text-[10px] text-slate-500 block">Cap: {{ fl.maxCapacityKg }}kg</span>
                      </div>
                    </div>
                    <div class="text-right">
                      <div class="flex items-center gap-1">
                        <mat-icon class="text-xs text-emerald-600">battery_charging_full</mat-icon>
                        <span class="font-bold font-mono text-slate-800">{{ fl.batteryPct }}%</span>
                      </div>
                      <span class="text-[10px] text-blue-700 font-bold block uppercase">{{ fl.status }}</span>
                    </div>
                  </div>
                }
              </div>
            </div>
          </div>
        </div>

        <!-- Right Col: AI Decision Support & Operational Alerts -->
        <div class="space-y-6">
          
          <!-- AI Decision Support Queue -->
          <div class="bg-white border border-slate-300 rounded-lg shadow-sm p-5 space-y-4">
            <div class="flex items-center justify-between border-b border-slate-200 pb-2">
              <div class="flex items-center gap-2">
                <mat-icon class="text-[#0058A3]">psychology</mat-icon>
                <h3 class="font-extrabold text-sm uppercase text-slate-900 tracking-wider">AI DECISION SUPPORT QUEUE</h3>
              </div>
              <span class="bg-[#FFDA1A] text-black font-extrabold text-[10px] px-2 py-0.5 rounded uppercase">HUMAN-IN-THE-LOOP</span>
            </div>

            <div class="space-y-3">
              @for (rec of state.aiRecommendations(); track rec.id) {
                <div class="border border-slate-200 bg-blue-50/40 p-3 rounded-lg space-y-2">
                  <div class="flex items-center justify-between text-xs">
                    <span class="font-bold text-[#0058A3] uppercase text-[10px]">{{ rec.category }}</span>
                    <span class="font-mono text-[10px] text-slate-500">Conf: {{ (rec.confidenceScore * 100).toFixed(0) }}%</span>
                  </div>
                  <h4 class="font-bold text-xs text-slate-900">{{ rec.title }}</h4>
                  <p class="text-xs text-slate-700 leading-snug">{{ rec.recommendation }}</p>

                  <div class="pt-2 border-t border-slate-200 flex items-center justify-between">
                    <span class="text-[10px] text-slate-500 font-mono">{{ rec.status }}</span>
                    @if (rec.status === 'RECOMMENDED') {
                      <button (click)="state.applyAiRecommendation(rec.id)" 
                              class="bg-[#0058A3] hover:bg-blue-900 text-white font-extrabold text-[10px] px-2.5 py-1 rounded shadow">
                        APPROVE & EXECUTE
                      </button>
                    } @else {
                      <span class="text-emerald-700 font-bold text-[10px]">EXECUTED ✓</span>
                    }
                  </div>
                </div>
              }
            </div>
          </div>

          <!-- Warehouse Utilisation & Capacity Card -->
          <div class="bg-white border border-slate-300 rounded-lg shadow-sm p-5 space-y-3">
            <h3 class="font-extrabold text-sm uppercase text-slate-900 tracking-wider border-b border-slate-200 pb-2 flex items-center gap-2">
              <mat-icon class="text-slate-700">pie_chart</mat-icon>
              STORAGE CAPACITY & CONGESTION
            </h3>

            <div class="space-y-2">
              <div>
                <div class="flex justify-between text-xs font-bold mb-1">
                  <span>Warehouse Storage Utilisation</span>
                  <span class="font-mono text-[#0058A3]">{{ state.warehouseUtilisationPct() }}%</span>
                </div>
                <div class="w-full bg-slate-200 rounded-full h-2.5">
                  <div class="bg-[#0058A3] h-2.5 rounded-full" [style.width.%]="state.warehouseUtilisationPct()"></div>
                </div>
              </div>

              <div>
                <div class="flex justify-between text-xs font-bold mb-1">
                  <span>Aisle Congestion Index</span>
                  <span class="font-mono text-amber-600">{{ state.congestionScore() }}/100</span>
                </div>
                <div class="w-full bg-slate-200 rounded-full h-2.5">
                  <div class="bg-amber-500 h-2.5 rounded-full" [style.width.%]="state.congestionScore()"></div>
                </div>
              </div>
            </div>
          </div>

        </div>

      </div>

    </div>
  `
})
export class ControlCentreComponent {
  readonly state = inject(WarehouseStateEngine);

  getLogBadgeClass(status: string) {
    switch (status) {
      case 'SUCCESS': return 'bg-emerald-500 text-black font-extrabold px-1.5 py-0.5 rounded text-[9px] uppercase';
      case 'WARN': return 'bg-red-500 text-white font-extrabold px-1.5 py-0.5 rounded text-[9px] uppercase';
      case 'EXEC': return 'bg-[#FFDA1A] text-black font-extrabold px-1.5 py-0.5 rounded text-[9px] uppercase';
      default: return 'bg-blue-500 text-white font-extrabold px-1.5 py-0.5 rounded text-[9px] uppercase';
    }
  }

  getOrderStatusBadgeClass(status: string) {
    switch (status) {
      case 'COMPLETED': return 'bg-emerald-100 text-emerald-800 font-extrabold text-[10px] px-2 py-0.5 rounded';
      case 'READY':
      case 'COLLECTION_READY': return 'bg-blue-100 text-blue-900 font-extrabold text-[10px] px-2 py-0.5 rounded';
      case 'PICKING': return 'bg-amber-100 text-amber-900 font-extrabold text-[10px] px-2 py-0.5 rounded';
      default: return 'bg-slate-200 text-slate-800 font-bold text-[10px] px-2 py-0.5 rounded';
    }
  }

  getRiskBadgeClass(risk: string) {
    switch (risk) {
      case 'CRITICAL':
      case 'HIGH': return 'bg-red-100 text-red-800 font-black text-[10px] px-2 py-0.5 rounded';
      case 'MEDIUM': return 'bg-amber-100 text-amber-800 font-bold text-[10px] px-2 py-0.5 rounded';
      default: return 'bg-emerald-100 text-emerald-800 font-bold text-[10px] px-2 py-0.5 rounded';
    }
  }
}
