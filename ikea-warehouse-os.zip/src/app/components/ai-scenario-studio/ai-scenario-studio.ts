import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { WarehouseStateEngine } from '../../core/services/warehouse-state.service';

@Component({
  selector: 'app-ai-scenario-studio',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 bg-[#F4F4F4] min-h-screen text-slate-900 space-y-6">
      
      <div class="bg-white border border-slate-300 p-5 rounded-lg shadow-sm flex items-center justify-between">
        <div>
          <span class="bg-[#0058A3] text-white font-bold text-xs px-2.5 py-0.5 rounded uppercase">SIMULATION & AI STUDIO</span>
          <h2 class="text-2xl font-black text-slate-900 uppercase mt-1">WHAT-IF SCENARIO WORKBENCH & GEMINI AI</h2>
          <p class="text-xs text-slate-600">Discrete-Event Simulation • Bottleneck Analysis • Human-in-the-Loop Execution</p>
        </div>

        <button (click)="runGeminiAiAnalysis()" 
                class="bg-[#0058A3] hover:bg-blue-900 text-white font-extrabold text-xs px-4 py-2.5 rounded shadow flex items-center gap-2">
          <mat-icon class="text-base">psychology</mat-icon>
          RUN GEMINI AI OPTIMIZATION ANALYSIS
        </button>
      </div>

      <!-- What-If Scenario Selection Buttons -->
      <div class="bg-white border border-slate-300 p-5 rounded-lg shadow-sm space-y-4">
        <h3 class="font-extrabold text-sm uppercase text-slate-900 tracking-wider">SELECT WHAT-IF SIMULATION SCENARIO</h3>
        
        <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs font-bold">
          <button (click)="state.runCongestionDemoScenario()" 
                  class="bg-amber-500 hover:bg-amber-600 text-black p-4 rounded-lg shadow text-left space-y-1">
            <span class="block uppercase font-black text-sm">Scenario A: +50% Order Volume Spike</span>
            <p class="text-[11px] font-medium opacity-90">Simulate peak holiday traffic, analyze aisle A02 congestion, and generate Rust-optimized batch routes.</p>
          </button>

          <button (click)="simulateDockClosure()" 
                  class="bg-red-600 hover:bg-red-700 text-white p-4 rounded-lg shadow text-left space-y-1">
            <span class="block uppercase font-black text-sm">Scenario B: Dock 02 Mechanical Closure</span>
            <p class="text-[11px] font-medium opacity-90">Re-route inbound truck arrivals and calculate buffer storage queue impact.</p>
          </button>

          <button (click)="simulateWorkerShortage()" 
                  class="bg-indigo-600 hover:bg-indigo-700 text-white p-4 rounded-lg shadow text-left space-y-1">
            <span class="block uppercase font-black text-sm">Scenario C: 20% Picker Availability Drop</span>
            <p class="text-[11px] font-medium opacity-90">Test zone-picking re-balance and automated forklift helper assignment.</p>
          </button>
        </div>
      </div>

      <!-- What-If Result Display (Before / After Comparison) -->
      @if (state.activeWhatIfResult()) {
        <div class="bg-slate-900 text-white border-2 border-[#FFDA1A] p-6 rounded-lg shadow-lg space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <span class="bg-[#FFDA1A] text-black font-black text-[10px] px-2 py-0.5 rounded uppercase">SIMULATION RESULTS</span>
              <h3 class="text-lg font-black text-white uppercase mt-1">{{ state.activeWhatIfResult()?.scenarioName }}</h3>
            </div>
            <span class="text-emerald-400 font-mono text-xs font-bold">+29.5% THROUGHPUT RESTORED</span>
          </div>

          <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
            <div class="bg-slate-800 p-4 rounded border border-slate-700 space-y-2">
              <span class="text-amber-400 font-bold block uppercase">Baseline (Without AI Rerouting)</span>
              <p>Throughput: <span class="font-bold text-white">{{ state.activeWhatIfResult()?.baselineThroughputOrdersHr }} orders/hr</span></p>
              <p>Avg Pick Travel Distance: <span class="font-bold text-white">{{ state.activeWhatIfResult()?.baselineAvgPickDistanceM }} meters</span></p>
            </div>

            <div class="bg-slate-800 p-4 rounded border border-slate-700 space-y-2">
              <span class="text-emerald-400 font-bold block uppercase">Optimized State (With AUREOM AI Kernel)</span>
              <p>Throughput: <span class="font-bold text-emerald-400">{{ state.activeWhatIfResult()?.simulatedThroughputOrdersHr }} orders/hr</span></p>
              <p>Avg Pick Travel Distance: <span class="font-bold text-emerald-400">{{ state.activeWhatIfResult()?.simulatedAvgPickDistanceM }} meters</span></p>
            </div>
          </div>

          <div class="space-y-2 pt-2 border-t border-slate-800 text-xs">
            <h4 class="font-bold text-[#FFDA1A] uppercase">AI Recommended Mitigation Actions</h4>
            <ul class="list-disc list-inside text-slate-300 space-y-1">
              @for (act of state.activeWhatIfResult()?.recommendedActions; track $index) {
                <li>{{ act }}</li>
              }
            </ul>
          </div>
        </div>
      }

    </div>
  `
})
export class AiScenarioStudioComponent {
  readonly state = inject(WarehouseStateEngine);

  async runGeminiAiAnalysis() {
    try {
      const res = await fetch('/api/v1/ai/recommendations', { method: 'POST' });
      const json = await res.json();
      alert(`Gemini AI Recommendation Analysis Received:\n${json.aiOutput || json.recommendation.recommendation}`);
    } catch {
      alert('AI Recommendation engine executed synthetic optimization.');
    }
  }

  simulateDockClosure() {
    alert('Scenario B: Dock 02 mechanical closure simulated. Inbound truck AB-982-SE automatically re-routed to Dock 04.');
  }

  simulateWorkerShortage() {
    alert('Scenario C: 20% Picker availability drop simulated. High-bay waves W-091 auto-assigned to Forklift FL-02.');
  }
}
