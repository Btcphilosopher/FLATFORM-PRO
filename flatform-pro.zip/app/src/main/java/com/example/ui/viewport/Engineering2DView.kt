package com.example.ui.viewport

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.FurnitureComponent
import com.example.domain.model.FurnitureProject
import com.example.ui.theme.*
import kotlin.math.min

enum class OrthoViewPlane(val label: String) {
    FRONT("Front Elevation (X-Y)"),
    TOP("Plan View (X-Z)"),
    SIDE_LEFT("Left Section (Z-Y)"),
    REAR("Rear Elevation (X-Y)")
}

@Composable
fun Engineering2DView(
    project: FurnitureProject,
    selectedComponentId: String?,
    onSelectComponent: (String?) -> Unit,
    modifier: Modifier = Modifier
) {
    var activePlane by remember { mutableStateOf(OrthoViewPlane.FRONT) }
    var showBoreHoles by remember { mutableStateOf(true) }
    var showCenterlines by remember { mutableStateOf(true) }
    val textMeasurer = rememberTextMeasurer()

    Box(
        modifier = modifier
            .background(CadBackground)
            .testTag("engineering_2d_container")
    ) {
        // 2D Drafting Canvas
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .testTag("cad_canvas_2d")
        ) {
            val canvasW = size.width
            val canvasH = size.height

            // Technical Drafting Grid
            val gridStep = 40f
            var gx = 0f
            while (gx < canvasW) {
                drawLine(color = CadBorderSubtle.copy(alpha = 0.4f), start = Offset(gx, 0f), end = Offset(gx, canvasH), strokeWidth = 0.5f)
                gx += gridStep
            }
            var gy = 0f
            while (gy < canvasH) {
                drawLine(color = CadBorderSubtle.copy(alpha = 0.4f), start = Offset(0f, gy), end = Offset(canvasW, gy), strokeWidth = 0.5f)
                gy += gridStep
            }

            val p = project.parameters
            val margin = 80f

            // Auto-scale drawing to fit available canvas
            val (objW, objH) = when (activePlane) {
                OrthoViewPlane.FRONT, OrthoViewPlane.REAR -> p.widthMm to p.heightMm
                OrthoViewPlane.TOP -> p.widthMm to p.depthMm
                OrthoViewPlane.SIDE_LEFT -> p.depthMm to p.heightMm
            }

            val scale = min((canvasW - margin * 2) / objW, (canvasH - margin * 2) / objH) * 0.85f
            val startX = (canvasW - (objW * scale)) / 2f
            val startY = (canvasH + (objH * scale)) / 2f // Invert Y for architectural drafting

            // Outer Bounds Box
            drawRect(
                color = CadAccentBlue.copy(alpha = 0.05f),
                topLeft = Offset(startX, startY - (objH * scale)),
                size = Size(objW * scale, objH * scale)
            )

            // Draw individual panels according to active ortho plane
            project.components.filter { it.isVisible }.forEach { comp ->
                val isSelected = comp.id == selectedComponentId
                drawComponent2D(
                    comp = comp,
                    plane = activePlane,
                    scale = scale,
                    startX = startX,
                    startY = startY,
                    isSelected = isSelected,
                    showBoreHoles = showBoreHoles
                )
            }

            // Draw Centerlines
            if (showCenterlines) {
                val midX = startX + (objW * scale) / 2f
                val midY = startY - (objH * scale) / 2f
                val dashEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 6f, 3f, 6f), 0f)

                // Vertical Centerline
                drawLine(
                    color = CadAccentRed.copy(alpha = 0.7f),
                    start = Offset(midX, startY - (objH * scale) - 20f),
                    end = Offset(midX, startY + 20f),
                    strokeWidth = 1f,
                    pathEffect = dashEffect
                )
                // Horizontal Centerline
                drawLine(
                    color = CadAccentRed.copy(alpha = 0.7f),
                    start = Offset(startX - 20f, midY),
                    end = Offset(startX + (objW * scale) + 20f, midY),
                    strokeWidth = 1f,
                    pathEffect = dashEffect
                )
            }

            // Draw CAD Dimension Leader Lines with Arrowheads
            draw2dDimension(
                p1 = Offset(startX, startY + 30f),
                p2 = Offset(startX + (objW * scale), startY + 30f),
                text = "${objW.toInt()} mm",
                textMeasurer = textMeasurer
            )

            draw2dDimension(
                p1 = Offset(startX - 30f, startY),
                p2 = Offset(startX - 30f, startY - (objH * scale)),
                text = "${objH.toInt()} mm",
                textMeasurer = textMeasurer
            )
        }

        // Top Plane Selector
        Row(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(12.dp)
                .background(CadSurface.copy(alpha = 0.9f), RoundedCornerShape(8.dp))
                .border(1.dp, CadBorder, RoundedCornerShape(8.dp))
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            OrthoViewPlane.values().forEach { plane ->
                val isActive = activePlane == plane
                Surface(
                    onClick = { activePlane = plane },
                    shape = RoundedCornerShape(6.dp),
                    color = if (isActive) CadAccentBlue.copy(alpha = 0.2f) else Color.Transparent,
                    border = if (isActive) androidx.compose.foundation.BorderStroke(1.dp, CadAccentBlue) else null
                ) {
                    Text(
                        text = plane.label,
                        style = TextStyle(
                            fontSize = 11.sp,
                            fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
                            color = if (isActive) CadAccentBlue else CadTextSecondary
                        ),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }
        }

        // Drawing Legend & Scale Tag (Bottom Right)
        Card(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(12.dp),
            colors = CardDefaults.cardColors(containerColor = CadSurfaceVariant.copy(alpha = 0.9f)),
            border = androidx.compose.foundation.BorderStroke(1.dp, CadBorder),
            shape = RoundedCornerShape(6.dp)
        ) {
            Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text("DIN ISO 128 TECHNICAL BLUEPRINT", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = CadAccentAmber)
                Text("Scale: 1:10 Metric | 32mm System Standard", fontSize = 9.sp, color = CadTextSecondary)
            }
        }
    }
}

private fun DrawScope.drawComponent2D(
    comp: FurnitureComponent,
    plane: OrthoViewPlane,
    scale: Float,
    startX: Float,
    startY: Float,
    isSelected: Boolean,
    showBoreHoles: Boolean
) {
    val (cx, cy, cw, ch) = when (plane) {
        OrthoViewPlane.FRONT, OrthoViewPlane.REAR -> {
            Quad(comp.position.x, comp.position.y, comp.dimensions.width, comp.dimensions.height)
        }
        OrthoViewPlane.TOP -> {
            Quad(comp.position.x, comp.position.z, comp.dimensions.width, comp.dimensions.depth)
        }
        OrthoViewPlane.SIDE_LEFT -> {
            Quad(comp.position.z, comp.position.y, comp.dimensions.depth, comp.dimensions.height)
        }
    }

    val px = startX + (cx * scale)
    val py = startY - ((cy + ch) * scale)
    val pw = cw * scale
    val ph = ch * scale

    // Fill
    val fillColor = if (isSelected) CadAccentBlue.copy(alpha = 0.35f) else CadSurfaceElevated.copy(alpha = 0.7f)
    drawRect(color = fillColor, topLeft = Offset(px, py), size = Size(pw, ph))

    // Border
    val strokeColor = if (isSelected) CadAccentBlue else CadBorderBright.copy(alpha = 0.8f)
    drawRect(color = strokeColor, topLeft = Offset(px, py), size = Size(pw, ph), style = Stroke(width = if (isSelected) 2f else 1f))

    // Bore Holes in 2D
    if (showBoreHoles) {
        comp.operations.forEach { op ->
            val hx = px + (op.xMm * scale)
            val hy = py + (op.yMm * scale)
            drawCircle(color = CadAccentCyan, radius = 2.5f, center = Offset(hx, hy), style = Stroke(width = 1f))
        }
    }
}

private fun DrawScope.draw2dDimension(
    p1: Offset,
    p2: Offset,
    text: String,
    textMeasurer: TextMeasurer
) {
    drawLine(color = CadAccentAmber, start = p1, end = p2, strokeWidth = 1.2f)

    // Dimension Extension Ticks
    drawCircle(color = CadAccentAmber, radius = 3f, center = p1)
    drawCircle(color = CadAccentAmber, radius = 3f, center = p2)

    val mid = Offset((p1.x + p2.x) / 2f, (p1.y + p2.y) / 2f)
    val layout = textMeasurer.measure(
        text = text,
        style = TextStyle(color = CadAccentAmber, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    )

    drawRect(
        color = CadBackground,
        topLeft = Offset(mid.x - layout.size.width / 2f - 3f, mid.y - layout.size.height / 2f - 2f),
        size = Size(layout.size.width + 6f, layout.size.height + 4f)
    )
    drawText(textLayoutResult = layout, topLeft = Offset(mid.x - layout.size.width / 2f, mid.y - layout.size.height / 2f))
}

private data class Quad(val x: Float, val y: Float, val w: Float, val h: Float)
