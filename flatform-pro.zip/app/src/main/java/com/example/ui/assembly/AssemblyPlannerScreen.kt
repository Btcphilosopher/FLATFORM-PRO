package com.example.ui.assembly

import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.AssemblyStep
import com.example.domain.model.FurnitureProject
import com.example.ui.theme.*
import com.example.ui.viewport.CameraState
import com.example.ui.viewport.ShadingMode
import com.example.ui.viewport.Viewport3D

@Composable
fun AssemblyPlannerScreen(
    project: FurnitureProject,
    modifier: Modifier = Modifier
) {
    var currentStepIndex by remember { mutableStateOf(0) }
    val steps = project.assemblySteps
    val activeStep = steps.getOrNull(currentStepIndex)

    var cameraState by remember { mutableStateOf(CameraState(yawDeg = 30f, pitchDeg = 20f, distance = 3000f)) }

    Row(
        modifier = modifier
            .fillMaxSize()
            .background(CadBackground)
            .testTag("assembly_planner_screen")
    ) {
        // Left Column: Step Guide & Instructions
        Column(
            modifier = Modifier
                .width(420.dp)
                .fillMaxHeight()
                .background(CadSurface)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "FLAT-PACK ASSEMBLY GUIDE",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = CadAccentBlue,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Step ${currentStepIndex + 1} of ${steps.size}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = CadTextPrimary
                    )
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = CadSurfaceElevated
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(Icons.Default.Timer, contentDescription = null, tint = CadAccentAmber, modifier = Modifier.size(14.dp))
                        Text(
                            text = "~${steps.sumOf { it.estimatedMinutes }} mins total",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = CadAccentAmber
                        )
                    }
                }
            }

            // Step Progress Bar
            LinearProgressIndicator(
                progress = { (currentStepIndex + 1).toFloat() / steps.size.coerceAtLeast(1) },
                modifier = Modifier.fillMaxWidth().height(6.dp),
                color = CadAccentBlue,
                trackColor = CadSurfaceVariant
            )

            HorizontalDivider(color = CadBorder)

            if (activeStep != null) {
                // Active Step Content Card
                Card(
                    colors = CardDefaults.cardColors(containerColor = CadSurfaceVariant),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CadAccentBlue),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().weight(1f)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = activeStep.title,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = CadTextPrimary
                        )

                        Text(
                            text = activeStep.description,
                            fontSize = 12.sp,
                            color = CadTextSecondary,
                            lineHeight = 17.sp
                        )

                        // Hardware Required Section
                        if (activeStep.hardwareRequired.isNotEmpty()) {
                            Text("Fasteners & Hardware Needed:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CadAccentCyan)
                            activeStep.hardwareRequired.forEach { hw ->
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = CadAccentCyan, modifier = Modifier.size(14.dp))
                                    Text(hw, fontSize = 11.sp, color = CadTextPrimary)
                                }
                            }
                        }

                        // Tools Required Section
                        if (activeStep.toolsRequired.isNotEmpty()) {
                            Text("Tools Required:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CadAccentAmber)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                activeStep.toolsRequired.forEach { tool ->
                                    Surface(shape = RoundedCornerShape(4.dp), color = CadSurfaceElevated) {
                                        Text(tool, fontSize = 10.sp, color = CadTextPrimary, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                    }
                                }
                            }
                        }

                        // Pro Tip Callout
                        if (activeStep.tip.isNotEmpty()) {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = CadAccentAmber.copy(alpha = 0.1f)),
                                border = androidx.compose.foundation.BorderStroke(1.dp, CadAccentAmber.copy(alpha = 0.4f)),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(modifier = Modifier.padding(8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Icon(Icons.Default.Lightbulb, contentDescription = null, tint = CadAccentAmber, modifier = Modifier.size(16.dp))
                                    Text(activeStep.tip, fontSize = 11.sp, color = CadAccentAmber, lineHeight = 15.sp)
                                }
                            }
                        }
                    }
                }
            }

            // Step Navigation Buttons (Previous / Next)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { if (currentStepIndex > 0) currentStepIndex-- },
                    enabled = currentStepIndex > 0,
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.weight(1f).height(40.dp).testTag("btn_prev_step")
                ) {
                    Icon(Icons.Default.ArrowBack, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Previous")
                }

                Button(
                    onClick = { if (currentStepIndex < steps.size - 1) currentStepIndex++ },
                    enabled = currentStepIndex < steps.size - 1,
                    shape = RoundedCornerShape(6.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = CadAccentBlue, contentColor = Color.Black),
                    modifier = Modifier.weight(1f).height(40.dp).testTag("btn_next_step")
                ) {
                    Text("Next Stage")
                    Spacer(Modifier.width(4.dp))
                    Icon(Icons.Default.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
                }
            }
        }

        VerticalDivider(color = CadBorder)

        // Right Column: Interactive 3D Exploded Stage Assembly Viewport
        Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
            Viewport3D(
                project = project,
                selectedComponentId = activeStep?.involvedComponentIds?.firstOrNull(),
                onSelectComponent = {},
                cameraState = cameraState,
                onUpdateCamera = { cameraState = it },
                shadingMode = ShadingMode.EXPLODED,
                onShadingModeChange = {},
                explodedFactor = 0.45f,
                onExplodedFactorChange = {},
                showDimensions = false,
                onToggleDimensions = {},
                showHardware = true,
                onToggleHardware = {},
                activeTool = "select",
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}
