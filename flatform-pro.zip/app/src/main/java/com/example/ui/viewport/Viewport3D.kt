package com.example.ui.viewport

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.materials.MaterialLibrary
import com.example.domain.model.FurnitureComponent
import com.example.domain.model.FurnitureProject
import com.example.domain.model.Vector3D
import com.example.ui.theme.*
import kotlin.math.max
import kotlin.math.min

@Composable
fun Viewport3D(
    project: FurnitureProject,
    selectedComponentId: String?,
    onSelectComponent: (String?) -> Unit,
    cameraState: CameraState,
    onUpdateCamera: (CameraState) -> Unit,
    shadingMode: ShadingMode,
    onShadingModeChange: (ShadingMode) -> Unit,
    explodedFactor: Float,
    onExplodedFactorChange: (Float) -> Unit,
    showDimensions: Boolean,
    onToggleDimensions: () -> Unit,
    showHardware: Boolean,
    onToggleHardware: () -> Unit,
    activeTool: String,
    modifier: Modifier = Modifier
) {
    val textMeasurer = rememberTextMeasurer()
    var hoveredCompId by remember { mutableStateOf<String?>(null) }
    var currentProjectedComponents by remember { mutableStateOf<List<ProjectedComponent>>(emptyList()) }

    Box(
        modifier = modifier
            .background(CadBackground)
            .testTag("viewport_3d_container")
    ) {
        // Main 3D Canvas
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .testTag("cad_canvas_3d")
                .pointerInput(activeTool, cameraState) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        if (activeTool == "pan" || zoom != 1f) {
                            val newDistance = (cameraState.distance / zoom).coerceIn(800f, 9000f)
                            val newPanX = cameraState.panX + pan.x
                            val newPanY = cameraState.panY + pan.y
                            onUpdateCamera(cameraState.copy(distance = newDistance, panX = newPanX, panY = newPanY))
                        } else {
                            // Orbit by default
                            val newYaw = (cameraState.yawDeg + pan.x * 0.4f) % 360f
                            val newPitch = (cameraState.pitchDeg - pan.y * 0.4f).coerceIn(-85f, 85f)
                            onUpdateCamera(cameraState.copy(yawDeg = newYaw, pitchDeg = newPitch))
                        }
                    }
                }
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDrag = { change, dragAmount ->
                            change.consume()
                            val hit = currentProjectedComponents.lastOrNull { comp ->
                                Viewport3DEngine.hitTest(change.position.x, change.position.y, comp)
                            }
                            hoveredCompId = hit?.component?.id
                        },
                        onDragEnd = {
                            hoveredCompId?.let { onSelectComponent(it) }
                        }
                    )
                }
        ) {
            val canvasW = size.width
            val canvasH = size.height

            // 1. Draw Technical Background Grid
            drawCadFloorGrid(cameraState, canvasW, canvasH)

            // Calculate world center of the assembly
            val worldCenter = Vector3D(
                x = project.parameters.widthMm / 2f,
                y = project.parameters.heightMm / 2f,
                z = project.parameters.depthMm / 2f
            )

            // 2. Project all components
            val projected = project.components.filter { it.isVisible }.map { comp ->
                val mat = MaterialLibrary.findById(comp.materialId)
                val isSel = comp.id == selectedComponentId
                Viewport3DEngine.projectCuboid(
                    comp = comp,
                    camera = cameraState,
                    screenWidth = canvasW,
                    screenHeight = canvasH,
                    worldCenter = worldCenter,
                    baseColor = mat.primaryColor,
                    explodedFactor = explodedFactor,
                    isSelected = isSel,
                    shadingMode = shadingMode
                )
            }
            currentProjectedComponents = projected

            // 3. Render Depth-Sorted Faces
            val allFaces = projected.flatMap { it.faces }.sortedByDescending { it.averageDepthZ }

            allFaces.forEach { face ->
                val path = Path().apply {
                    if (face.points.isNotEmpty()) {
                        moveTo(face.points[0].x, face.points[0].y)
                        for (i in 1 until face.points.size) {
                            lineTo(face.points[i].x, face.points[i].y)
                        }
                        close()
                    }
                }

                if (shadingMode != ShadingMode.WIREFRAME) {
                    drawPath(
                        path = path,
                        color = Color(face.color),
                        style = androidx.compose.ui.graphics.drawscope.Fill
                    )
                }

                // Panel Edge Border Lines
                val isComponentSelected = face.componentId == selectedComponentId
                val isHovered = face.componentId == hoveredCompId

                val edgeColor = when {
                    isComponentSelected -> CadAccentBlue
                    isHovered -> CadAccentCyan
                    shadingMode == ShadingMode.WIREFRAME -> CadAccentBlue
                    shadingMode == ShadingMode.TECHNICAL_SOLID -> Color(0xFF1E293B)
                    else -> Color(0x661A202C)
                }
                val edgeWidth = if (isComponentSelected || isHovered) 2.5f else 1.0f

                drawPath(
                    path = path,
                    color = edgeColor,
                    style = Stroke(width = edgeWidth)
                )
            }

            // 4. Draw Hardware Indicators (Bore holes, hinge cups, cam locks)
            if (showHardware) {
                drawHardwareDrillings(project, cameraState, canvasW, canvasH, worldCenter, explodedFactor)
            }

            // 5. Draw CAD 3D Dimension Leader Lines
            if (showDimensions) {
                drawDimensionCallouts(project, cameraState, canvasW, canvasH, worldCenter, textMeasurer)
            }

            // 6. Draw 3D Orientation Axis Gizmo (Bottom Left)
            drawAxisGizmo(cameraState, textMeasurer)
        }

        // Viewport Top-Left Overlay: Telemetry & Shading Bar
        Row(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(12.dp)
                .background(CadSurface.copy(alpha = 0.9f), RoundedCornerShape(8.dp))
                .border(1.dp, CadBorder, RoundedCornerShape(8.dp))
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            // Shading Mode selector
            ShadingMode.values().forEach { mode ->
                val isActive = shadingMode == mode
                Surface(
                    onClick = { onShadingModeChange(mode) },
                    shape = RoundedCornerShape(6.dp),
                    color = if (isActive) CadAccentBlue.copy(alpha = 0.2f) else Color.Transparent,
                    border = if (isActive) androidx.compose.foundation.BorderStroke(1.dp, CadAccentBlue) else null,
                    modifier = Modifier.testTag("mode_${mode.name.lowercase()}")
                ) {
                    Text(
                        text = mode.name.replace("_", " ").lowercase().capitalize(),
                        style = TextStyle(
                            fontSize = 11.sp,
                            fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
                            color = if (isActive) CadAccentBlue else CadTextSecondary
                        ),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                    )
                }
            }

            VerticalDivider(modifier = Modifier.height(18.dp), color = CadBorder)

            // Dimension toggle
            IconButton(
                onClick = onToggleDimensions,
                modifier = Modifier.size(28.dp).testTag("btn_toggle_dimensions")
            ) {
                Icon(
                    imageVector = Icons.Default.Straighten,
                    contentDescription = "Toggle Dimensions",
                    tint = if (showDimensions) CadAccentAmber else CadTextMuted,
                    modifier = Modifier.size(16.dp)
                )
            }

            // Hardware toggle
            IconButton(
                onClick = onToggleHardware,
                modifier = Modifier.size(28.dp).testTag("btn_toggle_hardware")
            ) {
                Icon(
                    imageVector = Icons.Default.Build,
                    contentDescription = "Toggle Hardware Drillings",
                    tint = if (showHardware) CadAccentGreen else CadTextMuted,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        // Viewport Top-Right Camera View Presets
        Row(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(12.dp)
                .background(CadSurface.copy(alpha = 0.9f), RoundedCornerShape(8.dp))
                .border(1.dp, CadBorder, RoundedCornerShape(8.dp))
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            val presets = listOf(
                "ISO" to CameraState(yawDeg = 45f, pitchDeg = 30f, distance = 3200f),
                "FRONT" to CameraState(yawDeg = 0f, pitchDeg = 0f, distance = 2900f, projection = ViewportProjection.ORTHOGRAPHIC),
                "TOP" to CameraState(yawDeg = 0f, pitchDeg = 89f, distance = 2900f, projection = ViewportProjection.ORTHOGRAPHIC),
                "SIDE" to CameraState(yawDeg = 90f, pitchDeg = 0f, distance = 2900f, projection = ViewportProjection.ORTHOGRAPHIC)
            )

            presets.forEach { (label, targetCam) ->
                OutlinedButton(
                    onClick = { onUpdateCamera(targetCam) },
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    shape = RoundedCornerShape(4.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = CadSurfaceVariant,
                        contentColor = CadTextPrimary
                    ),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CadBorder),
                    modifier = Modifier.height(26.dp).testTag("btn_preset_$label")
                ) {
                    Text(label, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                }
            }

            // Zoom Reset
            IconButton(
                onClick = {
                    onUpdateCamera(CameraState(yawDeg = 35f, pitchDeg = 22f, distance = 3200f, panX = 0f, panY = 0f))
                },
                modifier = Modifier.size(26.dp).testTag("btn_reset_view")
            ) {
                Icon(
                    imageVector = Icons.Default.FitScreen,
                    contentDescription = "Fit View",
                    tint = CadAccentBlue,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        // Bottom-Center Exploded View Slider (if Exploded or active)
        AnimatedVisibility(
            visible = shadingMode == ShadingMode.EXPLODED || explodedFactor > 0.01f,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 16.dp)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = CadSurfaceElevated.copy(alpha = 0.95f)),
                border = androidx.compose.foundation.BorderStroke(1.dp, CadAccentBlue),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .width(360.dp)
                    .padding(horizontal = 8.dp)
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.Layers, contentDescription = null, tint = CadAccentBlue, modifier = Modifier.size(16.dp))
                            Text("Exploded Assembly Displacement", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CadTextPrimary)
                        }
                        Text("${(explodedFactor * 100).toInt()}%", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CadAccentCyan)
                    }
                    Slider(
                        value = explodedFactor,
                        onValueChange = onExplodedFactorChange,
                        valueRange = 0f..1.5f,
                        colors = SliderDefaults.colors(
                            thumbColor = CadAccentBlue,
                            activeTrackColor = CadAccentBlue,
                            inactiveTrackColor = CadBorder
                        ),
                        modifier = Modifier.height(24.dp).testTag("slider_exploded_view")
                    )
                }
            }
        }
    }
}

private fun DrawScope.drawCadFloorGrid(
    camera: CameraState,
    screenWidth: Float,
    screenHeight: Float
) {
    val gridSizeMm = 4000f
    val stepMm = 200f
    val worldCenter = Vector3D(0f, 0f, 0f)

    var current = -gridSizeMm / 2f
    while (current <= gridSizeMm / 2f) {
        val p1 = Viewport3DEngine.project3DTo2D(Vector3D(current, 0f, -gridSizeMm / 2f), camera, screenWidth, screenHeight, worldCenter)
        val p2 = Viewport3DEngine.project3DTo2D(Vector3D(current, 0f, gridSizeMm / 2f), camera, screenWidth, screenHeight, worldCenter)
        val p3 = Viewport3DEngine.project3DTo2D(Vector3D(-gridSizeMm / 2f, 0f, current), camera, screenWidth, screenHeight, worldCenter)
        val p4 = Viewport3DEngine.project3DTo2D(Vector3D(gridSizeMm / 2f, 0f, current), camera, screenWidth, screenHeight, worldCenter)

        val isMajor = (current.toInt() % 1000) == 0
        val color = if (isMajor) CadGridMajor else CadGridMinor

        drawLine(color = color, start = Offset(p1.screenX, p1.screenY), end = Offset(p2.screenX, p2.screenY), strokeWidth = if (isMajor) 1.2f else 0.6f)
        drawLine(color = color, start = Offset(p3.screenX, p3.screenY), end = Offset(p4.screenX, p4.screenY), strokeWidth = if (isMajor) 1.2f else 0.6f)

        current += stepMm
    }
}

private fun DrawScope.drawDimensionCallouts(
    project: FurnitureProject,
    camera: CameraState,
    screenWidth: Float,
    screenHeight: Float,
    worldCenter: Vector3D,
    textMeasurer: TextMeasurer
) {
    val p = project.parameters
    val w = p.widthMm
    val h = p.heightMm
    val d = p.depthMm

    // 1. Width dimension callout (bottom front)
    val wStart = Viewport3DEngine.project3DTo2D(Vector3D(0f, -60f, -60f), camera, screenWidth, screenHeight, worldCenter)
    val wEnd = Viewport3DEngine.project3DTo2D(Vector3D(w, -60f, -60f), camera, screenWidth, screenHeight, worldCenter)
    drawDimensionLine(wStart, wEnd, "W: ${w.toInt()} mm", textMeasurer)

    // 2. Height dimension callout (right side)
    val hStart = Viewport3DEngine.project3DTo2D(Vector3D(w + 60f, 0f, -60f), camera, screenWidth, screenHeight, worldCenter)
    val hEnd = Viewport3DEngine.project3DTo2D(Vector3D(w + 60f, h, -60f), camera, screenWidth, screenHeight, worldCenter)
    drawDimensionLine(hStart, hEnd, "H: ${h.toInt()} mm", textMeasurer)

    // 3. Depth dimension callout (right bottom depth)
    val dStart = Viewport3DEngine.project3DTo2D(Vector3D(w + 60f, -60f, 0f), camera, screenWidth, screenHeight, worldCenter)
    val dEnd = Viewport3DEngine.project3DTo2D(Vector3D(w + 60f, -60f, d), camera, screenWidth, screenHeight, worldCenter)
    drawDimensionLine(dStart, dEnd, "D: ${d.toInt()} mm", textMeasurer)
}

private fun DrawScope.drawDimensionLine(
    p1: ProjectedPoint,
    p2: ProjectedPoint,
    label: String,
    textMeasurer: TextMeasurer
) {
    val start = Offset(p1.screenX, p1.screenY)
    val end = Offset(p2.screenX, p2.screenY)

    drawLine(color = CadAccentAmber, start = start, end = end, strokeWidth = 1.5f)

    // Ticks at ends
    drawCircle(color = CadAccentAmber, radius = 3.5f, center = start)
    drawCircle(color = CadAccentAmber, radius = 3.5f, center = end)

    // Label at midpoint
    val mid = Offset((start.x + end.x) / 2f, (start.y + end.y) / 2f)
    val layout = textMeasurer.measure(
        text = label,
        style = TextStyle(
            color = CadAccentAmber,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    )

    drawRect(
        color = CadBackground.copy(alpha = 0.85f),
        topLeft = Offset(mid.x - layout.size.width / 2f - 4f, mid.y - layout.size.height / 2f - 2f),
        size = androidx.compose.ui.geometry.Size(layout.size.width + 8f, layout.size.height + 4f)
    )
    drawText(
        textLayoutResult = layout,
        topLeft = Offset(mid.x - layout.size.width / 2f, mid.y - layout.size.height / 2f)
    )
}

private fun DrawScope.drawHardwareDrillings(
    project: FurnitureProject,
    camera: CameraState,
    screenWidth: Float,
    screenHeight: Float,
    worldCenter: Vector3D,
    explodedFactor: Float
) {
    project.components.forEach { comp ->
        val compPos = comp.position + (comp.explosiveOffset * explodedFactor)
        comp.operations.forEach { op ->
            val pt = compPos + Vector3D(op.xMm, op.yMm, 0f)
            val proj = Viewport3DEngine.project3DTo2D(pt, camera, screenWidth, screenHeight, worldCenter)

            val radius = when (op.type) {
                com.example.domain.model.CncOperationType.HINGE_CUP_35MM -> 7f
                com.example.domain.model.CncOperationType.CAM_LOCK_POCKET_15MM -> 5f
                else -> 3f
            }

            drawCircle(
                color = CadAccentCyan,
                radius = radius,
                center = Offset(proj.screenX, proj.screenY),
                style = Stroke(width = 1.5f)
            )
            drawCircle(
                color = CadAccentCyan.copy(alpha = 0.3f),
                radius = radius,
                center = Offset(proj.screenX, proj.screenY)
            )
        }
    }
}

private fun DrawScope.drawAxisGizmo(camera: CameraState, textMeasurer: TextMeasurer) {
    val gizmoCenter = Offset(50f, size.height - 50f)
    val axisLen = 32f

    val origin = Vector3D(0f, 0f, 0f)
    val xAxis = Vector3D(axisLen, 0f, 0f)
    val yAxis = Vector3D(0f, axisLen, 0f)
    val zAxis = Vector3D(0f, 0f, axisLen)

    val pOrig = Viewport3DEngine.project3DTo2D(origin, camera, 0f, 0f, origin)
    val pX = Viewport3DEngine.project3DTo2D(xAxis, camera, 0f, 0f, origin)
    val pY = Viewport3DEngine.project3DTo2D(yAxis, camera, 0f, 0f, origin)
    val pZ = Viewport3DEngine.project3DTo2D(zAxis, camera, 0f, 0f, origin)

    val dX = Offset(pX.screenX - pOrig.screenX, pX.screenY - pOrig.screenY)
    val dY = Offset(pY.screenX - pOrig.screenX, pY.screenY - pOrig.screenY)
    val dZ = Offset(pZ.screenX - pOrig.screenX, pZ.screenY - pOrig.screenY)

    // X Axis (Red)
    drawLine(color = Color(0xFFEF4444), start = gizmoCenter, end = gizmoCenter + dX, strokeWidth = 2.5f)
    // Y Axis (Green)
    drawLine(color = Color(0xFF10B981), start = gizmoCenter, end = gizmoCenter + dY, strokeWidth = 2.5f)
    // Z Axis (Blue)
    drawLine(color = Color(0xFF3B82F6), start = gizmoCenter, end = gizmoCenter + dZ, strokeWidth = 2.5f)

    drawCircle(color = CadTextPrimary, radius = 3f, center = gizmoCenter)
}

private fun String.capitalize(): String = replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
