import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { WarehouseStateEngine } from '../../core/services/warehouse-state.service';

@Component({
  selector: 'app-inventory-app',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 bg-[#F4F4F4] min-h-screen text-slate-900 space-y-6">
      
      <div class="bg-white border border-slate-300 p-5 rounded-lg shadow-sm flex items-center justify-between">
        <div>
          <span class="bg-[#0058A3] text-white font-bold text-xs px-2.5 py-0.5 rounded uppercase">STOCK CONTROL</span>
          <h2 class="text-2xl font-black text-slate-900 uppercase mt-1">INVENTORY CONTROL & IMMUTABLE LEDGER</h2>
          <p class="text-xs text-slate-600">Available To Promise (ATP) Calculation • Cycle Counting Audit • Event Ledger History</p>
        </div>

        <span class="bg-slate-900 text-white font-mono text-xs px-3 py-1.5 rounded">
          {{ state.inventoryLedger().length }} Ledger Events
        </span>
      </div>

      <!-- Tab Switcher: Available To Promise Stock vs Event Ledger -->
      <div class="flex gap-2 border-b border-slate-300 pb-2">
        <button (click)="activeTab.set('ATP')" 
                [class]="activeTab() === 'ATP' ? 'bg-[#0058A3] text-white font-extrabold px-4 py-2 rounded text-xs shadow' : 'bg-white text-slate-700 font-bold px-4 py-2 rounded text-xs border border-slate-300'">
          AVAILABLE TO PROMISE (ATP) STOCK
        </button>
        <button (click)="activeTab.set('LEDGER')" 
                [class]="activeTab() === 'LEDGER' ? 'bg-[#0058A3] text-white font-extrabold px-4 py-2 rounded text-xs shadow' : 'bg-white text-slate-700 font-bold px-4 py-2 rounded text-xs border border-slate-300'">
          IMMUTABLE INVENTORY AUDIT LEDGER
        </button>
      </div>

      @if (activeTab() === 'ATP') {
        <!-- ATP Stock Breakdown Table -->
        <div class="bg-white border border-slate-300 rounded-lg shadow-sm overflow-hidden">
          <div class="p-4 bg-slate-900 text-white flex justify-between items-center text-xs">
            <span class="font-extrabold uppercase">ATP Formula = Physical - Reserved - Allocated + ConfirmedInbound - SafetyBuffer</span>
            <span class="text-slate-400 font-mono">Real-time Stock Balances</span>
          </div>

          <div class="overflow-x-auto">
            <table class="w-full text-left text-xs border-collapse">
              <thead>
                <tr class="bg-slate-100 text-slate-700 font-extrabold uppercase border-b border-slate-300">
                  <th class="p-3">SKU</th>
                  <th class="p-3">Physical Stock</th>
                  <th class="p-3">Reserved</th>
                  <th class="p-3">Allocated</th>
                  <th class="p-3">Inbound ASN</th>
                  <th class="p-3">Safety Buffer</th>
                  <th class="p-3 text-right">ATP Balance</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-200 font-mono">
                @for (item of state.availableToPromiseList(); track item.sku) {
                  <tr class="hover:bg-blue-50/50">
                    <td class="p-3 font-bold text-[#0058A3]">{{ item.sku }}</td>
                    <td class="p-3 font-bold text-slate-900">{{ item.physicalStock }}</td>
                    <td class="p-3 text-slate-600">{{ item.reservedStock }}</td>
                    <td class="p-3 text-amber-700 font-bold">{{ item.allocatedStock }}</td>
                    <td class="p-3 text-emerald-700 font-bold">+{{ item.confirmedInbound }}</td>
                    <td class="p-3 text-slate-500">-{{ item.safetyBuffer }}</td>
                    <td class="p-3 text-right font-black text-emerald-700 text-sm">{{ item.availableToPromise }}</td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </div>
      } @else {
        <!-- Immutable Event Ledger Table -->
        <div class="bg-white border border-slate-300 rounded-lg shadow-sm overflow-hidden">
          <div class="p-4 bg-slate-900 text-white flex justify-between items-center text-xs">
            <span class="font-extrabold uppercase">Audit Log: Every inventory movement is timestamped & attributable</span>
            <span class="text-slate-400 font-mono">Cryptographic Correlation ID</span>
          </div>

          <div class="overflow-x-auto">
            <table class="w-full text-left text-xs border-collapse font-mono">
              <thead>
                <tr class="bg-slate-100 text-slate-700 font-extrabold uppercase border-b border-slate-300">
                  <th class="p-3">Event ID</th>
                  <th class="p-3">Timestamp</th>
                  <th class="p-3">SKU</th>
                  <th class="p-3">Location</th>
                  <th class="p-3">Qty</th>
                  <th class="p-3">Event Type</th>
                  <th class="p-3">Worker</th>
                  <th class="p-3">Reason</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-200">
                @for (evt of state.inventoryLedger(); track evt.eventId) {
                  <tr class="hover:bg-blue-50/50">
                    <td class="p-3 font-bold text-[#0058A3]">{{ evt.eventId }}</td>
                    <td class="p-3 text-slate-600 text-[11px]">{{ evt.timestamp }}</td>
                    <td class="p-3 font-bold text-slate-900">{{ evt.sku }}</td>
                    <td class="p-3 font-bold text-slate-800">{{ evt.locationId }}</td>
                    <td class="p-3 font-bold text-emerald-700">+{{ evt.quantity }}</td>
                    <td class="p-3">
                      <span class="bg-blue-100 text-[#0058A3] font-bold text-[10px] px-2 py-0.5 rounded">
                        {{ evt.newState }}
                      </span>
                    </td>
                    <td class="p-3 text-slate-700">{{ evt.workerId }}</td>
                    <td class="p-3 text-slate-600 font-sans text-[11px]">{{ evt.reason }}</td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </div>
      }

    </div>
  `
})
export class InventoryAppComponent {
  readonly state = inject(WarehouseStateEngine);
  readonly activeTab = signal<'ATP' | 'LEDGER'>('ATP');
}
