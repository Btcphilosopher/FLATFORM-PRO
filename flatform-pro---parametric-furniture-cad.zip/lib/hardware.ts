import { HardwareItem } from '@/types/furniture';

export interface HardwareCatalogItem {
  code: string;
  name: string;
  category: 'hinge' | 'slide' | 'cam_lock' | 'dowel' | 'screw' | 'handle' | 'shelf_pin' | 'foot' | 'bracket';
  manufacturer: string;
  unitPrice: number;
  specs: string;
}

export const HARDWARE_CATALOG: HardwareCatalogItem[] = [
  {
    code: 'CAM-MINIFIX-15',
    name: 'Häfele Minifix 15 Cam Casing + Connecting Bolt',
    category: 'cam_lock',
    manufacturer: 'Häfele',
    unitPrice: 0.42,
    specs: 'Zinc alloy casing 15mm dia × 12mm depth, M6 steel connecting bolt',
  },
  {
    code: 'DOWEL-BE-8X30',
    name: 'Fluted Hardwood Dowel 8 × 30 mm',
    category: 'dowel',
    manufacturer: 'Würth',
    unitPrice: 0.04,
    specs: 'Steamed beech FSC-certified with chamfered ends and longitudinal glue grooves',
  },
  {
    code: 'SCREW-CONF-7X50',
    name: 'Confirmat Assembly Screw 7.0 × 50 mm SW4',
    category: 'screw',
    manufacturer: 'Spax',
    unitPrice: 0.12,
    specs: 'Zinc-plated carbon steel with flat countersunk head and stepped pilot drill requirement',
  },
  {
    code: 'HINGE-BLUM-CLIP-110',
    name: 'Blum Clip Top BLUMOTION 110° Concealed Hinge',
    category: 'hinge',
    manufacturer: 'Blum',
    unitPrice: 4.85,
    specs: 'Integrated soft-close damper, 35mm cup drilling, 3-way tool-free cam adjustment',
  },
  {
    code: 'SLIDE-BLUM-MOVENTO-550',
    name: 'Blum MOVENTO 760H Undermount Runner 550mm (40kg)',
    category: 'slide',
    manufacturer: 'Blum',
    unitPrice: 28.5,
    specs: 'Synchronized feather-light glide, BLUMOTION soft-close, 4-dimensional front adjustment',
  },
  {
    code: 'HANDLE-BAR-160-BLK',
    name: 'Architectural Solid Brass Bar Pull (160mm CC)',
    category: 'handle',
    manufacturer: 'Formani',
    unitPrice: 12.0,
    specs: 'Matte black PVD coat, 12mm rod diameter, 160mm center-to-center hole spacing',
  },
  {
    code: 'PIN-SHELF-DUO-5MM',
    name: 'Duplo 5mm Steel Shelf Support with Anti-Tilt Lip',
    category: 'shelf_pin',
    manufacturer: 'Hettich',
    unitPrice: 0.18,
    specs: 'Nickel-plated hardened steel, 5mm shaft diameter with rubber grip pad',
  },
  {
    code: 'FOOT-ADJ-LEVELER-M10',
    name: 'Heavy Duty Internal M10 Plinth Leveler (150kg)',
    category: 'foot',
    manufacturer: 'Camar',
    unitPrice: 1.65,
    specs: 'Through-floor hex key adjustment, 0-25mm height range, nylon base pad',
  },
];
