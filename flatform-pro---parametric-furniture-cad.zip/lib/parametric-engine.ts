import {
  FurnitureComponent,
  FurnitureProject,
  HardwareItem,
  MachiningGroove,
  MachiningHole,
  ParametricConfig,
  Vector3D,
} from '@/types/furniture';

/**
 * Recalculates all components, 3D coordinates, thicknesses, and hardware
 * for any parametric furniture design.
 */
export function generateParametricComponents(
  config: ParametricConfig
): { components: FurnitureComponent[]; hardware: HardwareItem[] } {
  const components: FurnitureComponent[] = [];
  const hardware: HardwareItem[] = [];

  const {
    width,
    height,
    depth,
    carcassThickness: t,
    backPanelThickness: tBack,
    backPanelInset,
    plinthHeight,
    baysCount,
    shelvesPerBay,
    hasDoors,
    doorGap,
    doorOpeningAngle,
    hasDrawers,
    drawersCount,
    drawerHeightMm,
    drawerClearance,
    defaultCarcassMaterialId,
    defaultFrontMaterialId,
    defaultBackMaterialId,
    jointType,
  } = config;

  // Origin point: (0, 0, 0) is at Bottom Center of the carcass footprint.
  // X: Left (-width/2) to Right (+width/2)
  // Y: Bottom (0) to Top (height)
  // Z: Front (+depth/2) to Back (-depth/2)

  const internalHeight = height - plinthHeight - 2 * t;
  const internalDepth = depth - backPanelInset - tBack;
  const carcassYBottom = plinthHeight;

  // 1. STRUCTURE: LEFT SIDE PANEL
  const leftSidePanel: FurnitureComponent = {
    id: 'comp_side_left',
    name: 'Left Side Panel',
    type: 'side_left',
    category: 'structure',
    dimensions: { width: t, height: height - plinthHeight, depth: depth },
    position: {
      x: -width / 2 + t / 2,
      y: plinthHeight + (height - plinthHeight) / 2,
      z: 0,
    },
    rotation: { x: 0, y: 0, z: 0 },
    materialId: defaultCarcassMaterialId,
    thicknessMm: t,
    quantity: 1,
    visible: true,
    locked: false,
    grainDirection: 'length',
    edgeTreatments: {
      top: '1.0mm_abs',
      bottom: '0.4mm_pvc',
      left: '1.0mm_abs', // front edge
      right: '0.4mm_pvc', // back edge
    },
    machiningHoles: [
      { id: 'h1', diameterMm: 15, depthMm: 12, x: 50, y: 30, face: 'left', purpose: 'cam_housing' },
      { id: 'h2', diameterMm: 8, depthMm: 24, x: 50, y: 62, face: 'left', purpose: 'dowel' },
      { id: 'h3', diameterMm: 15, depthMm: 12, x: depth - 50, y: 30, face: 'left', purpose: 'cam_housing' },
      { id: 'h4', diameterMm: 8, depthMm: 24, x: depth - 50, y: 62, face: 'left', purpose: 'dowel' },
      { id: 'h5', diameterMm: 5, depthMm: 13, x: 100, y: internalHeight * 0.33, face: 'right', purpose: 'shelf_pin' },
      { id: 'h6', diameterMm: 5, depthMm: 13, x: 100, y: internalHeight * 0.66, face: 'right', purpose: 'shelf_pin' },
    ],
    machiningGrooves: [
      {
        id: 'g_back',
        name: 'Back Panel Groove 6×8mm',
        widthMm: tBack + 0.5,
        depthMm: 8,
        offsetMm: backPanelInset,
        direction: 'vertical',
        purpose: 'back_panel_slot',
      },
    ],
    hardwareIds: ['hw_cam_01', 'hw_dowel_01'],
  };
  components.push(leftSidePanel);

  // 2. STRUCTURE: RIGHT SIDE PANEL
  const rightSidePanel: FurnitureComponent = {
    id: 'comp_side_right',
    name: 'Right Side Panel',
    type: 'side_right',
    category: 'structure',
    dimensions: { width: t, height: height - plinthHeight, depth: depth },
    position: {
      x: width / 2 - t / 2,
      y: plinthHeight + (height - plinthHeight) / 2,
      z: 0,
    },
    rotation: { x: 0, y: 0, z: 0 },
    materialId: defaultCarcassMaterialId,
    thicknessMm: t,
    quantity: 1,
    visible: true,
    locked: false,
    grainDirection: 'length',
    edgeTreatments: {
      top: '1.0mm_abs',
      bottom: '0.4mm_pvc',
      left: '1.0mm_abs',
      right: '0.4mm_pvc',
    },
    machiningHoles: [
      { id: 'h7', diameterMm: 15, depthMm: 12, x: 50, y: 30, face: 'right', purpose: 'cam_housing' },
      { id: 'h8', diameterMm: 8, depthMm: 24, x: 50, y: 62, face: 'right', purpose: 'dowel' },
      { id: 'h9', diameterMm: 15, depthMm: 12, x: depth - 50, y: 30, face: 'right', purpose: 'cam_housing' },
      { id: 'h10', diameterMm: 8, depthMm: 24, x: depth - 50, y: 62, face: 'right', purpose: 'dowel' },
    ],
    machiningGrooves: [
      {
        id: 'g_back_r',
        name: 'Back Panel Groove 6×8mm',
        widthMm: tBack + 0.5,
        depthMm: 8,
        offsetMm: backPanelInset,
        direction: 'vertical',
        purpose: 'back_panel_slot',
      },
    ],
    hardwareIds: ['hw_cam_02', 'hw_dowel_02'],
  };
  components.push(rightSidePanel);

  // 3. STRUCTURE: BOTTOM PANEL
  const bottomPanelWidth = width - 2 * t;
  const bottomPanel: FurnitureComponent = {
    id: 'comp_bottom_panel',
    name: 'Bottom Structural Panel',
    type: 'bottom',
    category: 'structure',
    dimensions: { width: bottomPanelWidth, height: t, depth: depth },
    position: {
      x: 0,
      y: carcassYBottom + t / 2,
      z: 0,
    },
    rotation: { x: 0, y: 0, z: 0 },
    materialId: defaultCarcassMaterialId,
    thicknessMm: t,
    quantity: 1,
    visible: true,
    locked: false,
    grainDirection: 'length',
    edgeTreatments: {
      top: '1.0mm_abs',
      bottom: '0.4mm_pvc',
      left: '0.4mm_pvc',
      right: '0.4mm_pvc',
    },
    machiningHoles: [],
    machiningGrooves: [
      {
        id: 'g_back_bot',
        name: 'Back Panel Groove',
        widthMm: tBack + 0.5,
        depthMm: 8,
        offsetMm: backPanelInset,
        direction: 'horizontal',
        purpose: 'back_panel_slot',
      },
    ],
    hardwareIds: [],
  };
  components.push(bottomPanel);

  // 4. STRUCTURE: TOP PANEL
  const topPanel: FurnitureComponent = {
    id: 'comp_top_panel',
    name: 'Top Structural Panel',
    type: 'top',
    category: 'structure',
    dimensions: { width: bottomPanelWidth, height: t, depth: depth },
    position: {
      x: 0,
      y: height - t / 2,
      z: 0,
    },
    rotation: { x: 0, y: 0, z: 0 },
    materialId: defaultCarcassMaterialId,
    thicknessMm: t,
    quantity: 1,
    visible: true,
    locked: false,
    grainDirection: 'length',
    edgeTreatments: {
      top: '1.0mm_abs',
      bottom: '0.4mm_pvc',
      left: '0.4mm_pvc',
      right: '0.4mm_pvc',
    },
    machiningHoles: [],
    machiningGrooves: [
      {
        id: 'g_back_top',
        name: 'Back Panel Groove',
        widthMm: tBack + 0.5,
        depthMm: 8,
        offsetMm: backPanelInset,
        direction: 'horizontal',
        purpose: 'back_panel_slot',
      },
    ],
    hardwareIds: [],
  };
  components.push(topPanel);

  // 5. STRUCTURE: BACK PANEL (Grooved or rabbeted into carcass)
  const backPanelWidth = width - 2 * t + 16; // 8mm rebate each side
  const backPanelHeight = height - plinthHeight - 2 * t + 16;
  const backPanel: FurnitureComponent = {
    id: 'comp_back_panel',
    name: 'Back Enclosure Panel',
    type: 'back',
    category: 'structure',
    dimensions: { width: backPanelWidth, height: backPanelHeight, depth: tBack },
    position: {
      x: 0,
      y: carcassYBottom + t + (height - plinthHeight - 2 * t) / 2,
      z: -depth / 2 + backPanelInset + tBack / 2,
    },
    rotation: { x: 0, y: 0, z: 0 },
    materialId: defaultBackMaterialId,
    thicknessMm: tBack,
    quantity: 1,
    visible: true,
    locked: false,
    grainDirection: 'length',
    edgeTreatments: {
      top: 'none',
      bottom: 'none',
      left: 'none',
      right: 'none',
    },
    machiningHoles: [],
    machiningGrooves: [],
    hardwareIds: [],
  };
  components.push(backPanel);

  // 6. STRUCTURE: PLINTH / TOE-KICK (if enabled)
  if (plinthHeight > 0) {
    const plinthFront: FurnitureComponent = {
      id: 'comp_plinth_front',
      name: 'Front Toe-Kick Plinth',
      type: 'plinth',
      category: 'structure',
      dimensions: { width: width - 2 * t, height: plinthHeight, depth: t },
      position: {
        x: 0,
        y: plinthHeight / 2,
        z: depth / 2 - config.plinthSetback - t / 2,
      },
      rotation: { x: 0, y: 0, z: 0 },
      materialId: defaultCarcassMaterialId,
      thicknessMm: t,
      quantity: 1,
      visible: true,
      locked: false,
      grainDirection: 'length',
      edgeTreatments: {
        top: '0.4mm_pvc',
        bottom: 'none',
        left: 'none',
        right: 'none',
      },
      machiningHoles: [],
      machiningGrooves: [],
      hardwareIds: [],
    };
    components.push(plinthFront);

    // Plinth leveler feet
    for (let f = 0; f < 4; f++) {
      const fx = (f % 2 === 0 ? -1 : 1) * (width / 2 - 80);
      const fz = (f < 2 ? -1 : 1) * (depth / 2 - 80);
      hardware.push({
        id: `hw_foot_${f + 1}`,
        name: `Adjustable Plinth Leveler M10 #${f + 1}`,
        category: 'foot',
        model: 'Camar M10 Heavy Duty',
        manufacturer: 'Camar',
        unitCost: 1.65,
        dimensions: { width: 50, height: plinthHeight - 5, depth: 50 },
        position: { x: fx, y: (plinthHeight - 5) / 2, z: fz },
        rotation: { x: 0, y: 0, z: 0 },
        description: 'Leveler foot for cabinet alignment on uneven floors',
      });
    }
  }

  // 7. INTERNAL PARTITIONS / DIVIDERS (for multi-bay wardrobes/cabinets)
  const partitionCount = Math.max(0, baysCount - 1);
  const bayWidth = (width - 2 * t - partitionCount * t) / baysCount;

  for (let p = 0; p < partitionCount; p++) {
    const px = -width / 2 + t + (p + 1) * bayWidth + p * t + t / 2;
    const partition: FurnitureComponent = {
      id: `comp_partition_${p + 1}`,
      name: `Internal Divider Partition ${p + 1}`,
      type: 'partition',
      category: 'structure',
      dimensions: { width: t, height: internalHeight, depth: internalDepth },
      position: {
        x: px,
        y: carcassYBottom + t + internalHeight / 2,
        z: -depth / 2 + backPanelInset + tBack + internalDepth / 2,
      },
      rotation: { x: 0, y: 0, z: 0 },
      materialId: defaultCarcassMaterialId,
      thicknessMm: t,
      quantity: 1,
      visible: true,
      locked: false,
      grainDirection: 'length',
      edgeTreatments: {
        top: '0.4mm_pvc',
        bottom: '0.4mm_pvc',
        left: '1.0mm_abs',
        right: '0.4mm_pvc',
      },
      machiningHoles: [
        { id: `hp_${p}_1`, diameterMm: 5, depthMm: 12, x: 80, y: internalHeight * 0.25, face: 'left', purpose: 'shelf_pin' },
        { id: `hp_${p}_2`, diameterMm: 5, depthMm: 12, x: 80, y: internalHeight * 0.5, face: 'left', purpose: 'shelf_pin' },
        { id: `hp_${p}_3`, diameterMm: 5, depthMm: 12, x: 80, y: internalHeight * 0.75, face: 'left', purpose: 'shelf_pin' },
      ],
      machiningGrooves: [],
      hardwareIds: [],
    };
    components.push(partition);
  }

  // 8. INTERIOR: SHELVES (Fixed and Adjustable)
  for (let bay = 0; bay < baysCount; bay++) {
    const bayLeftX = -width / 2 + t + bay * (bayWidth + t);
    const bayCenterX = bayLeftX + bayWidth / 2;
    const count = shelvesPerBay[bay] ?? 3;
    const shelfSpacing = internalHeight / (count + 1);

    for (let s = 0; s < count; s++) {
      const shelfY = carcassYBottom + t + (s + 1) * shelfSpacing;
      const isFixed = s === Math.floor(count / 2) && count > 2; // middle shelf can be fixed
      const shelf: FurnitureComponent = {
        id: `comp_shelf_bay${bay + 1}_${s + 1}`,
        name: `Shelf Bay ${bay + 1} #${s + 1} (${isFixed ? 'Fixed' : 'Adjustable'})`,
        type: isFixed ? 'shelf_fixed' : 'shelf_adjustable',
        category: 'interior',
        dimensions: {
          width: bayWidth - 2, // 1mm clearance each side
          height: t,
          depth: internalDepth - config.shelfSetback,
        },
        position: {
          x: bayCenterX,
          y: shelfY,
          z: -depth / 2 + backPanelInset + tBack + (internalDepth - config.shelfSetback) / 2,
        },
        rotation: { x: 0, y: 0, z: 0 },
        materialId: defaultCarcassMaterialId,
        thicknessMm: t,
        quantity: 1,
        visible: true,
        locked: false,
        grainDirection: 'length',
        edgeTreatments: {
          top: '1.0mm_abs', // front facing edge
          bottom: 'none',
          left: '0.4mm_pvc',
          right: '0.4mm_pvc',
        },
        machiningHoles: [],
        machiningGrooves: [],
        hardwareIds: [],
      };
      components.push(shelf);

      // Hardware pins for adjustable shelf
      if (!isFixed) {
        for (let pinIdx = 0; pinIdx < 4; pinIdx++) {
          const pinX = bayCenterX + (pinIdx % 2 === 0 ? -1 : 1) * (bayWidth / 2 - 20);
          const pinZ = (pinIdx < 2 ? -1 : 1) * (internalDepth / 2 - 40);
          hardware.push({
            id: `hw_pin_${bay}_${s}_${pinIdx}`,
            name: `Shelf Pin 5mm Bay ${bay + 1} Shelf ${s + 1}`,
            category: 'shelf_pin',
            model: 'Duplo 5mm Steel Pin',
            manufacturer: 'Hettich',
            unitCost: 0.18,
            dimensions: { width: 5, height: 16, depth: 5 },
            position: { x: pinX, y: shelfY - 5, z: pinZ },
            rotation: { x: 0, y: 0, z: 0 },
            attachedToComponentId: shelf.id,
            description: 'Steel shelf support with anti-tilt pin',
          });
        }
      }
    }
  }

  // 9. DRAWERS (Parametric stack in specified bay or bottom)
  if (hasDrawers && drawersCount > 0) {
    const drawerBayIdx = config.drawerBays[0] ?? 0;
    const dBayLeftX = -width / 2 + t + drawerBayIdx * (bayWidth + t);
    const dBayCenterX = dBayLeftX + bayWidth / 2;
    const dWidth = bayWidth - 2 * drawerClearance;
    const dDepth = internalDepth - 30; // 30mm runner clearance

    for (let d = 0; d < drawersCount; d++) {
      const dY = carcassYBottom + t + d * (drawerHeightMm + drawerClearance) + drawerHeightMm / 2;

      // Drawer Front Face
      const drawerFront: FurnitureComponent = {
        id: `comp_drawer_front_${d + 1}`,
        name: `Drawer Front 0${d + 1}`,
        type: 'drawer_front',
        category: 'drawers',
        dimensions: {
          width: dWidth,
          height: drawerHeightMm - drawerClearance,
          depth: t,
        },
        position: {
          x: dBayCenterX,
          y: dY,
          z: depth / 2 - t / 2,
        },
        rotation: { x: 0, y: 0, z: 0 },
        materialId: defaultFrontMaterialId,
        thicknessMm: t,
        quantity: 1,
        visible: true,
        locked: false,
        grainDirection: 'length',
        edgeTreatments: {
          top: '1.0mm_abs',
          bottom: '1.0mm_abs',
          left: '1.0mm_abs',
          right: '1.0mm_abs',
        },
        machiningHoles: [
          { id: `dh_${d}_1`, diameterMm: 4, depthMm: 18, x: dWidth / 2 - 80, y: drawerHeightMm / 2, face: 'back', purpose: 'handle' },
          { id: `dh_${d}_2`, diameterMm: 4, depthMm: 18, x: dWidth / 2 + 80, y: drawerHeightMm / 2, face: 'back', purpose: 'handle' },
        ],
        machiningGrooves: [],
        hardwareIds: [`hw_handle_d_${d + 1}`, `hw_slide_l_${d + 1}`, `hw_slide_r_${d + 1}`],
      };
      components.push(drawerFront);

      // Drawer Box Body (sub-assembly)
      const drawerBox: FurnitureComponent = {
        id: `comp_drawer_box_${d + 1}`,
        name: `Drawer Internal Box 0${d + 1}`,
        type: 'drawer_box',
        category: 'drawers',
        dimensions: {
          width: dWidth - 24, // 12mm slide clearance per side
          height: drawerHeightMm - 40,
          depth: dDepth,
        },
        position: {
          x: dBayCenterX,
          y: dY - 10,
          z: depth / 2 - t - dDepth / 2,
        },
        rotation: { x: 0, y: 0, z: 0 },
        materialId: 'mat_birch_plywood',
        thicknessMm: 15,
        quantity: 1,
        visible: true,
        locked: false,
        grainDirection: 'length',
        edgeTreatments: {
          top: '0.4mm_pvc',
          bottom: 'none',
          left: 'none',
          right: 'none',
        },
        machiningHoles: [],
        machiningGrooves: [
          {
            id: `dbg_${d}`,
            name: 'Bottom Panel Groove',
            widthMm: 6,
            depthMm: 6,
            offsetMm: 10,
            direction: 'horizontal',
            purpose: 'drawer_bottom_slot',
          },
        ],
        hardwareIds: [],
      };
      components.push(drawerBox);

      // Drawer Pull Handle Hardware
      hardware.push({
        id: `hw_handle_d_${d + 1}`,
        name: `Architectural Bar Pull (160mm) - Drawer ${d + 1}`,
        category: 'handle',
        model: 'Formani PVD Black 160mm',
        manufacturer: 'Formani',
        unitCost: 12.0,
        dimensions: { width: 180, height: 12, depth: 32 },
        position: { x: dBayCenterX, y: dY, z: depth / 2 + 16 },
        rotation: { x: 0, y: 0, z: 0 },
        attachedToComponentId: drawerFront.id,
        description: 'Solid brass bar handle with matte black PVD finish',
      });

      // Blum MOVENTO Drawer Slides
      hardware.push({
        id: `hw_slide_l_${d + 1}`,
        name: `Blum MOVENTO 550mm Slide Pair - Drawer ${d + 1}`,
        category: 'slide',
        model: 'Blum 760H5500B',
        manufacturer: 'Blum',
        unitCost: 28.5,
        dimensions: { width: 24, height: 45, depth: dDepth },
        position: { x: dBayCenterX, y: dY - drawerHeightMm / 2 + 10, z: 0 },
        rotation: { x: 0, y: 0, z: 0 },
        attachedToComponentId: drawerBox.id,
        description: 'Concealed synchronized full-extension slide with BLUMOTION',
      });
    }
  }

  // 10. DOORS (Single, Double, or Multi-bay slab doors)
  if (hasDoors) {
    const doorHeight = internalHeight + t + (plinthHeight === 0 ? t : 0) - doorGap * 2;
    const doorY = carcassYBottom + t / 2 + doorHeight / 2;

    if (baysCount === 1) {
      // Single Door
      const dWidth = width - doorGap * 2;
      const door: FurnitureComponent = {
        id: 'comp_door_1',
        name: 'Single Front Door',
        type: 'door_single',
        category: 'doors',
        dimensions: { width: dWidth, height: doorHeight, depth: t },
        position: {
          x: 0,
          y: doorY,
          z: depth / 2 + t / 2,
        },
        rotation: { x: 0, y: doorOpeningAngle, z: 0 },
        materialId: defaultFrontMaterialId,
        thicknessMm: t,
        quantity: 1,
        visible: true,
        locked: false,
        grainDirection: 'length',
        edgeTreatments: {
          top: '1.0mm_abs',
          bottom: '1.0mm_abs',
          left: '1.0mm_abs',
          right: '1.0mm_abs',
        },
        machiningHoles: [
          { id: 'dh1', diameterMm: 35, depthMm: 13, x: 22.5, y: 100, face: 'back', purpose: 'hinge_cup' },
          { id: 'dh2', diameterMm: 35, depthMm: 13, x: 22.5, y: doorHeight - 100, face: 'back', purpose: 'hinge_cup' },
          { id: 'dh3', diameterMm: 35, depthMm: 13, x: 22.5, y: doorHeight / 2, face: 'back', purpose: 'hinge_cup' },
        ],
        machiningGrooves: [],
        hardwareIds: ['hw_hinge_1', 'hw_hinge_2', 'hw_hinge_3', 'hw_handle_door_1'],
      };
      components.push(door);
    } else {
      // Multi-bay or 2-door wardrobe
      const doorsCount = Math.min(4, Math.max(2, baysCount));
      const individualDoorWidth = (width - (doorsCount + 1) * doorGap) / doorsCount;

      for (let di = 0; di < doorsCount; di++) {
        const isLeftHinged = di % 2 === 0;
        const dx = -width / 2 + doorGap + individualDoorWidth / 2 + di * (individualDoorWidth + doorGap);
        const swingAngle = isLeftHinged ? -doorOpeningAngle : doorOpeningAngle;

        const door: FurnitureComponent = {
          id: `comp_door_${di + 1}`,
          name: `Front Door 0${di + 1} (${isLeftHinged ? 'Left Hinge' : 'Right Hinge'})`,
          type: isLeftHinged ? 'door_left' : 'door_right',
          category: 'doors',
          dimensions: { width: individualDoorWidth, height: doorHeight, depth: t },
          position: {
            x: dx,
            y: doorY,
            z: depth / 2 + t / 2,
          },
          rotation: { x: 0, y: swingAngle, z: 0 },
          materialId: defaultFrontMaterialId,
          thicknessMm: t,
          quantity: 1,
          visible: true,
          locked: false,
          grainDirection: 'length',
          edgeTreatments: {
            top: '1.0mm_abs',
            bottom: '1.0mm_abs',
            left: '1.0mm_abs',
            right: '1.0mm_abs',
          },
          machiningHoles: [
            { id: `dh_${di}_1`, diameterMm: 35, depthMm: 13, x: 22.5, y: 120, face: 'back', purpose: 'hinge_cup' },
            { id: `dh_${di}_2`, diameterMm: 35, depthMm: 13, x: 22.5, y: doorHeight - 120, face: 'back', purpose: 'hinge_cup' },
            { id: `dh_${di}_3`, diameterMm: 35, depthMm: 13, x: 22.5, y: doorHeight / 2, face: 'back', purpose: 'hinge_cup' },
            { id: `dh_${di}_h1`, diameterMm: 4, depthMm: 18, x: individualDoorWidth - 35, y: doorHeight / 2 - 80, face: 'back', purpose: 'handle' },
            { id: `dh_${di}_h2`, diameterMm: 4, depthMm: 18, x: individualDoorWidth - 35, y: doorHeight / 2 + 80, face: 'back', purpose: 'handle' },
          ],
          machiningGrooves: [],
          hardwareIds: [`hw_door_hinge_${di}_1`, `hw_door_hinge_${di}_2`, `hw_door_hinge_${di}_3`, `hw_door_handle_${di + 1}`],
        };
        components.push(door);

        // Hinges for this door (Blum Clip Top Soft-Close)
        for (let hIdx = 0; hIdx < 3; hIdx++) {
          const hingeY = doorY - doorHeight / 2 + (hIdx === 0 ? 120 : hIdx === 1 ? doorHeight / 2 : doorHeight - 120);
          hardware.push({
            id: `hw_door_hinge_${di}_${hIdx + 1}`,
            name: `Blum Clip Top 110° Hinge #${hIdx + 1} (Door ${di + 1})`,
            category: 'hinge',
            model: 'Blum Clip Top BLUMOTION 110°',
            manufacturer: 'Blum',
            unitCost: 4.85,
            dimensions: { width: 35, height: 60, depth: 35 },
            position: {
              x: dx + (isLeftHinged ? -individualDoorWidth / 2 + 22.5 : individualDoorWidth / 2 - 22.5),
              y: hingeY,
              z: depth / 2,
            },
            rotation: { x: 0, y: 0, z: 0 },
            attachedToComponentId: door.id,
            description: 'Concealed cup hinge with integrated soft-close damping',
          });
        }

        // Door handle
        hardware.push({
          id: `hw_door_handle_${di + 1}`,
          name: `Door Bar Pull (160mm) - Door ${di + 1}`,
          category: 'handle',
          model: 'Formani PVD Black 160mm',
          manufacturer: 'Formani',
          unitCost: 12.0,
          dimensions: { width: 12, height: 180, depth: 32 },
          position: {
            x: dx + (isLeftHinged ? individualDoorWidth / 2 - 40 : -individualDoorWidth / 2 + 40),
            y: doorY,
            z: depth / 2 + t + 16,
          },
          rotation: { x: 0, y: 0, z: 0 },
          attachedToComponentId: door.id,
          description: 'Solid architectural door pull handle',
        });
      }
    }
  }

  // 11. GENERAL STRUCTURAL FASTENERS (Cam-locks and Dowels)
  if (jointType === 'cam_lock_dowel') {
    // 8x Cam locks for Top/Bottom to Left/Right side panels
    for (let c = 0; c < 8; c++) {
      const isTop = c < 4;
      const isLeft = c % 2 === 0;
      const isFront = Math.floor(c / 2) % 2 === 0;
      hardware.push({
        id: `hw_minifix_${c + 1}`,
        name: `Häfele Minifix 15 Joint #${c + 1}`,
        category: 'cam_lock',
        model: 'Minifix 15 with Bolt',
        manufacturer: 'Häfele',
        unitCost: 0.42,
        dimensions: { width: 15, height: 12, depth: 15 },
        position: {
          x: isLeft ? -width / 2 + t + 10 : width / 2 - t - 10,
          y: isTop ? height - t - 6 : carcassYBottom + t + 6,
          z: isFront ? depth / 2 - 50 : -depth / 2 + 50,
        },
        rotation: { x: 0, y: 0, z: 0 },
        description: 'Zinc cam lock connector with steel connecting bolt',
      });
    }

    // 16x Hardwood Beech Dowels (8x30mm)
    for (let d = 0; d < 16; d++) {
      hardware.push({
        id: `hw_dowel_${d + 1}`,
        name: `Fluted Hardwood Dowel 8×30mm #${d + 1}`,
        category: 'dowel',
        model: 'Beech 8x30 DIN 68150',
        manufacturer: 'Würth',
        unitCost: 0.04,
        dimensions: { width: 8, height: 30, depth: 8 },
        position: {
          x: (d % 2 === 0 ? -1 : 1) * (width / 2 - t / 2),
          y: (d < 8 ? carcassYBottom + t / 2 : height - t / 2),
          z: -depth / 2 + 30 + (d % 4) * (depth / 4),
        },
        rotation: { x: 0, y: 0, z: 0 },
        description: 'Steamed beech dowel for rigid shear alignment',
      });
    }
  }

  return { components, hardware };
}

/**
 * Creates the primary demonstration project: MODERN OAK WARDROBE (2400 x 600 x 2200 mm)
 */
export function createDefaultWardrobeProject(): FurnitureProject {
  const config: ParametricConfig = {
    width: 2400,
    height: 2200,
    depth: 600,
    carcassThickness: 18,
    backPanelThickness: 6,
    backPanelGrooveDepth: 8,
    backPanelInset: 15,
    plinthHeight: 80,
    plinthSetback: 20,
    jointType: 'cam_lock_dowel',
    baysCount: 3,
    shelvesPerBay: [4, 2, 4],
    shelfSpacingMode: 'equal',
    shelfSetback: 15,
    hasDoors: true,
    doorType: 'slab',
    doorBays: [0, 1, 2],
    doorGap: 2.5,
    doorOpeningAngle: 0,
    hasDrawers: true,
    drawerBays: [1], // Middle bay has 3 stacked drawers
    drawersCount: 3,
    drawerClearance: 3,
    drawerHeightMm: 180,
    drawerSlideType: 'undermount_soft_close',
    defaultCarcassMaterialId: 'mat_oak_veneer',
    defaultFrontMaterialId: 'mat_oak_veneer',
    defaultBackMaterialId: 'mat_raw_mdf',
  };

  const { components, hardware } = generateParametricComponents(config);

  return {
    id: 'proj_modern_oak_wardrobe',
    name: 'MODERN OAK WARDROBE',
    version: '1.0.0',
    category: 'wardrobe',
    createdDate: new Date().toISOString(),
    lastModifiedDate: new Date().toISOString(),
    author: 'Principal CAD Engineer',
    notes: 'Parametric 3-bay enterprise master wardrobe with interior drawers, Blum concealed soft-close joinery and CNC manufacturing drill map.',
    config,
    components,
    hardwareItems: hardware,
    variants: [
      { id: 'var_natural_oak', name: 'Natural Oak (Standard)', description: 'Full crown-cut European Oak veneer with matte lacquer' },
      { id: 'var_walnut_luxury', name: 'American Walnut Luxury', description: 'Deep dark walnut with brass accent hardware', materialOverrideId: 'mat_american_walnut' },
      { id: 'var_nordic_white', name: 'Nordic White & Ash', description: 'Matte white carcass with blonde ash accents', materialOverrideId: 'mat_white_melamine' },
      { id: 'var_charcoal_anthracite', name: 'Anthracite Architectural', description: 'Deep graphite matte finish with black PVD hardware', materialOverrideId: 'mat_anthracite_melamine' },
    ],
    activeVariantId: 'var_natural_oak',
    unitSystem: 'mm',
  };
}

/**
 * Templates for the Project Dashboard
 */
export const FURNITURE_TEMPLATES: {
  id: string;
  name: string;
  category: FurnitureProject['category'];
  dimensions: string;
  description: string;
  componentCountEst: number;
  config: ParametricConfig;
}[] = [
  {
    id: 'tpl_wardrobe_master',
    name: 'Modern 3-Bay Master Wardrobe',
    category: 'wardrobe',
    dimensions: '2400 × 600 × 2200 mm',
    description: '3-bay full height wardrobe with soft-close doors, internal drawers and adjustable shelves.',
    componentCountEst: 28,
    config: {
      width: 2400,
      height: 2200,
      depth: 600,
      carcassThickness: 18,
      backPanelThickness: 6,
      backPanelGrooveDepth: 8,
      backPanelInset: 15,
      plinthHeight: 80,
      plinthSetback: 20,
      jointType: 'cam_lock_dowel',
      baysCount: 3,
      shelvesPerBay: [4, 2, 4],
      shelfSpacingMode: 'equal',
      shelfSetback: 15,
      hasDoors: true,
      doorType: 'slab',
      doorBays: [0, 1, 2],
      doorGap: 2.5,
      doorOpeningAngle: 0,
      hasDrawers: true,
      drawerBays: [1],
      drawersCount: 3,
      drawerClearance: 3,
      drawerHeightMm: 180,
      drawerSlideType: 'undermount_soft_close',
      defaultCarcassMaterialId: 'mat_oak_veneer',
      defaultFrontMaterialId: 'mat_oak_veneer',
      defaultBackMaterialId: 'mat_raw_mdf',
    },
  },
  {
    id: 'tpl_base_cabinet_600',
    name: 'Modular Kitchen Base Cabinet',
    category: 'base_cabinet',
    dimensions: '600 × 580 × 870 mm',
    description: 'Standard euro-box 600mm base unit with adjustable feet, soft-close door and top structural stretchers.',
    componentCountEst: 11,
    config: {
      width: 600,
      height: 870,
      depth: 580,
      carcassThickness: 18,
      backPanelThickness: 6,
      backPanelGrooveDepth: 8,
      backPanelInset: 20,
      plinthHeight: 120,
      plinthSetback: 35,
      jointType: 'confirmat_screw',
      baysCount: 1,
      shelvesPerBay: [1],
      shelfSpacingMode: 'equal',
      shelfSetback: 20,
      hasDoors: true,
      doorType: 'slab',
      doorBays: [0],
      doorGap: 2.0,
      doorOpeningAngle: 0,
      hasDrawers: false,
      drawerBays: [],
      drawersCount: 0,
      drawerClearance: 3,
      drawerHeightMm: 180,
      drawerSlideType: 'undermount_soft_close',
      defaultCarcassMaterialId: 'mat_white_melamine',
      defaultFrontMaterialId: 'mat_white_melamine',
      defaultBackMaterialId: 'mat_raw_mdf',
    },
  },
  {
    id: 'tpl_bookcase_tower',
    name: 'Minimalist Architectural Bookcase',
    category: 'bookcase',
    dimensions: '1000 × 320 × 2000 mm',
    description: 'Clean open display unit with 5 reinforced fixed shelves and solid birch plywood edge details.',
    componentCountEst: 9,
    config: {
      width: 1000,
      height: 2000,
      depth: 320,
      carcassThickness: 18,
      backPanelThickness: 6,
      backPanelGrooveDepth: 8,
      backPanelInset: 12,
      plinthHeight: 60,
      plinthSetback: 15,
      jointType: 'cam_lock_dowel',
      baysCount: 1,
      shelvesPerBay: [5],
      shelfSpacingMode: 'equal',
      shelfSetback: 0,
      hasDoors: false,
      doorType: 'slab',
      doorBays: [],
      doorGap: 2.5,
      doorOpeningAngle: 0,
      hasDrawers: false,
      drawerBays: [],
      drawersCount: 0,
      drawerClearance: 3,
      drawerHeightMm: 180,
      drawerSlideType: 'undermount_soft_close',
      defaultCarcassMaterialId: 'mat_birch_plywood',
      defaultFrontMaterialId: 'mat_birch_plywood',
      defaultBackMaterialId: 'mat_birch_plywood',
    },
  },
  {
    id: 'tpl_sideboard_credenza',
    name: 'Lowline Credenza / TV Unit',
    category: 'sideboard',
    dimensions: '1800 × 450 × 650 mm',
    description: 'Horizontal entertainment credenza with 3 equal bays, acoustic routing and concealed cable management.',
    componentCountEst: 19,
    config: {
      width: 1800,
      height: 650,
      depth: 450,
      carcassThickness: 18,
      backPanelThickness: 6,
      backPanelGrooveDepth: 8,
      backPanelInset: 25,
      plinthHeight: 100,
      plinthSetback: 25,
      jointType: 'cam_lock_dowel',
      baysCount: 3,
      shelvesPerBay: [1, 1, 1],
      shelfSpacingMode: 'equal',
      shelfSetback: 15,
      hasDoors: true,
      doorType: 'slab',
      doorBays: [0, 2],
      doorGap: 2.5,
      doorOpeningAngle: 0,
      hasDrawers: true,
      drawerBays: [1],
      drawersCount: 2,
      drawerClearance: 3,
      drawerHeightMm: 200,
      drawerSlideType: 'undermount_soft_close',
      defaultCarcassMaterialId: 'mat_american_walnut',
      defaultFrontMaterialId: 'mat_american_walnut',
      defaultBackMaterialId: 'mat_raw_mdf',
    },
  },
  {
    id: 'tpl_tall_cabinet',
    name: 'Tall Utility / Pantry Cabinet',
    category: 'tall_cabinet',
    dimensions: '800 × 600 × 2100 mm',
    description: 'High-capacity dual door storage unit with reinforced shelves for heavy kitchen/laundry loads.',
    componentCountEst: 16,
    config: {
      width: 800,
      height: 2100,
      depth: 600,
      carcassThickness: 18,
      backPanelThickness: 6,
      backPanelGrooveDepth: 8,
      backPanelInset: 15,
      plinthHeight: 100,
      plinthSetback: 25,
      jointType: 'cam_lock_dowel',
      baysCount: 1,
      shelvesPerBay: [5],
      shelfSpacingMode: 'equal',
      shelfSetback: 20,
      hasDoors: true,
      doorType: 'slab',
      doorBays: [0],
      doorGap: 2.5,
      doorOpeningAngle: 0,
      hasDrawers: false,
      drawerBays: [],
      drawersCount: 0,
      drawerClearance: 3,
      drawerHeightMm: 180,
      drawerSlideType: 'undermount_soft_close',
      defaultCarcassMaterialId: 'mat_anthracite_melamine',
      defaultFrontMaterialId: 'mat_anthracite_melamine',
      defaultBackMaterialId: 'mat_raw_mdf',
    },
  },
];
