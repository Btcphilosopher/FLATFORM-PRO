package com.example.ui.panels

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Redo
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.DesignVariant
import com.example.domain.model.FurnitureProject
import com.example.domain.model.ProjectHistorySnapshot
import com.example.ui.theme.*

@Composable
fun DesignHistoryAndVariantsPanel(
    project: FurnitureProject,
    historyStack: List<ProjectHistorySnapshot>,
    canUndo: Boolean,
    canRedo: Boolean,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onApplyVariant: (DesignVariant) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxHeight()
            .background(CadSurface)
            .testTag("variants_history_panel")
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "VARIANTS & AUDIT TRAIL",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = CadAccentBlue,
                letterSpacing = 1.sp
            )

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                IconButton(onClick = onUndo, enabled = canUndo, modifier = Modifier.size(26.dp).testTag("btn_undo")) {
                    Icon(Icons.Default.Undo, contentDescription = "Undo", tint = if (canUndo) CadAccentBlue else CadTextMuted, modifier = Modifier.size(16.dp))
                }
                IconButton(onClick = onRedo, enabled = canRedo, modifier = Modifier.size(26.dp).testTag("btn_redo")) {
                    Icon(Icons.Default.Redo, contentDescription = "Redo", tint = if (canRedo) CadAccentBlue else CadTextMuted, modifier = Modifier.size(16.dp))
                }
            }
        }

        HorizontalDivider(color = CadBorder)

        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Variants Section
            item {
                Text("Design Configuration Variants", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CadTextSecondary)
            }

            if (project.variants.isEmpty()) {
                item {
                    Text("No pre-configured variants for this template.", fontSize = 11.sp, color = CadTextMuted)
                }
            } else {
                items(project.variants, key = { it.id }) { variant ->
                    val isActive = project.activeVariantId == variant.id
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onApplyVariant(variant) },
                        colors = CardDefaults.cardColors(
                            containerColor = if (isActive) CadSurfaceElevated else CadSurfaceVariant
                        ),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isActive) CadAccentBlue else CadBorder
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = variant.name,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isActive) CadAccentBlue else CadTextPrimary
                                )
                                if (isActive) {
                                    Surface(shape = RoundedCornerShape(4.dp), color = CadAccentBlue.copy(alpha = 0.2f)) {
                                        Text("Active", fontSize = 9.sp, color = CadAccentBlue, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                                    }
                                }
                            }
                            if (variant.description.isNotEmpty()) {
                                Text(variant.description, fontSize = 10.sp, color = CadTextSecondary)
                            }
                        }
                    }
                }
            }

            // History Snapshots Section
            item {
                Spacer(Modifier.height(8.dp))
                Text("Engineering Revision History", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CadTextSecondary)
            }

            if (historyStack.isEmpty()) {
                item {
                    Text("No previous history states in session.", fontSize = 11.sp, color = CadTextMuted)
                }
            } else {
                items(historyStack.reversed()) { snapshot ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = CadSurfaceVariant.copy(alpha = 0.6f)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CadBorderSubtle),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.History, contentDescription = null, tint = CadTextMuted, modifier = Modifier.size(16.dp))
                            Column {
                                Text(snapshot.description, fontSize = 11.sp, color = CadTextPrimary)
                                Text(
                                    "${snapshot.parameters.widthMm.toInt()}×${snapshot.parameters.heightMm.toInt()}×${snapshot.parameters.depthMm.toInt()} mm • ${snapshot.parameters.shelfCount} shelves",
                                    fontSize = 9.sp,
                                    color = CadTextMuted
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
