package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Editorial Aesthetic: Deep Obsidian, Warm Slate & Rich Lilac Palette
val CadBackground = Color(0xFF111318)
val CadBackgroundDark = Color(0xFF0F1113)
val CadSurface = Color(0xFF1A1C1E)
val CadSurfaceVariant = Color(0xFF333538)
val CadSurfaceElevated = Color(0xFF2E2E31)
val CadSurfacePlum = Color(0xFF1F1B2C)

val CadBorder = Color(0xFF44474E)
val CadBorderSubtle = Color(0xFF333538)
val CadBorderBright = Color(0xFFD0BCFF)

// Editorial Accents
val CadAccentBlue = Color(0xFFD0BCFF) // Editorial Lilac / Lavender
val CadAccentLavender = Color(0xFFD0BCFF)
val CadAccentCyan = Color(0xFFCCC2DC)  // Soft Secondary Lavender
val CadAccentAmber = Color(0xFFEFB8C8) // Warm Rose / Gold
val CadAccentGreen = Color(0xFFA8DAB5) // Editorial Muted Sage Green
val CadAccentRed = Color(0xFFF2B8B5)   // Editorial Soft Coral
val CadAccentPurple = Color(0xFF381E72)
val CadPillActive = Color(0xFF47464F)

// Editorial Typography & Text Callouts
val CadTextPrimary = Color(0xFFE2E2E6)
val CadTextSecondary = Color(0xFFC6C6D0)
val CadTextMuted = Color(0xFF909094)
val CadTextCode = Color(0xFFD0BCFF)

// Viewport Grid & Shading
val CadGridMajor = Color(0xFF333538)
val CadGridMinor = Color(0xFF1F2226)
val CadDimensionLine = Color(0xFF909094)
val CadSelectionGlow = Color(0xFFD0BCFF)
val CadHoverGlow = Color(0x55D0BCFF)
