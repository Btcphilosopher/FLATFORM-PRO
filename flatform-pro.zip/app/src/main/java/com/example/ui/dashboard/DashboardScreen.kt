package com.example.ui.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.FurnitureProject
import com.example.domain.model.FurnitureTemplateType
import com.example.domain.templates.FurnitureTemplate
import com.example.domain.templates.FurnitureTemplates
import com.example.ui.theme.*

@Composable
fun DashboardScreen(
    recentProjects: List<FurnitureProject>,
    onOpenProject: (FurnitureProject) -> Unit,
    onCreateFromTemplate: (FurnitureTemplate) -> Unit,
    onDeleteProject: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(0) } // 0 = New From Template, 1 = Recent Projects

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CadBackground)
            .testTag("dashboard_screen")
    ) {
        // Top Banner / Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(CadSurface)
                .padding(horizontal = 24.dp, vertical = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = CadAccentBlue.copy(alpha = 0.15f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CadAccentBlue)
                ) {
                    Icon(
                        imageVector = Icons.Default.PrecisionManufacturing,
                        contentDescription = null,
                        tint = CadAccentBlue,
                        modifier = Modifier.padding(8.dp).size(28.dp)
                    )
                }

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "FLATFORM PRO",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = CadTextPrimary,
                            letterSpacing = 1.sp
                        )
                        Surface(shape = RoundedCornerShape(4.dp), color = CadAccentCyan.copy(alpha = 0.2f)) {
                            Text("ENTERPRISE CAD v1.0", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = CadAccentCyan, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                        }
                    }
                    Text(
                        text = "Parametric Flat-Pack Furniture Engineering & CAM System",
                        fontSize = 12.sp,
                        color = CadTextSecondary
                    )
                }
            }

            // Quick Actions
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = {
                        val wardrobe = FurnitureTemplates.getByType(FurnitureTemplateType.MODERN_WARDROBE)
                        onCreateFromTemplate(wardrobe)
                    },
                    shape = RoundedCornerShape(6.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = CadAccentBlue),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CadAccentBlue),
                    modifier = Modifier.height(38.dp).testTag("btn_quick_wardrobe")
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Load Oak Wardrobe Demo", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        HorizontalDivider(color = CadBorder)

        // Tab Selector Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TabButton("Engineering Templates", Icons.Default.Dashboard, selectedTab == 0) { selectedTab = 0 }
            TabButton("Recent Workspace Projects (${recentProjects.size})", Icons.Default.FolderOpen, selectedTab == 1) { selectedTab = 1 }
        }

        // Tab Body
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp, vertical = 8.dp)
        ) {
            if (selectedTab == 0) {
                // Template Catalog Grid
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 300.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.fillMaxSize().testTag("grid_templates")
                ) {
                    items(FurnitureTemplates.templates, key = { it.type.name }) { tpl ->
                        TemplateCard(
                            template = tpl,
                            onClick = { onCreateFromTemplate(tpl) }
                        )
                    }
                }
            } else {
                // Recent Projects Grid
                if (recentProjects.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("No saved projects found. Choose a template to begin engineering.", color = CadTextMuted, fontSize = 13.sp)
                    }
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(minSize = 320.dp),
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        modifier = Modifier.fillMaxSize().testTag("grid_recent_projects")
                    ) {
                        items(recentProjects, key = { it.id }) { proj ->
                            ProjectCard(
                                project = proj,
                                onClick = { onOpenProject(proj) },
                                onDelete = { onDeleteProject(proj.id) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TabButton(text: String, icon: androidx.compose.ui.graphics.vector.ImageVector, isSelected: Boolean, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(8.dp),
        color = if (isSelected) CadAccentBlue.copy(alpha = 0.2f) else CadSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) CadAccentBlue else CadBorder)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(icon, contentDescription = null, tint = if (isSelected) CadAccentBlue else CadTextSecondary, modifier = Modifier.size(16.dp))
            Text(text, fontSize = 12.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal, color = if (isSelected) CadAccentBlue else CadTextPrimary)
        }
    }
}

@Composable
private fun TemplateCard(template: FurnitureTemplate, onClick: () -> Unit) {
    val p = template.defaultParams

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("card_template_${template.type.name.lowercase()}"),
        colors = CardDefaults.cardColors(containerColor = CadSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, CadBorder),
        shape = RoundedCornerShape(10.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = CadSurfaceVariant
                ) {
                    Icon(
                        imageVector = when (template.type) {
                            FurnitureTemplateType.MODERN_WARDROBE -> Icons.Default.DoorFront
                            FurnitureTemplateType.BASE_CABINET, FurnitureTemplateType.WALL_CABINET -> Icons.Default.Kitchen
                            FurnitureTemplateType.BOOKCASE -> Icons.Default.MenuBook
                            FurnitureTemplateType.DESK_WITH_DRAWERS -> Icons.Default.Desk
                            FurnitureTemplateType.CHEST_OF_DRAWERS -> Icons.Default.Inbox
                            FurnitureTemplateType.TV_MEDIA_UNIT -> Icons.Default.Tv
                            else -> Icons.Default.Category
                        },
                        contentDescription = null,
                        tint = CadAccentBlue,
                        modifier = Modifier.padding(8.dp).size(20.dp)
                    )
                }

                Surface(shape = RoundedCornerShape(4.dp), color = CadSurfaceVariant) {
                    Text(
                        "${p.widthMm.toInt()}×${p.heightMm.toInt()}×${p.depthMm.toInt()} mm",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = CadAccentCyan,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Text(template.title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = CadTextPrimary)
            Text(template.description, fontSize = 11.sp, color = CadTextSecondary, lineHeight = 16.sp, maxLines = 2)

            HorizontalDivider(color = CadBorderSubtle)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "${p.shelfCount} shelves • ${p.doorCount} doors • ${p.drawerCount} drawers",
                    fontSize = 10.sp,
                    color = CadTextMuted
                )
                Text("Configure →", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CadAccentBlue)
            }
        }
    }
}

@Composable
private fun ProjectCard(project: FurnitureProject, onClick: () -> Unit, onDelete: () -> Unit) {
    val p = project.parameters

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("card_project_${project.id}"),
        colors = CardDefaults.cardColors(containerColor = CadSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, CadBorder),
        shape = RoundedCornerShape(10.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Default.Architecture, contentDescription = null, tint = CadAccentAmber, modifier = Modifier.size(18.dp))
                    Text(project.name, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = CadTextPrimary)
                }

                IconButton(onClick = onDelete, modifier = Modifier.size(24.dp)) {
                    Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = CadTextMuted, modifier = Modifier.size(16.dp))
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(shape = RoundedCornerShape(4.dp), color = CadSurfaceVariant) {
                    Text(
                        "${p.widthMm.toInt()}×${p.heightMm.toInt()}×${p.depthMm.toInt()} mm",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = CadAccentCyan,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }

                Surface(shape = RoundedCornerShape(4.dp), color = CadSurfaceVariant) {
                    Text(
                        "${project.components.size} CNC Parts",
                        fontSize = 10.sp,
                        color = CadTextSecondary,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            HorizontalDivider(color = CadBorderSubtle)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val totalCost = project.bomItems.sumOf { it.totalCost.toDouble() }
                Text("Est: €${String.format("%.2f", totalCost)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CadAccentAmber)
                Text("Open CAD Editor →", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CadAccentBlue)
            }
        }
    }
}
