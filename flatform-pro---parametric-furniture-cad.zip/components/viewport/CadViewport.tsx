'use client';

import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import {
  CameraPreset,
  FurnitureComponent,
  HardwareItem,
  ShadingMode,
  UnitSystem,
} from '@/types/furniture';
import { getMaterialById } from '@/lib/materials';
import {
  Box,
  Eye,
  Layers,
  Maximize2,
  Minimize2,
  Move,
  RotateCw,
  Sliders,
  ZoomIn,
  ZoomOut,
} from 'lucide-react';

interface CadViewportProps {
  components: FurnitureComponent[];
  hardwareItems: HardwareItem[];
  selectedComponentId: string | null;
  onSelectComponent: (id: string | null) => void;
  hoveredComponentId: string | null;
  onHoverComponent: (id: string | null) => void;
  shadingMode: ShadingMode;
  onShadingModeChange: (mode: ShadingMode) => void;
  explodedDistance: number; // 0 to 100
  cameraPreset: CameraPreset;
  onCameraPresetChange: (preset: CameraPreset) => void;
  unitSystem: UnitSystem;
  showDimensions: boolean;
  showGrid: boolean;
  showHardware: boolean;
}

export function CadViewport({
  components,
  hardwareItems,
  selectedComponentId,
  onSelectComponent,
  hoveredComponentId,
  onHoverComponent,
  shadingMode,
  onShadingModeChange,
  explodedDistance,
  cameraPreset,
  onCameraPresetChange,
  unitSystem,
  showDimensions,
  showGrid,
  showHardware,
}: CadViewportProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | THREE.OrthographicCamera | null>(null);
  const perspCameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const orthoCameraRef = useRef<THREE.OrthographicCamera | null>(null);
  const isOrthoRef = useRef<boolean>(false);
  const meshesMapRef = useRef<Map<string, THREE.Mesh>>(new Map());
  const edgesMapRef = useRef<Map<string, THREE.LineSegments>>(new Map());
  const hardwareMeshesRef = useRef<Map<string, THREE.Mesh>>(new Map());
  const modelGroupRef = useRef<THREE.Group | null>(null);
  const gridHelperRef = useRef<THREE.GridHelper | null>(null);
  const axesGizmoCanvasRef = useRef<HTMLCanvasElement>(null);

  // Orbit / Pan state
  const isMouseDownRef = useRef(false);
  const mouseButtonRef = useRef(0);
  const prevMousePosRef = useRef({ x: 0, y: 0 });
  const cameraTargetRef = useRef(new THREE.Vector3(0, 1100, 0));
  const cameraSphericalRef = useRef({ radius: 3600, theta: Math.PI / 4, phi: Math.PI / 3.2 });

  const [fps, setFps] = useState(60);

  // Initialize Three.js Scene
  useEffect(() => {
    if (!containerRef.current) return;
    const container = containerRef.current;
    const width = container.clientWidth;
    const height = container.clientHeight;

    // 1. Scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x16171b);
    sceneRef.current = scene;

    // 2. Cameras
    const aspect = width / height;
    const perspCamera = new THREE.PerspectiveCamera(40, aspect, 10, 25000);
    perspCameraRef.current = perspCamera;

    const frustumSize = 2600;
    const orthoCamera = new THREE.OrthographicCamera(
      (-frustumSize * aspect) / 2,
      (frustumSize * aspect) / 2,
      frustumSize / 2,
      -frustumSize / 2,
      10,
      25000
    );
    orthoCameraRef.current = orthoCamera;

    const camera = isOrthoRef.current ? orthoCamera : perspCamera;
    cameraRef.current = camera;

    // 3. Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    rendererRef.current = renderer;
    container.appendChild(renderer.domElement);

    // 4. Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.95);
    scene.add(ambientLight);

    const dirLight1 = new THREE.DirectionalLight(0xffffff, 1.4);
    dirLight1.position.set(2500, 4500, 3500);
    dirLight1.castShadow = true;
    dirLight1.shadow.mapSize.width = 2048;
    dirLight1.shadow.mapSize.height = 2048;
    dirLight1.shadow.camera.near = 500;
    dirLight1.shadow.camera.far = 12000;
    const d = 2500;
    dirLight1.shadow.camera.left = -d;
    dirLight1.shadow.camera.right = d;
    dirLight1.shadow.camera.top = d;
    dirLight1.shadow.camera.bottom = -d;
    dirLight1.shadow.bias = -0.0005;
    scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0x90a0b0, 0.7);
    dirLight2.position.set(-2500, 2000, -2500);
    scene.add(dirLight2);

    const dirLight3 = new THREE.DirectionalLight(0xffeedd, 0.4);
    dirLight3.position.set(0, -2000, 2000);
    scene.add(dirLight3);

    // 5. Technical CAD Ground Grid
    const gridHelper = new THREE.GridHelper(5000, 50, 0x3b82f6, 0x22262b);
    gridHelper.position.y = -1;
    scene.add(gridHelper);
    gridHelperRef.current = gridHelper;

    // Shadow receiver ground plane
    const planeGeo = new THREE.PlaneGeometry(8000, 8000);
    const planeMat = new THREE.ShadowMaterial({ opacity: 0.25 });
    const shadowPlane = new THREE.Mesh(planeGeo, planeMat);
    shadowPlane.rotation.x = -Math.PI / 2;
    shadowPlane.position.y = -1;
    shadowPlane.receiveShadow = true;
    scene.add(shadowPlane);

    // 6. Furniture Model Group
    const modelGroup = new THREE.Group();
    scene.add(modelGroup);
    modelGroupRef.current = modelGroup;

    // 7. Resize Observer
    const handleResize = () => {
      if (!containerRef.current || !rendererRef.current) return;
      const w = containerRef.current.clientWidth;
      const h = containerRef.current.clientHeight;
      const asp = w / h;

      if (perspCameraRef.current) {
        perspCameraRef.current.aspect = asp;
        perspCameraRef.current.updateProjectionMatrix();
      }
      if (orthoCameraRef.current) {
        const fs = 2600;
        orthoCameraRef.current.left = (-fs * asp) / 2;
        orthoCameraRef.current.right = (fs * asp) / 2;
        orthoCameraRef.current.top = fs / 2;
        orthoCameraRef.current.bottom = -fs / 2;
        orthoCameraRef.current.updateProjectionMatrix();
      }
      rendererRef.current.setSize(w, h);
    };

    const resizeObserver = new ResizeObserver(handleResize);
    resizeObserver.observe(container);

    // 8. Animation Render Loop
    let animationFrameId: number;
    let lastTime = performance.now();
    let frameCount = 0;

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);

      // Camera Spherical Position Update
      const s = cameraSphericalRef.current;
      const target = cameraTargetRef.current;
      const cx = target.x + s.radius * Math.sin(s.phi) * Math.sin(s.theta);
      const cy = target.y + s.radius * Math.cos(s.phi);
      const cz = target.z + s.radius * Math.sin(s.phi) * Math.cos(s.theta);

      const activeCamera = isOrthoRef.current ? orthoCameraRef.current : perspCameraRef.current;
      if (activeCamera) {
        activeCamera.position.set(cx, cy, cz);
        activeCamera.lookAt(target);
      }

      if (rendererRef.current && sceneRef.current && activeCamera) {
        rendererRef.current.render(sceneRef.current, activeCamera);
      }

      // Draw XYZ Orientation Cube in Canvas
      if (axesGizmoCanvasRef.current) {
        renderOrientationGizmo(axesGizmoCanvasRef.current, s);
      }

      // FPS counter calculation
      frameCount++;
      const now = performance.now();
      if (now - lastTime >= 1000) {
        setFps(frameCount);
        frameCount = 0;
        lastTime = now;
      }
    };
    animate();

    return () => {
      cancelAnimationFrame(animationFrameId);
      resizeObserver.disconnect();
      if (rendererRef.current && rendererRef.current.domElement) {
        rendererRef.current.dispose();
        rendererRef.current.domElement.remove();
      }
    };
  }, []);

  // Update Grid Visibility
  useEffect(() => {
    if (gridHelperRef.current) {
      gridHelperRef.current.visible = showGrid;
    }
  }, [showGrid]);

  // Update Camera Preset
  useEffect(() => {
    const s = cameraSphericalRef.current;
    const target = cameraTargetRef.current;

    switch (cameraPreset) {
      case 'perspective':
        isOrthoRef.current = false;
        s.radius = 3600;
        s.theta = Math.PI / 4;
        s.phi = Math.PI / 3.2;
        target.set(0, 1100, 0);
        break;
      case 'isometric':
        isOrthoRef.current = true;
        s.radius = 4000;
        s.theta = Math.PI / 4;
        s.phi = Math.PI / 3.2;
        target.set(0, 1100, 0);
        break;
      case 'front':
        isOrthoRef.current = true;
        s.radius = 3600;
        s.theta = 0;
        s.phi = Math.PI / 2;
        target.set(0, 1100, 0);
        break;
      case 'rear':
        isOrthoRef.current = true;
        s.radius = 3600;
        s.theta = Math.PI;
        s.phi = Math.PI / 2;
        target.set(0, 1100, 0);
        break;
      case 'left':
        isOrthoRef.current = true;
        s.radius = 3600;
        s.theta = -Math.PI / 2;
        s.phi = Math.PI / 2;
        target.set(0, 1100, 0);
        break;
      case 'right':
        isOrthoRef.current = true;
        s.radius = 3600;
        s.theta = Math.PI / 2;
        s.phi = Math.PI / 2;
        target.set(0, 1100, 0);
        break;
      case 'top':
        isOrthoRef.current = true;
        s.radius = 3600;
        s.theta = 0;
        s.phi = 0.001; // nearly top
        target.set(0, 1100, 0);
        break;
      case 'bottom':
        isOrthoRef.current = true;
        s.radius = 3600;
        s.theta = 0;
        s.phi = Math.PI - 0.001;
        target.set(0, 1100, 0);
        break;
    }
  }, [cameraPreset]);

  // Build / Re-render 3D Meshes from parametric components
  useEffect(() => {
    if (!modelGroupRef.current) return;
    const modelGroup = modelGroupRef.current;

    // Clear existing meshes
    while (modelGroup.children.length > 0) {
      const obj = modelGroup.children[0];
      modelGroup.remove(obj);
      if (obj instanceof THREE.Mesh) {
        obj.geometry.dispose();
        if (Array.isArray(obj.material)) {
          obj.material.forEach((m) => m.dispose());
        } else {
          obj.material.dispose();
        }
      }
    }

    meshesMapRef.current.clear();
    edgesMapRef.current.clear();
    hardwareMeshesRef.current.clear();

    // 1. Render Furniture Panels / Components
    for (const comp of components) {
      if (!comp.visible) continue;

      const matDef = getMaterialById(comp.materialId);
      const isSelected = selectedComponentId === comp.id;
      const isHovered = hoveredComponentId === comp.id;

      // Calculate Explosion Offset
      const explosionVec = calculateExplosionVector(comp, explodedDistance);

      // Create Box Geometry
      const geometry = new THREE.BoxGeometry(
        comp.dimensions.width,
        comp.dimensions.height,
        comp.dimensions.depth
      );

      // Create Material according to ShadingMode
      let meshMaterial: THREE.Material;

      if (shadingMode === 'wireframe') {
        meshMaterial = new THREE.MeshBasicMaterial({
          wireframe: true,
          color: isSelected ? 0x3b82f6 : isHovered ? 0x60a5fa : 0x71717a,
        });
      } else if (shadingMode === 'xray') {
        meshMaterial = new THREE.MeshPhysicalMaterial({
          color: isSelected ? 0x3b82f6 : new THREE.Color(matDef.color),
          transparent: true,
          opacity: 0.38,
          roughness: 0.2,
          transmission: 0.7,
          thickness: 15,
        });
      } else if (shadingMode === 'solid') {
        meshMaterial = new THREE.MeshStandardMaterial({
          color: isSelected ? 0x2563eb : isHovered ? 0x3b82f6 : 0xcccccc,
          roughness: 0.45,
          metalness: 0.1,
        });
      } else {
        // Materials preview (Wood grain / Melamine)
        meshMaterial = new THREE.MeshStandardMaterial({
          color: isSelected ? 0x3b82f6 : new THREE.Color(matDef.color),
          roughness: matDef.roughness,
          metalness: matDef.metalness,
        });
      }

      const mesh = new THREE.Mesh(geometry, meshMaterial);
      mesh.castShadow = true;
      mesh.receiveShadow = true;

      // Position + Explosion offset
      mesh.position.set(
        comp.position.x + explosionVec.x,
        comp.position.y + explosionVec.y,
        comp.position.z + explosionVec.z
      );

      // Rotation (e.g. for open door)
      mesh.rotation.set(
        THREE.MathUtils.degToRad(comp.rotation.x),
        THREE.MathUtils.degToRad(comp.rotation.y),
        THREE.MathUtils.degToRad(comp.rotation.z)
      );

      // Store component ID in user data for raycasting
      mesh.userData = { componentId: comp.id, componentName: comp.name };

      // Add CAD Edge Linework (Crucial for professional CAD look!)
      const edgesGeo = new THREE.EdgesGeometry(geometry, 15);
      const edgeColor = isSelected ? 0x60a5fa : isHovered ? 0x93c5fd : 0x1f242b;
      const edgeMat = new THREE.LineBasicMaterial({
        color: edgeColor,
        linewidth: isSelected ? 2 : 1,
      });
      const edges = new THREE.LineSegments(edgesGeo, edgeMat);
      edges.position.copy(mesh.position);
      edges.rotation.copy(mesh.rotation);

      modelGroup.add(mesh);
      modelGroup.add(edges);

      meshesMapRef.current.set(comp.id, mesh);
      edgesMapRef.current.set(comp.id, edges);
    }

    // 2. Render Hardware (Hinges, Cam locks, Screws, Slides, Handles, Pins)
    if (showHardware) {
      for (const hw of hardwareItems) {
        const isHwSelected = selectedComponentId === hw.id;
        const hwGeo = createHardwareGeometry(hw);
        const hwMat = new THREE.MeshStandardMaterial({
          color: isHwSelected ? 0x3b82f6 : hw.category === 'handle' ? 0x18181b : 0xa1a1aa,
          metalness: 0.85,
          roughness: 0.25,
        });

        const hwMesh = new THREE.Mesh(hwGeo, hwMat);
        hwMesh.position.set(hw.position.x, hw.position.y, hw.position.z);
        hwMesh.userData = { componentId: hw.id, hardwareName: hw.name };
        modelGroup.add(hwMesh);
        hardwareMeshesRef.current.set(hw.id, hwMesh);
      }
    }
  }, [
    components,
    hardwareItems,
    selectedComponentId,
    hoveredComponentId,
    shadingMode,
    explodedDistance,
    showHardware,
  ]);

  // Mouse Interaction: Orbit, Pan, Zoom, and Raycast Selection
  const handleMouseDown = (e: React.MouseEvent) => {
    isMouseDownRef.current = true;
    mouseButtonRef.current = e.button;
    prevMousePosRef.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!containerRef.current) return;
    const container = containerRef.current;

    // If mouse is dragging: Orbit (Left click or Middle) or Pan (Right click or Shift+Left)
    if (isMouseDownRef.current) {
      const deltaX = e.clientX - prevMousePosRef.current.x;
      const deltaY = e.clientY - prevMousePosRef.current.y;
      prevMousePosRef.current = { x: e.clientX, y: e.clientY };

      const isPan = mouseButtonRef.current === 2 || mouseButtonRef.current === 1 || e.shiftKey;

      if (isPan) {
        // Pan Camera Target
        const panSpeed = isOrthoRef.current ? 3.0 : 2.2;
        const s = cameraSphericalRef.current;
        const rightVec = new THREE.Vector3(Math.cos(s.theta), 0, -Math.sin(s.theta));
        const upVec = new THREE.Vector3(0, 1, 0);

        cameraTargetRef.current.addScaledVector(rightVec, -deltaX * panSpeed);
        cameraTargetRef.current.addScaledVector(upVec, deltaY * panSpeed);
      } else {
        // Orbit Camera
        const rotateSpeed = 0.005;
        const s = cameraSphericalRef.current;
        s.theta -= deltaX * rotateSpeed;
        s.phi = Math.max(0.05, Math.min(Math.PI - 0.05, s.phi - deltaY * rotateSpeed));
      }
      return;
    }

    // Hover Raycasting
    const rect = container.getBoundingClientRect();
    const mouseX = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    const mouseY = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    const camera = isOrthoRef.current ? orthoCameraRef.current : perspCameraRef.current;
    if (!camera || !sceneRef.current) return;

    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(new THREE.Vector2(mouseX, mouseY), camera);

    const meshes = Array.from(meshesMapRef.current.values());
    const intersects = raycaster.intersectObjects(meshes, false);

    if (intersects.length > 0) {
      const hitId = intersects[0].object.userData.componentId;
      if (hitId !== hoveredComponentId) {
        onHoverComponent(hitId);
      }
    } else if (hoveredComponentId !== null) {
      onHoverComponent(null);
    }
  };

  const handleMouseUp = (e: React.MouseEvent) => {
    isMouseDownRef.current = false;
  };

  const handleClick = (e: React.MouseEvent) => {
    if (!containerRef.current) return;
    const container = containerRef.current;
    const rect = container.getBoundingClientRect();
    const mouseX = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    const mouseY = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    const camera = isOrthoRef.current ? orthoCameraRef.current : perspCameraRef.current;
    if (!camera || !sceneRef.current) return;

    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(new THREE.Vector2(mouseX, mouseY), camera);

    const meshes = Array.from(meshesMapRef.current.values());
    const hwMeshes = Array.from(hardwareMeshesRef.current.values());
    const intersects = raycaster.intersectObjects([...meshes, ...hwMeshes], false);

    if (intersects.length > 0) {
      const hitId = intersects[0].object.userData.componentId;
      onSelectComponent(hitId);
    } else {
      onSelectComponent(null);
    }
  };

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const zoomFactor = e.deltaY > 0 ? 1.08 : 0.92;
    const s = cameraSphericalRef.current;

    if (isOrthoRef.current && orthoCameraRef.current) {
      const ortho = orthoCameraRef.current;
      ortho.zoom = Math.max(0.2, Math.min(6.0, ortho.zoom / zoomFactor));
      ortho.updateProjectionMatrix();
    } else {
      s.radius = Math.max(500, Math.min(15000, s.radius * zoomFactor));
    }
  };

  const handleFitToScreen = () => {
    cameraSphericalRef.current.radius = 3600;
    cameraSphericalRef.current.theta = Math.PI / 4;
    cameraSphericalRef.current.phi = Math.PI / 3.2;
    cameraTargetRef.current.set(0, 1100, 0);
    if (orthoCameraRef.current) {
      orthoCameraRef.current.zoom = 1.0;
      orthoCameraRef.current.updateProjectionMatrix();
    }
  };

  // Find selected component metadata for dimensions overlay
  const selectedComponent = components.find((c) => c.id === selectedComponentId);

  return (
    <div
      id="cad_viewport_container"
      className="relative w-full h-full bg-[#16171B] overflow-hidden select-none cursor-crosshair font-sans"
    >
      {/* Three.js Canvas Container */}
      <div
        ref={containerRef}
        className="w-full h-full"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onWheel={handleWheel}
        onClick={handleClick}
        onContextMenu={(e) => e.preventDefault()}
      />

      {/* Top Floating Viewport Control Bar */}
      <div className="absolute top-3 left-3 flex items-center gap-1.5 p-1 bg-[#1A1B1E]/95 backdrop-blur border border-[#2C2E33] rounded-lg shadow-xl z-10 text-xs">
        {/* Shading Mode Picker */}
        <div className="flex items-center bg-black/40 p-0.5 rounded border border-[#2C2E33]">
          {(['solid', 'wireframe', 'materials', 'xray'] as ShadingMode[]).map((mode) => (
            <button
              key={mode}
              id={`btn_shading_${mode}`}
              onClick={() => onShadingModeChange(mode)}
              className={`px-2.5 py-1 rounded text-[11px] font-bold uppercase tracking-wider transition-colors ${
                shadingMode === mode
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-gray-400 hover:text-white hover:bg-[#222328]'
              }`}
            >
              {mode}
            </button>
          ))}
        </div>

        <div className="h-4 w-px bg-[#2C2E33] mx-1" />

        {/* Camera Preset Dropdown */}
        <div className="flex items-center gap-1">
          {(['perspective', 'isometric', 'front', 'top', 'left'] as CameraPreset[]).map((preset) => (
            <button
              key={preset}
              id={`btn_cam_${preset}`}
              onClick={() => onCameraPresetChange(preset)}
              className={`px-2 py-1 rounded text-[11px] font-medium capitalize transition-colors ${
                cameraPreset === preset
                  ? 'bg-[#222328] text-blue-400 border border-blue-500/50 font-bold'
                  : 'text-gray-400 hover:text-white hover:bg-[#222328]'
              }`}
            >
              {preset}
            </button>
          ))}
        </div>

        <div className="h-4 w-px bg-[#2C2E33] mx-1" />

        {/* Fit to Screen Button */}
        <button
          id="btn_fit_screen"
          onClick={handleFitToScreen}
          title="Fit Model to Viewport (F)"
          className="p-1.5 text-gray-400 hover:text-white hover:bg-[#222328] rounded transition-colors"
        >
          <Maximize2 className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Exploded View Control Bar (Top Right) */}
      <div className="absolute top-3 right-3 flex items-center gap-2 p-1.5 px-3 bg-[#1A1B1E]/95 backdrop-blur border border-[#2C2E33] rounded-lg shadow-xl z-10 text-xs">
        <Layers className="w-3.5 h-3.5 text-blue-400" />
        <span className="text-gray-300 text-[11px] font-medium">Exploded View</span>
        <input
          id="range_exploded_view"
          type="range"
          min="0"
          max="100"
          value={explodedDistance}
          onChange={(e) => {
            // Exploded distance update handled via prop or parent
          }}
          className="w-24 h-1.5 bg-[#2C2E33] rounded-lg appearance-none cursor-pointer accent-[#3B82F6]"
        />
        <span className="text-blue-400 font-mono text-[11px] w-8 text-right font-bold">
          {Math.round(explodedDistance)}%
        </span>
      </div>

      {/* Bottom Left HUD: Active Selection & Dimension Callout */}
      {selectedComponent && (
        <div className="absolute bottom-4 left-4 p-3 bg-[#1A1B1E]/95 backdrop-blur border border-[#2C2E33] rounded-lg shadow-2xl z-10 text-xs space-y-1 max-w-sm pointer-events-none animate-in fade-in duration-150">
          <div className="flex items-center justify-between gap-4">
            <span className="font-bold text-blue-400 text-xs truncate">
              {selectedComponent.name}
            </span>
            <span className="px-1.5 py-0.5 bg-blue-900/40 text-blue-300 text-[10px] rounded border border-blue-700/50 uppercase font-mono">
              {selectedComponent.type.replace(/_/g, ' ')}
            </span>
          </div>
          <div className="grid grid-cols-3 gap-2 pt-1 border-t border-[#2C2E33] text-[11px]">
            <div>
              <span className="text-gray-500 block text-[9px] uppercase font-medium">Width</span>
              <span className="text-gray-200 font-mono font-bold">
                {Math.round(selectedComponent.dimensions.width)} mm
              </span>
            </div>
            <div>
              <span className="text-gray-500 block text-[9px] uppercase font-medium">Height</span>
              <span className="text-gray-200 font-mono font-bold">
                {Math.round(selectedComponent.dimensions.height)} mm
              </span>
            </div>
            <div>
              <span className="text-gray-500 block text-[9px] uppercase font-medium">Thick</span>
              <span className="text-gray-200 font-mono font-bold">
                {selectedComponent.thicknessMm} mm
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Bottom Right CAD Telemetry & Axes Gizmo */}
      <div className="absolute bottom-4 right-4 flex items-center gap-3 p-2 bg-[#1A1B1E]/95 backdrop-blur border border-[#2C2E33] rounded-lg shadow-xl z-10 pointer-events-none font-mono">
        <canvas ref={axesGizmoCanvasRef} width={64} height={64} className="w-16 h-16" />
        <div className="text-[10px] text-gray-400 space-y-0.5 pr-2">
          <div>
            UNIT: <span className="text-gray-200 font-bold">{unitSystem.toUpperCase()}</span>
          </div>
          <div>
            RENDER: <span className="text-emerald-400 font-bold">{fps} FPS</span>
          </div>
          <div>
            PARTS: <span className="text-gray-200 font-bold">{components.length}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

// Helper: Calculate explosion spatial displacement
function calculateExplosionVector(comp: FurnitureComponent, distanceFactor: number) {
  if (distanceFactor <= 0) return { x: 0, y: 0, z: 0 };
  const d = (distanceFactor / 100) * 450; // max 450mm explosion

  switch (comp.type) {
    case 'side_left':
      return { x: -d * 1.5, y: 0, z: 0 };
    case 'side_right':
      return { x: d * 1.5, y: 0, z: 0 };
    case 'top':
      return { x: 0, y: d * 1.6, z: 0 };
    case 'bottom':
      return { x: 0, y: -d * 0.8, z: 0 };
    case 'back':
      return { x: 0, y: 0, z: -d * 1.8 };
    case 'door_left':
    case 'door_right':
    case 'door_single':
      return { x: 0, y: 0, z: d * 2.2 };
    case 'drawer_front':
    case 'drawer_box':
      return { x: 0, y: 0, z: d * 1.6 };
    case 'plinth':
      return { x: 0, y: -d * 1.2, z: d * 0.4 };
    case 'shelf_fixed':
    case 'shelf_adjustable':
      return { x: 0, y: 0, z: d * 0.5 };
    default:
      return { x: 0, y: 0, z: 0 };
  }
}

// Helper: Create 3D geometry for hardware items (hinges, cams, dowels, handles)
function createHardwareGeometry(hw: HardwareItem): THREE.BufferGeometry {
  switch (hw.category) {
    case 'hinge':
      return new THREE.CylinderGeometry(17.5, 17.5, 13, 16);
    case 'cam_lock':
      return new THREE.CylinderGeometry(7.5, 7.5, 12, 16);
    case 'dowel':
      return new THREE.CylinderGeometry(4, 4, 30, 12);
    case 'handle':
      return new THREE.BoxGeometry(hw.dimensions.width, hw.dimensions.height, hw.dimensions.depth);
    case 'shelf_pin':
      return new THREE.CylinderGeometry(2.5, 2.5, 16, 8);
    case 'foot':
      return new THREE.CylinderGeometry(25, 25, hw.dimensions.height, 16);
    default:
      return new THREE.BoxGeometry(10, 10, 10);
  }
}

// Draw Technical XYZ Orientation Gizmo in overlay canvas
function renderOrientationGizmo(
  canvas: HTMLCanvasElement,
  spherical: { radius: number; theta: number; phi: number }
) {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const cx = canvas.width / 2;
  const cy = canvas.height / 2;
  const len = 28;

  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Project 3D unit axes into screen coords based on camera spherical angles
  const rotY = -spherical.theta;
  const rotX = Math.PI / 2 - spherical.phi;

  const project = (x: number, y: number, z: number) => {
    // Rotate around Y
    const x1 = x * Math.cos(rotY) - z * Math.sin(rotY);
    const z1 = x * Math.sin(rotY) + z * Math.cos(rotY);
    // Rotate around X
    const y2 = y * Math.cos(rotX) - z1 * Math.sin(rotX);
    return { px: cx + x1 * len, py: cy - y2 * len };
  };

  const axes = [
    { name: 'X', color: '#ef4444', pt: project(1, 0, 0) },
    { name: 'Y', color: '#22c55e', pt: project(0, 1, 0) },
    { name: 'Z', color: '#3b82f6', pt: project(0, 0, 1) },
  ];

  axes.forEach((axis) => {
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.lineTo(axis.pt.px, axis.pt.py);
    ctx.strokeStyle = axis.color;
    ctx.lineWidth = 2.5;
    ctx.stroke();

    ctx.fillStyle = axis.color;
    ctx.font = 'bold 10px monospace';
    ctx.fillText(axis.name, axis.pt.px + 4, axis.pt.py + 3);
  });
}

