import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { WarehouseStateEngine } from '../../core/services/warehouse-state.service';

@Component({
  selector: 'app-receiving-app',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 bg-[#F4F4F4] min-h-screen text-slate-900 space-y-6">
      
      <div class="bg-white border border-slate-300 p-5 rounded-lg shadow-sm flex items-center justify-between">
        <div>
          <span class="bg-emerald-600 text-white font-bold text-xs px-2.5 py-0.5 rounded uppercase">INBOUND LOGISTICS</span>
          <h2 class="text-2xl font-black text-slate-900 uppercase mt-1">RECEIVING & PUTAWAY OPTIMIZER</h2>
          <p class="text-xs text-slate-600">Truck Dock Check-in • ASN Quality Inspection • Putaway Scoring Engine</p>
        </div>

        <button (click)="state.runInboundDemoScenario()" 
                class="bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs px-4 py-2.5 rounded shadow flex items-center gap-2">
          <mat-icon class="text-base">local_shipping</mat-icon>
          SIMULATE TRUCK ARRIVAL & PUTAWAY
        </button>
      </div>

      <!-- Inbound Shipments List -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        @for (shipment of state.inboundShipments(); track shipment.shipmentId) {
          <div class="bg-white border border-slate-300 rounded-lg p-5 shadow-sm space-y-4">
            <div class="flex items-center justify-between border-b border-slate-200 pb-3">
              <div>
                <span class="text-xs font-mono font-bold text-[#0058A3]">{{ shipment.shipmentId }} • ASN: {{ shipment.asnNumber }}</span>
                <h3 class="font-extrabold text-slate-900 text-base mt-0.5">{{ shipment.supplierName }}</h3>
              </div>
              <span class="bg-emerald-100 text-emerald-800 font-extrabold text-xs px-3 py-1 rounded">
                {{ shipment.status }}
              </span>
            </div>

            <div class="grid grid-cols-3 gap-2 text-xs font-mono">
              <div class="bg-slate-50 p-2 rounded border border-slate-200">
                <span class="text-slate-500 block text-[10px]">Truck License</span>
                <span class="font-bold text-slate-900">{{ shipment.truckLicensePlate }}</span>
              </div>
              <div class="bg-slate-50 p-2 rounded border border-slate-200">
                <span class="text-slate-500 block text-[10px]">Assigned Dock</span>
                <span class="font-bold text-emerald-700">{{ shipment.dockDoorId }}</span>
              </div>
              <div class="bg-slate-50 p-2 rounded border border-slate-200">
                <span class="text-slate-500 block text-[10px]">Driver</span>
                <span class="font-bold text-slate-900">{{ shipment.driverName }}</span>
              </div>
            </div>

            <!-- Putaway Scoring Recommendations -->
            <div class="space-y-2 pt-2">
              <h4 class="font-extrabold text-xs text-slate-800 uppercase">Automated Putaway Location Scoring</h4>
              @for (task of shipment.putawayTasks; track task.sku) {
                <div class="bg-blue-50/60 border border-blue-200 p-3 rounded-lg space-y-1 text-xs">
                  <div class="flex justify-between font-bold">
                    <span>SKU: {{ task.sku }} ({{ task.qty }} Units)</span>
                    <span class="text-[#0058A3] font-mono">Target: {{ task.recommendedLocationId }}</span>
                  </div>
                  <div class="flex justify-between text-[11px] text-slate-600">
                    <span>Putaway Score: {{ task.score }}/100</span>
                    <span class="text-emerald-700 font-bold font-mono">{{ task.status }}</span>
                  </div>
                </div>
              }
            </div>
          </div>
        }
      </div>

    </div>
  `
})
export class ReceivingAppComponent {
  readonly state = inject(WarehouseStateEngine);
}
