import { FurnitureProject } from '@/types/furniture';
import { generateBOM, generateCutList } from './bom-engine';
import { KOTLIN_PROJECT_FILES } from './kotlin-source-code';
import JSZip from 'jszip';

export function exportProjectToJSON(project: FurnitureProject): void {
  const jsonStr = JSON.stringify(project, null, 2);
  const blob = new Blob([jsonStr], { type: 'application/json' });
  downloadBlob(blob, `${project.name.toLowerCase().replace(/\s+/g, '_')}_v${project.version}.flatform`);
}

export function exportBOMToCSV(project: FurnitureProject): void {
  const bom = generateBOM(project);
  const headers = ['Part Number', 'Name', 'Type', 'Quantity', 'Material / Model', 'Dimensions (mm)', 'Thickness (mm)', 'Area (m²)', 'Weight (kg)', 'Unit Cost ($)', 'Total Cost ($)'];
  const rows = bom.items.map((item) => [
    item.partNumber,
    `"${item.name.replace(/"/g, '""')}"`,
    item.type,
    item.quantity,
    `"${item.materialName.replace(/"/g, '""')}"`,
    `"${item.dimensionsMm}"`,
    item.thicknessMm,
    item.areaM2,
    item.weightKg,
    item.unitCostEst.toFixed(2),
    item.totalCostEst.toFixed(2),
  ]);

  const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  downloadBlob(blob, `${project.name.toLowerCase().replace(/\s+/g, '_')}_BOM.csv`);
}

export function exportCutListToCSV(project: FurnitureProject): void {
  const cutList = generateCutList(project);
  const headers = ['Part Number', 'Name', 'Quantity', 'Length (mm)', 'Width (mm)', 'Thickness (mm)', 'Material', 'Grain Direction', 'Edge Banding', 'CNC Ops'];
  const rows = cutList.map((item) => [
    item.partNumber,
    `"${item.name.replace(/"/g, '""')}"`,
    item.quantity,
    item.lengthMm,
    item.widthMm,
    item.thicknessMm,
    `"${item.materialName.replace(/"/g, '""')}"`,
    item.grainDirection,
    `"${item.edgeBandingSummary.replace(/"/g, '""')}"`,
    item.cncOpsCount,
  ]);

  const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  downloadBlob(blob, `${project.name.toLowerCase().replace(/\s+/g, '_')}_CUTLIST.csv`);
}

export async function exportKotlinProjectZip(): Promise<void> {
  const zip = new JSZip();

  for (const file of KOTLIN_PROJECT_FILES) {
    zip.file(file.path, file.content);
  }

  const content = await zip.generateAsync({ type: 'blob' });
  downloadBlob(content, 'flatform-pro-kotlin-compose-desktop.zip');
}

function downloadBlob(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
