package com.example.domain.model

import androidx.compose.ui.graphics.Color

/**
 * 3D Dimension in millimeters.
 */
data class Dimension3D(
    val width: Float,   // X axis (mm)
    val height: Float,  // Y axis (mm)
    val depth: Float    // Z axis (mm)
) {
    fun formatted(): String = "${width.toInt()} × ${depth.toInt()} × ${height.toInt()} mm"
    fun volumeM3(): Float = (width / 1000f) * (height / 1000f) * (depth / 1000f)
}

/**
 * 3D Coordinate in millimeters.
 */
data class Vector3D(
    val x: Float = 0f,
    val y: Float = 0f,
    val z: Float = 0f
) {
    operator fun plus(other: Vector3D) = Vector3D(x + other.x, y + other.y, z + other.z)
    operator fun minus(other: Vector3D) = Vector3D(x - other.x, y - other.y, z - other.z)
    operator fun times(factor: Float) = Vector3D(x * factor, y * factor, z * factor)
}

enum class MaterialCategory {
    SOLID_WOOD,
    PANEL_ENGINEERED,
    FINISH_DECORATIVE,
    METAL_GLASS
}

enum class MaterialFinish {
    NATURAL_GRAIN,
    MATT,
    SATIN,
    GLOSS,
    TEXTURED_VENEER,
    PAINTED
}

data class Material(
    val id: String,
    val name: String,
    val category: MaterialCategory,
    val finish: MaterialFinish,
    val primaryColor: Long, // Hex ARGB
    val secondaryColor: Long, // Grain / accent
    val thicknessOptionsMm: List<Float> = listOf(16f, 18f, 19f, 22f, 25f),
    val densityKgM3: Float = 680f, // e.g. MDF ~750, Oak ~700, Birch Ply ~680
    val costPerM2: Float = 45.0f,
    val grainDirection: GrainDirection = GrainDirection.VERTICAL,
    val texturePattern: String = "wood_grain_vertical"
)

enum class GrainDirection {
    VERTICAL,
    HORIZONTAL,
    NONE
}

enum class EdgeBandingType {
    NONE,
    ABS_1MM,
    ABS_2MM,
    PVC_1MM,
    WOOD_VENEER_0_6MM,
    SOLID_WOOD_LIP_5MM
}

data class EdgeTreatment(
    val top: EdgeBandingType = EdgeBandingType.ABS_1MM,
    val bottom: EdgeBandingType = EdgeBandingType.ABS_1MM,
    val left: EdgeBandingType = EdgeBandingType.ABS_1MM,
    val right: EdgeBandingType = EdgeBandingType.ABS_1MM
) {
    fun hasAnyEdge(): Boolean = top != EdgeBandingType.NONE || bottom != EdgeBandingType.NONE || left != EdgeBandingType.NONE || right != EdgeBandingType.NONE
    fun summary(): String {
        val edges = mutableListOf<String>()
        if (top != EdgeBandingType.NONE) edges.add("T")
        if (bottom != EdgeBandingType.NONE) edges.add("B")
        if (left != EdgeBandingType.NONE) edges.add("L")
        if (right != EdgeBandingType.NONE) edges.add("R")
        return if (edges.isEmpty()) "Raw Edges" else "Edge ${edges.joinToString("+")}"
    }
}

enum class JointType {
    CAM_LOCK_AND_DOWEL,
    CONFIRMAT_SCREW,
    WOODEN_DOWEL_ONLY,
    POCKET_HOLE_SCREW,
    DADO_AND_RABBET,
    BISCUIT_JOINERY,
    CONCEALED_BRACKET,
    MORTISE_TENON
}

enum class CncOperationType {
    BORE_HOLE_32MM_SYSTEM,
    HINGE_CUP_35MM,
    CAM_LOCK_POCKET_15MM,
    DADO_GROOVE,
    RABBET_BACK_PANEL,
    HANDLE_BORE,
    DRAWER_SLIDE_LINE
}

data class CncOperation(
    val id: String,
    val type: CncOperationType,
    val description: String,
    val diameterMm: Float = 5f,
    val depthMm: Float = 12f,
    val xMm: Float = 0f,
    val yMm: Float = 0f,
    val lengthMm: Float = 0f,
    val face: String = "Face A"
)

enum class ComponentRole {
    SIDE_LEFT,
    SIDE_RIGHT,
    TOP_PANEL,
    BOTTOM_PANEL,
    BACK_PANEL,
    DIVIDER_VERTICAL,
    SHELF_FIXED,
    SHELF_ADJUSTABLE,
    DOOR_LEFT,
    DOOR_RIGHT,
    DOOR_SINGLE,
    DRAWER_FRONT,
    DRAWER_BOX_SIDE_L,
    DRAWER_BOX_SIDE_R,
    DRAWER_BOX_FRONT,
    DRAWER_BOX_BACK,
    DRAWER_BOX_BOTTOM,
    TOE_KICK_PLINTH,
    TABLE_LEG,
    TABLE_TOP,
    APRON_RAIL
}

enum class ComponentGroup {
    STRUCTURE,
    INTERIOR,
    FACADES,
    DRAWERS,
    HARDWARE
}

data class FurnitureComponent(
    val id: String,
    val name: String,
    val group: ComponentGroup,
    val role: ComponentRole,
    val dimensions: Dimension3D, // Width, Height, Depth (or Length, Width, Thickness in panel space)
    val position: Vector3D,     // Position in assembly coordinate space (X, Y, Z in mm)
    val materialId: String,
    val edgeTreatment: EdgeTreatment = EdgeTreatment(),
    val operations: List<CncOperation> = emptyList(),
    val jointType: JointType = JointType.CAM_LOCK_AND_DOWEL,
    val isVisible: Boolean = true,
    val isIsolated: Boolean = false,
    val explosiveOffset: Vector3D = Vector3D(0f, 0f, 0f), // Vector for exploded view
    val notes: String = ""
) {
    fun panelAreaM2(): Float = (dimensions.width / 1000f) * (dimensions.height / 1000f)
    fun panelThickness(): Float = dimensions.depth
}

enum class HardwareCategory {
    HINGES,
    DRAWER_SLIDES,
    CAM_LOCKS_DOWELS,
    CONNECTORS_SCREWS,
    HANDLES_KNOBS,
    SHELF_PINS,
    LEVELLERS_FEET,
    BRACKETS
}

data class HardwareItem(
    val id: String,
    val name: String,
    val category: HardwareCategory,
    val code: String,
    val quantity: Int,
    val unitCost: Float,
    val mountingType: String,
    val specs: String,
    val positions: List<Vector3D> = emptyList()
)

data class BomItem(
    val partNumber: String,
    val name: String,
    val category: String,
    val quantity: Int,
    val materialName: String,
    val dimensions: String,
    val thicknessMm: Float,
    val areaM2: Float,
    val edgeBandingM: Float,
    val unitCost: Float,
    val totalCost: Float
)

data class CutListItem(
    val partNumber: String,
    val componentId: String,
    val name: String,
    val quantity: Int,
    val lengthMm: Float,
    val widthMm: Float,
    val thicknessMm: Float,
    val materialName: String,
    val edgeTreatment: String,
    val grainDirection: GrainDirection,
    val cncOperationsCount: Int,
    val sheetAssignment: String = "Sheet 1"
)

data class PlacedPanel(
    val cutListItem: CutListItem,
    val x: Float, // mm on standard sheet
    val y: Float, // mm on standard sheet
    val width: Float,
    val height: Float,
    val isRotated: Boolean
)

data class NestingSheet(
    val sheetIndex: Int,
    val materialName: String,
    val sheetWidthMm: Float = 2440f,
    val sheetHeightMm: Float = 1220f,
    val thicknessMm: Float = 18f,
    val placedPanels: List<PlacedPanel> = emptyList(),
    val usedAreaM2: Float = 0f,
    val totalAreaM2: Float = 2.9768f, // 2.44 * 1.22
    val wastePercentage: Float = 15.0f
)

enum class WarningSeverity {
    INFO,
    WARNING,
    ERROR
}

data class DesignWarning(
    val id: String,
    val severity: WarningSeverity,
    val title: String,
    val message: String,
    val componentId: String? = null,
    val canAutoFix: Boolean = false,
    val fixActionTitle: String? = null
)

data class AssemblyStep(
    val stepNumber: Int,
    val totalSteps: Int,
    val title: String,
    val description: String,
    val involvedComponentIds: List<String>,
    val hardwareRequired: List<String>,
    val toolsRequired: List<String>,
    val estimatedMinutes: Int,
    val explosionHighlightVector: Vector3D = Vector3D(0f, 0f, 0f),
    val tip: String = ""
)

data class DesignVariant(
    val id: String,
    val name: String,
    val materialId: String,
    val widthOverride: Float? = null,
    val doorCountOverride: Int? = null,
    val drawerCountOverride: Int? = null,
    val shelfCountOverride: Int? = null,
    val description: String = ""
)

enum class FurnitureTemplateType(val displayName: String, val category: String) {
    MODERN_WARDROBE("Modern Wardrobe", "Storage"),
    BASE_CABINET("Kitchen Base Cabinet", "Cabinetry"),
    WALL_CABINET("Upper Wall Cabinet", "Cabinetry"),
    TALL_PANTRY("Tall Utility Pantry", "Cabinetry"),
    BOOKCASE("Architectural Bookcase", "Living"),
    DESK_WITH_DRAWERS("Executive Studio Desk", "Office"),
    CHEST_OF_DRAWERS("Minimalist 4-Drawer Chest", "Bedroom"),
    TV_MEDIA_UNIT("Lowline TV Media Credenza", "Living"),
    MODULAR_SHELVING("Modular Grid Shelf", "Display"),
    SIDEBOARD("Contemporary Sideboard", "Dining"),
    CUSTOM_BOX("Parametric Carcass Box", "Custom")
}

data class FurnitureParameters(
    val widthMm: Float = 2400f,
    val heightMm: Float = 2200f,
    val depthMm: Float = 600f,
    val panelThicknessMm: Float = 18f,
    val backPanelThicknessMm: Float = 6f,
    val backPanelInsetMm: Float = 16f,
    val toeKickHeightMm: Float = 80f,
    val doorGapMm: Float = 2.5f,
    val drawerClearanceMm: Float = 12.7f,
    val shelfCount: Int = 6,
    val dividerCount: Int = 2,
    val doorCount: Int = 2,
    val drawerCount: Int = 3,
    val primaryMaterialId: String = "mat_oak_veneer",
    val accentMaterialId: String = "mat_white_melamine",
    val defaultJoint: JointType = JointType.CAM_LOCK_AND_DOWEL,
    val hasBackPanel: Boolean = true,
    val hasDoors: Boolean = true,
    val hasDrawers: Boolean = true
)

data class ProjectHistorySnapshot(
    val timestamp: Long,
    val description: String,
    val parameters: FurnitureParameters
)

data class FurnitureProject(
    val id: String,
    val name: String,
    val templateType: FurnitureTemplateType,
    val parameters: FurnitureParameters,
    val components: List<FurnitureComponent> = emptyList(),
    val hardwareList: List<HardwareItem> = emptyList(),
    val bomItems: List<BomItem> = emptyList(),
    val cutListItems: List<CutListItem> = emptyList(),
    val nestingSheets: List<NestingSheet> = emptyList(),
    val assemblySteps: List<AssemblyStep> = emptyList(),
    val warnings: List<DesignWarning> = emptyList(),
    val variants: List<DesignVariant> = emptyList(),
    val activeVariantId: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val modifiedAt: Long = System.currentTimeMillis()
)
