package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.storage.ProjectStorage
import com.example.domain.engine.ParametricEngine
import com.example.domain.model.*
import com.example.domain.templates.FurnitureTemplate
import com.example.domain.templates.FurnitureTemplates
import com.example.ui.viewport.CameraState
import com.example.ui.viewport.ShadingMode
import com.example.ui.viewport.ViewportProjection
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class WorkspaceMode {
    CAD_3D_DESIGNER,
    DRAFTING_2D,
    MANUFACTURING_CAM,
    ASSEMBLY_PLANNER
}

enum class LeftPanelTab {
    COMPONENT_TREE,
    MATERIALS,
    HARDWARE,
    VARIANTS_HISTORY
}

enum class RightPanelTab {
    PARAMETRIC_PROPERTIES,
    DRC_VALIDATION
}

data class DesignerUiState(
    val currentScreen: String = "DESIGNER", // "DASHBOARD" or "DESIGNER"
    val projectsList: List<FurnitureProject> = emptyList(),
    val activeProject: FurnitureProject,
    val selectedComponentId: String? = null,
    val activeMode: WorkspaceMode = WorkspaceMode.CAD_3D_DESIGNER,
    val activeLeftTab: LeftPanelTab = LeftPanelTab.COMPONENT_TREE,
    val activeRightTab: RightPanelTab = RightPanelTab.PARAMETRIC_PROPERTIES,
    val isLeftPanelExpanded: Boolean = true,
    val isRightPanelExpanded: Boolean = true,
    val activeTool: String = "select", // "select", "orbit", "pan", "measure"
    val cameraState: CameraState = CameraState(),
    val shadingMode: ShadingMode = ShadingMode.MATERIAL_TEXTURED,
    val explodedFactor: Float = 0f,
    val showDimensions: Boolean = true,
    val showHardware: Boolean = true,
    val isMeasureDialogOpen: Boolean = false,
    val isExportDialogOpen: Boolean = false,
    val undoStack: List<ProjectHistorySnapshot> = emptyList(),
    val redoStack: List<ProjectHistorySnapshot> = emptyList(),
    val snackbarMessage: String? = null
)

class DesignerViewModel(application: Application) : AndroidViewModel(application) {
    private val storage = ProjectStorage(application)

    private val _uiState: MutableStateFlow<DesignerUiState>

    init {
        val initialProjects = storage.getInitialProjects()
        val defaultProject = initialProjects.first()
        _uiState = MutableStateFlow(
            DesignerUiState(
                projectsList = initialProjects,
                activeProject = defaultProject,
                selectedComponentId = defaultProject.components.firstOrNull()?.id
            )
        )
    }

    val uiState: StateFlow<DesignerUiState> = _uiState.asStateFlow()

    fun navigateToDashboard() {
        _uiState.update { it.copy(currentScreen = "DASHBOARD") }
    }

    fun navigateToDesigner() {
        _uiState.update { it.copy(currentScreen = "DESIGNER") }
    }

    fun openProject(project: FurnitureProject) {
        _uiState.update {
            it.copy(
                activeProject = project,
                selectedComponentId = project.components.firstOrNull()?.id,
                currentScreen = "DESIGNER",
                undoStack = emptyList(),
                redoStack = emptyList()
            )
        }
    }

    fun createFromTemplate(template: FurnitureTemplate) {
        val newProj = ParametricEngine.buildProject(
            id = "proj_${System.currentTimeMillis()}",
            name = template.title.uppercase(),
            templateType = template.type,
            params = template.defaultParams,
            variants = template.defaultVariants
        )
        storage.saveProject(newProj)
        val updatedList = storage.getInitialProjects()
        _uiState.update {
            it.copy(
                projectsList = updatedList,
                activeProject = newProj,
                selectedComponentId = newProj.components.firstOrNull()?.id,
                currentScreen = "DESIGNER"
            )
        }
    }

    fun deleteProject(projectId: String) {
        val filtered = _uiState.value.projectsList.filter { it.id != projectId }
        _uiState.update { it.copy(projectsList = filtered) }
    }

    fun setWorkspaceMode(mode: WorkspaceMode) {
        _uiState.update { it.copy(activeMode = mode) }
    }

    fun setLeftTab(tab: LeftPanelTab) {
        _uiState.update { it.copy(activeLeftTab = tab, isLeftPanelExpanded = true) }
    }

    fun setRightTab(tab: RightPanelTab) {
        _uiState.update { it.copy(activeRightTab = tab, isRightPanelExpanded = true) }
    }

    fun toggleLeftPanel() {
        _uiState.update { it.copy(isLeftPanelExpanded = !it.isLeftPanelExpanded) }
    }

    fun toggleRightPanel() {
        _uiState.update { it.copy(isRightPanelExpanded = !it.isRightPanelExpanded) }
    }

    fun setActiveTool(tool: String) {
        if (tool == "measure") {
            _uiState.update { it.copy(isMeasureDialogOpen = true) }
        } else {
            _uiState.update { it.copy(activeTool = tool) }
        }
    }

    fun selectComponent(componentId: String?) {
        _uiState.update { it.copy(selectedComponentId = componentId) }
    }

    fun toggleComponentVisibility(componentId: String) {
        val current = _uiState.value.activeProject
        val updatedComponents = current.components.map {
            if (it.id == componentId) it.copy(isVisible = !it.isVisible) else it
        }
        _uiState.update { it.copy(activeProject = current.copy(components = updatedComponents)) }
    }

    fun updateParameters(newParams: FurnitureParameters, description: String = "Parameter Update") {
        val current = _uiState.value.activeProject
        val snapshot = ProjectHistorySnapshot(
            timestamp = System.currentTimeMillis(),
            parameters = current.parameters,
            description = description
        )

        val updatedProject = ParametricEngine.buildProject(
            id = current.id,
            name = current.name,
            templateType = current.templateType,
            params = newParams,
            variants = current.variants,
            activeVariantId = current.activeVariantId
        )

        storage.saveProject(updatedProject)

        _uiState.update {
            it.copy(
                activeProject = updatedProject,
                undoStack = it.undoStack + snapshot,
                redoStack = emptyList()
            )
        }
    }

    fun applyMaterialToProject(materialId: String) {
        val params = _uiState.value.activeProject.parameters.copy(
            primaryMaterialId = materialId,
            accentMaterialId = materialId
        )
        updateParameters(params, "Applied Material: $materialId")
        showSnackbar("Applied material to all components")
    }

    fun applyVariant(variant: DesignVariant) {
        val curParams = _uiState.value.activeProject.parameters
        val updatedParams = curParams.copy(
            primaryMaterialId = variant.materialId,
            widthMm = variant.widthOverride ?: curParams.widthMm,
            doorCount = variant.doorCountOverride ?: curParams.doorCount,
            drawerCount = variant.drawerCountOverride ?: curParams.drawerCount,
            shelfCount = variant.shelfCountOverride ?: curParams.shelfCount
        )
        val updatedProject = ParametricEngine.buildProject(
            id = _uiState.value.activeProject.id,
            name = _uiState.value.activeProject.name,
            templateType = _uiState.value.activeProject.templateType,
            params = updatedParams,
            variants = _uiState.value.activeProject.variants,
            activeVariantId = variant.id
        )
        storage.saveProject(updatedProject)
        _uiState.update { it.copy(activeProject = updatedProject) }
        showSnackbar("Applied configuration variant: ${variant.name}")
    }

    fun autoFixWarning(warning: DesignWarning) {
        val params = _uiState.value.activeProject.parameters
        when (warning.id) {
            "warn_shelf_span" -> {
                updateParameters(params.copy(dividerCount = params.dividerCount + 1), "Auto-Fix: Added Central Divider")
                showSnackbar("Fixed shelf span deflection by inserting vertical divider.")
            }
            "warn_drawer_depth" -> {
                updateParameters(params.copy(depthMm = 550f), "Auto-Fix: Increased Depth to 550mm")
                showSnackbar("Fixed drawer depth incompatibility.")
            }
        }
    }

    fun addComponentGroup(group: ComponentGroup) {
        val params = _uiState.value.activeProject.parameters
        when (group) {
            ComponentGroup.INTERIOR -> {
                updateParameters(params.copy(shelfCount = params.shelfCount + 1), "Added Shelf")
                showSnackbar("Added adjustable interior shelf.")
            }
            ComponentGroup.DRAWERS -> {
                updateParameters(params.copy(drawerCount = params.drawerCount + 1, hasDrawers = true), "Added Drawer Bay")
                showSnackbar("Added drawer bay.")
            }
            ComponentGroup.STRUCTURE -> {
                updateParameters(params.copy(dividerCount = params.dividerCount + 1), "Added Divider")
                showSnackbar("Added vertical structural divider.")
            }
            else -> {}
        }
    }

    fun undo() {
        val stack = _uiState.value.undoStack
        if (stack.isEmpty()) return
        val lastSnapshot = stack.last()
        val current = _uiState.value.activeProject

        val restoredProject = ParametricEngine.buildProject(
            id = current.id,
            name = current.name,
            templateType = current.templateType,
            params = lastSnapshot.parameters,
            variants = current.variants
        )

        val currentSnapshot = ProjectHistorySnapshot(
            timestamp = System.currentTimeMillis(),
            parameters = current.parameters,
            description = "Undo Snapshot"
        )

        _uiState.update {
            it.copy(
                activeProject = restoredProject,
                undoStack = stack.dropLast(1),
                redoStack = it.redoStack + currentSnapshot
            )
        }
    }

    fun redo() {
        val stack = _uiState.value.redoStack
        if (stack.isEmpty()) return
        val nextSnapshot = stack.last()
        val current = _uiState.value.activeProject

        val restoredProject = ParametricEngine.buildProject(
            id = current.id,
            name = current.name,
            templateType = current.templateType,
            params = nextSnapshot.parameters,
            variants = current.variants
        )

        val currentSnapshot = ProjectHistorySnapshot(
            timestamp = System.currentTimeMillis(),
            parameters = current.parameters,
            description = "Redo Snapshot"
        )

        _uiState.update {
            it.copy(
                activeProject = restoredProject,
                undoStack = it.undoStack + currentSnapshot,
                redoStack = stack.dropLast(1)
            )
        }
    }

    fun updateCamera(camera: CameraState) {
        _uiState.update { it.copy(cameraState = camera) }
    }

    fun setShadingMode(mode: ShadingMode) {
        _uiState.update { it.copy(shadingMode = mode) }
    }

    fun setExplodedFactor(factor: Float) {
        _uiState.update { it.copy(explodedFactor = factor) }
    }

    fun toggleDimensions() {
        _uiState.update { it.copy(showDimensions = !it.showDimensions) }
    }

    fun toggleHardware() {
        _uiState.update { it.copy(showHardware = !it.showHardware) }
    }

    fun openExportDialog() {
        _uiState.update { it.copy(isExportDialogOpen = true) }
    }

    fun closeExportDialog() {
        _uiState.update { it.copy(isExportDialogOpen = false) }
    }

    fun closeMeasureDialog() {
        _uiState.update { it.copy(isMeasureDialogOpen = false, activeTool = "select") }
    }

    fun showSnackbar(message: String) {
        _uiState.update { it.copy(snackbarMessage = message) }
    }

    fun clearSnackbar() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }
}
