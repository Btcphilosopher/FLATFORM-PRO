package com.example.domain.templates

import com.example.domain.model.DesignVariant
import com.example.domain.model.FurnitureParameters
import com.example.domain.model.FurnitureTemplateType
import com.example.domain.model.JointType

data class FurnitureTemplate(
    val type: FurnitureTemplateType,
    val title: String,
    val description: String,
    val defaultParams: FurnitureParameters,
    val defaultVariants: List<DesignVariant>
)

object FurnitureTemplates {
    val templates: List<FurnitureTemplate> = listOf(
        FurnitureTemplate(
            type = FurnitureTemplateType.MODERN_WARDROBE,
            title = "Modern Oak Master Wardrobe",
            description = "High-capacity parametric wardrobe with dual facade doors, 6 configurable shelves, and 3 integrated soft-close drawer bays.",
            defaultParams = FurnitureParameters(
                widthMm = 2400f,
                heightMm = 2200f,
                depthMm = 600f,
                panelThicknessMm = 18f,
                backPanelThicknessMm = 6f,
                backPanelInsetMm = 16f,
                toeKickHeightMm = 80f,
                doorGapMm = 2.5f,
                drawerClearanceMm = 12.7f,
                shelfCount = 6,
                dividerCount = 2,
                doorCount = 2,
                drawerCount = 3,
                primaryMaterialId = "mat_oak_veneer",
                accentMaterialId = "mat_white_melamine",
                defaultJoint = JointType.CAM_LOCK_AND_DOWEL,
                hasBackPanel = true,
                hasDoors = true,
                hasDrawers = true
            ),
            defaultVariants = listOf(
                DesignVariant("var_oak_std", "Natural Oak (Standard)", "mat_oak_veneer", null, 2, 3, 6, "Standard 2-door wardrobe in natural oak"),
                DesignVariant("var_walnut_exec", "American Walnut Luxury", "mat_walnut_veneer", 2600f, 3, 4, 8, "Extended 2600mm width in luxury dark walnut"),
                DesignVariant("var_white_nordic", "Nordic White Melamine", "mat_white_melamine", 2000f, 2, 2, 4, "Compact 2000mm wardrobe in alpine white")
            )
        ),
        FurnitureTemplate(
            type = FurnitureTemplateType.BASE_CABINET,
            title = "Kitchen Standard Base Cabinet",
            description = "Standard 800mm base unit featuring twin doors, internal adjustable shelf, and full undermount hardware provisions.",
            defaultParams = FurnitureParameters(
                widthMm = 800f,
                heightMm = 850f,
                depthMm = 600f,
                panelThicknessMm = 18f,
                backPanelThicknessMm = 6f,
                backPanelInsetMm = 16f,
                toeKickHeightMm = 100f,
                doorGapMm = 2.0f,
                drawerClearanceMm = 12.7f,
                shelfCount = 2,
                dividerCount = 0,
                doorCount = 2,
                drawerCount = 0,
                primaryMaterialId = "mat_white_melamine",
                accentMaterialId = "mat_anthracite_mfc",
                defaultJoint = JointType.CAM_LOCK_AND_DOWEL,
                hasBackPanel = true,
                hasDoors = true,
                hasDrawers = false
            ),
            defaultVariants = listOf(
                DesignVariant("var_base_white", "Alpine White Standard", "mat_white_melamine", 800f, 2, 0, 2),
                DesignVariant("var_base_anthra", "Anthracite Matte Base", "mat_anthracite_mfc", 900f, 2, 0, 2)
            )
        ),
        FurnitureTemplate(
            type = FurnitureTemplateType.WALL_CABINET,
            title = "Kitchen Upper Wall Cabinet",
            description = "Shallow depth wall-hung cabinet engineered with heavy-duty concealed hanging brackets.",
            defaultParams = FurnitureParameters(
                widthMm = 600f,
                heightMm = 720f,
                depthMm = 350f,
                panelThicknessMm = 18f,
                backPanelThicknessMm = 6f,
                backPanelInsetMm = 16f,
                toeKickHeightMm = 0f,
                doorGapMm = 2.0f,
                drawerClearanceMm = 12.7f,
                shelfCount = 2,
                dividerCount = 0,
                doorCount = 1,
                drawerCount = 0,
                primaryMaterialId = "mat_white_melamine",
                accentMaterialId = "mat_oak_veneer",
                defaultJoint = JointType.CAM_LOCK_AND_DOWEL,
                hasBackPanel = true,
                hasDoors = true,
                hasDrawers = false
            ),
            defaultVariants = emptyList()
        ),
        FurnitureTemplate(
            type = FurnitureTemplateType.BOOKCASE,
            title = "Architectural Living Bookcase",
            description = "Multi-bay tall open shelving unit designed with heavy-load 32mm system pin drillings.",
            defaultParams = FurnitureParameters(
                widthMm = 1200f,
                heightMm = 2000f,
                depthMm = 320f,
                panelThicknessMm = 19f,
                backPanelThicknessMm = 6f,
                backPanelInsetMm = 12f,
                toeKickHeightMm = 60f,
                doorGapMm = 2.0f,
                drawerClearanceMm = 12.7f,
                shelfCount = 8,
                dividerCount = 1,
                doorCount = 0,
                drawerCount = 0,
                primaryMaterialId = "mat_ash_solid",
                accentMaterialId = "mat_ash_solid",
                defaultJoint = JointType.CAM_LOCK_AND_DOWEL,
                hasBackPanel = true,
                hasDoors = false,
                hasDrawers = false
            ),
            defaultVariants = emptyList()
        ),
        FurnitureTemplate(
            type = FurnitureTemplateType.DESK_WITH_DRAWERS,
            title = "Executive Studio Desk",
            description = "Ergonomic wide-span work surface with side pedestal housing 3 stationery and file drawer boxes.",
            defaultParams = FurnitureParameters(
                widthMm = 1500f,
                heightMm = 750f,
                depthMm = 700f,
                panelThicknessMm = 25f,
                backPanelThicknessMm = 18f,
                backPanelInsetMm = 20f,
                toeKickHeightMm = 0f,
                doorGapMm = 2.5f,
                drawerClearanceMm = 12.7f,
                shelfCount = 1,
                dividerCount = 1,
                doorCount = 0,
                drawerCount = 3,
                primaryMaterialId = "mat_oak_veneer",
                accentMaterialId = "mat_anthracite_mfc",
                defaultJoint = JointType.CAM_LOCK_AND_DOWEL,
                hasBackPanel = false,
                hasDoors = false,
                hasDrawers = true
            ),
            defaultVariants = emptyList()
        ),
        FurnitureTemplate(
            type = FurnitureTemplateType.CHEST_OF_DRAWERS,
            title = "Minimalist 4-Drawer Bedroom Chest",
            description = "Contemporary vertical chest with precision 12.7mm drawer reveals and concealed undermount runners.",
            defaultParams = FurnitureParameters(
                widthMm = 900f,
                heightMm = 1000f,
                depthMm = 500f,
                panelThicknessMm = 18f,
                backPanelThicknessMm = 6f,
                backPanelInsetMm = 16f,
                toeKickHeightMm = 60f,
                doorGapMm = 2.0f,
                drawerClearanceMm = 12.7f,
                shelfCount = 0,
                dividerCount = 0,
                doorCount = 0,
                drawerCount = 4,
                primaryMaterialId = "mat_walnut_veneer",
                accentMaterialId = "mat_birch_plywood",
                defaultJoint = JointType.CAM_LOCK_AND_DOWEL,
                hasBackPanel = true,
                hasDoors = false,
                hasDrawers = true
            ),
            defaultVariants = emptyList()
        ),
        FurnitureTemplate(
            type = FurnitureTemplateType.TV_MEDIA_UNIT,
            title = "Lowline TV Media Credenza",
            description = "Wide low-profile media unit with cable management cutouts and mixed drawer & audio gear compartments.",
            defaultParams = FurnitureParameters(
                widthMm = 1800f,
                heightMm = 500f,
                depthMm = 450f,
                panelThicknessMm = 18f,
                backPanelThicknessMm = 6f,
                backPanelInsetMm = 16f,
                toeKickHeightMm = 50f,
                doorGapMm = 2.0f,
                drawerClearanceMm = 12.7f,
                shelfCount = 2,
                dividerCount = 2,
                doorCount = 2,
                drawerCount = 2,
                primaryMaterialId = "mat_anthracite_mfc",
                accentMaterialId = "mat_oak_veneer",
                defaultJoint = JointType.CAM_LOCK_AND_DOWEL,
                hasBackPanel = true,
                hasDoors = true,
                hasDrawers = true
            ),
            defaultVariants = emptyList()
        ),
        FurnitureTemplate(
            type = FurnitureTemplateType.TALL_PANTRY,
            title = "Tall Utility Pantry Carcass",
            description = "Full-height 2100mm kitchen pantry cabinet with multi-tier adjustable shelving.",
            defaultParams = FurnitureParameters(
                widthMm = 600f,
                heightMm = 2100f,
                depthMm = 600f,
                panelThicknessMm = 18f,
                backPanelThicknessMm = 6f,
                backPanelInsetMm = 16f,
                toeKickHeightMm = 100f,
                doorGapMm = 2.0f,
                drawerClearanceMm = 12.7f,
                shelfCount = 5,
                dividerCount = 0,
                doorCount = 2,
                drawerCount = 0,
                primaryMaterialId = "mat_white_melamine",
                accentMaterialId = "mat_white_melamine",
                defaultJoint = JointType.CAM_LOCK_AND_DOWEL,
                hasBackPanel = true,
                hasDoors = true,
                hasDrawers = false
            ),
            defaultVariants = emptyList()
        ),
        FurnitureTemplate(
            type = FurnitureTemplateType.CUSTOM_BOX,
            title = "Fully Parametric Carcass Box",
            description = "Generic flat-pack carcass unit customizable to arbitrary engineering dimensions.",
            defaultParams = FurnitureParameters(
                widthMm = 1000f,
                heightMm = 1000f,
                depthMm = 500f,
                panelThicknessMm = 18f,
                backPanelThicknessMm = 6f,
                backPanelInsetMm = 16f,
                toeKickHeightMm = 0f,
                doorGapMm = 2.0f,
                drawerClearanceMm = 12.7f,
                shelfCount = 2,
                dividerCount = 1,
                doorCount = 2,
                drawerCount = 2,
                primaryMaterialId = "mat_birch_plywood",
                accentMaterialId = "mat_birch_plywood",
                defaultJoint = JointType.CAM_LOCK_AND_DOWEL,
                hasBackPanel = true,
                hasDoors = true,
                hasDrawers = true
            ),
            defaultVariants = emptyList()
        )
    )

    fun getByType(type: FurnitureTemplateType): FurnitureTemplate =
        templates.find { it.type == type } ?: templates.first()
}
