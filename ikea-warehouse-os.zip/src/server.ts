import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import { join } from 'node:path';
import { GoogleGenAI } from '@google/genai';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json());

const angularApp = new AngularNodeAppEngine();

// --- REST API Endpoints (/api/v1/...) ---

app.get('/api/v1/warehouses', (req, res) => {
  res.json({
    status: 'success',
    data: [
      { id: 'DC-01', name: 'SYNTHETIC DISTRIBUTION CENTRE 01', code: 'AUREOM-DC01', location: 'Älmhult, Sweden', status: 'ACTIVE', capacityM3: 125000 },
      { id: 'DC-02', name: 'SYNTHETIC LOGISTICS HUB 02', code: 'AUREOM-DC02', location: 'London Gateway, UK', status: 'ACTIVE', capacityM3: 98000 },
      { id: 'DC-03', name: 'SYNTHETIC DISTRIBUTION CENTRE 03', code: 'AUREOM-DC03', location: 'Hamburg, Germany', status: 'ACTIVE', capacityM3: 140000 }
    ]
  });
});

app.get('/api/v1/products', (req, res) => {
  res.json({
    status: 'success',
    data: [
      { sku: 'BILLY-SYN-001', articleNumber: '802.638.32', productName: 'SYNTHETIC-BILLY-BOOKCASE', department: 'Living Room', packageCount: 2, unitPriceSEK: 699 },
      { sku: 'KALLAX-SYN-002', articleNumber: '202.758.85', productName: 'SYNTHETIC-KALLAX-SHELVING', department: 'Storage', packageCount: 1, unitPriceSEK: 499 },
      { sku: 'PAX-SYN-003', articleNumber: '690.257.23', productName: 'SYNTHETIC-PAX-WARDROBE', department: 'Bedroom', packageCount: 3, unitPriceSEK: 3499 },
      { sku: 'LAMP-SYN-004', articleNumber: '603.728.01', productName: 'SYNTHETIC-TERTIAL-LAMP', department: 'Lighting', packageCount: 1, unitPriceSEK: 149 },
      { sku: 'MALM-SYN-005', articleNumber: '002.145.43', productName: 'SYNTHETIC-MALM-BEDFRAME', department: 'Bedroom', packageCount: 2, unitPriceSEK: 2199 }
    ]
  });
});

app.get('/api/v1/inventory', (req, res) => {
  res.json({
    status: 'success',
    data: [
      { sku: 'BILLY-SYN-001', locationId: 'DC01-A02-R04-B01', onHand: 84, available: 72, reserved: 8, allocated: 4 },
      { sku: 'KALLAX-SYN-002', locationId: 'DC01-A01-R02-B01', onHand: 112, available: 95, reserved: 10, allocated: 7 },
      { sku: 'PAX-SYN-003', locationId: 'DC01-HBA-R08-B01', onHand: 42, available: 32, reserved: 6, allocated: 4 }
    ]
  });
});

app.get('/api/v1/orders', (req, res) => {
  res.json({
    status: 'success',
    data: [
      { orderId: 'ORD-100042', customerName: 'Astrid Bergman', status: 'PICKING', orderType: 'CLICK_AND_COLLECT', totalWeightKg: 97.0 },
      { orderId: 'ORD-100045', customerName: 'Lars Nilsson', status: 'READY', orderType: 'HOME_DELIVERY', totalWeightKg: 56.3 }
    ]
  });
});

app.post('/api/v1/orders/allocate', (req, res) => {
  const { orderId } = req.body;
  res.json({
    status: 'success',
    message: `Order ${orderId || 'ORD-NEW'} allocated to warehouse DC-01`,
    allocatedWarehouseId: 'DC-01',
    packagesAllocated: 5,
    pickWaveId: 'WAVE-092'
  });
});

app.post('/api/v1/ai/recommendations', async (req, res) => {
  try {
    const apiKey = process.env['GEMINI_API_KEY'];
    if (!apiKey) {
      // Graceful fallback synthetic recommendation if API key is not configured
      return res.json({
        status: 'success',
        source: 'synthetic_kernel',
        recommendation: {
          category: 'CONGESTION_MITIGATION',
          title: 'Aisle A02 Flow Optimization',
          recommendation: 'Re-assign Pick Wave W-092 to Cross-Aisle B to prevent worker congestion near Forward Pick A02.',
          confidenceScore: 0.94,
          evidence: ['Aisle A02 density > 3 workers/min', 'Travel delay +14 minutes calculated'],
          modelVersion: 'AUREOM-Opt-v1'
        }
      });
    }

    const ai = new GoogleGenAI({ apiKey });
    const prompt = `You are the Gemini 3.7 AI Optimization Engine for AUREOM-WMS (IKEA Warehouse OS).
    Analyze current warehouse context: 45 active orders, 3 pickers in Forward Pick Aisle A02, 1 forklift charging.
    Generate a concise JSON recommendation for warehouse managers. Return JSON with keys: category, title, recommendation, confidenceScore, evidence (array of strings).`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return res.json({
      status: 'success',
      source: 'gemini_api',
      aiOutput: response.text
    });
  } catch (err: unknown) {
    const errorMsg = err instanceof Error ? err.message : String(err);
    return res.json({
      status: 'fallback',
      message: errorMsg,
      recommendation: {
        category: 'REPLENISHMENT',
        title: 'Forward Pick Auto-Replenish',
        recommendation: 'Move 20 units of KALLAX-SYN-002 from HBA-04 to FP-A01.',
        confidenceScore: 0.89,
        evidence: ['Forward pick inventory under reorder threshold (18 < 25)'],
        modelVersion: 'AUREOM-RuleEngine-v1'
      }
    });
  }
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 3000;
  app.listen(port, () => {
    console.log(`IKEA WAREHOUSE OS Server listening on http://0.0.0.0:${port}`);
  });
}

export const reqHandler = createNodeRequestHandler(app);
