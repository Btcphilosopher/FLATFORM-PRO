import { Component, ChangeDetectionStrategy, inject, output, input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { WarehouseStateEngine } from '../../core/services/warehouse-state.service';

export type ActiveAppView = 
  | 'CONTROL_CENTRE'
  | 'DIGITAL_TWIN'
  | 'PICKER_APP'
  | 'RECEIVING_APP'
  | 'DISPATCH_APP'
  | 'CLICK_COLLECT'
  | 'INVENTORY'
  | 'LOGISTICS_TOWER'
  | 'CUSTOMER_VIEW'
  | 'AI_SCENARIO';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="bg-[#0058A3] text-white border-b-4 border-[#FFDA1A] shadow-md sticky top-0 z-50">
      <!-- Top Brand & Operations Bar -->
      <div class="max-w-7xl mx-auto px-4 py-2.5 flex flex-wrap items-center justify-between gap-3">
        
        <!-- IKEA-style Bold Brand Block -->
        <div class="flex items-center gap-3">
          <div class="bg-[#FFDA1A] text-[#0058A3] font-black text-xl px-3 py-1 rounded tracking-tighter uppercase shadow-inner flex items-center gap-1.5">
            <mat-icon class="text-[#0058A3]">warehouse</mat-icon>
            <span>IKEA</span>
          </div>
          <div>
            <h1 class="text-lg font-black tracking-tight uppercase leading-none">WAREHOUSE OS</h1>
            <p class="text-xs text-blue-100 font-medium tracking-wide">AUREOM-WMS • ÄLMHULT DISTRIBUTION HUB DC-01</p>
          </div>
        </div>

        <!-- Master Demo Quick Launcher Buttons -->
        <div class="flex flex-wrap items-center gap-2 text-xs font-semibold">
          <span class="text-blue-200 uppercase tracking-wider text-[10px]">Master Demos:</span>
          
          <button (click)="runMasterDemo()" 
                  class="bg-[#FFDA1A] hover:bg-yellow-400 text-black px-2.5 py-1.5 rounded font-bold shadow flex items-center gap-1 transition-all">
            <mat-icon class="text-sm">play_arrow</mat-icon>
            1. Master Flow
          </button>

          <button (click)="runFailureDemo()" 
                  class="bg-red-600 hover:bg-red-700 text-white px-2.5 py-1.5 rounded font-bold shadow flex items-center gap-1 transition-all">
            <mat-icon class="text-sm">error_outline</mat-icon>
            2. Missing SKU
          </button>

          <button (click)="runCongestionDemo()" 
                  class="bg-amber-500 hover:bg-amber-600 text-black px-2.5 py-1.5 rounded font-bold shadow flex items-center gap-1 transition-all">
            <mat-icon class="text-sm">show_chart</mat-icon>
            3. +50% Congestion
          </button>

          <button (click)="runInboundDemo()" 
                  class="bg-emerald-600 hover:bg-emerald-700 text-white px-2.5 py-1.5 rounded font-bold shadow flex items-center gap-1 transition-all">
            <mat-icon class="text-sm">local_shipping</mat-icon>
            4. Inbound Truck
          </button>
        </div>

        <!-- System Clock & Status -->
        <div class="flex items-center gap-3 text-xs bg-blue-900/60 px-3 py-1.5 rounded border border-blue-400/30">
          <div class="flex items-center gap-1.5">
            <span class="relative flex h-2 w-2">
              <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span class="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <span class="font-bold tracking-wider text-emerald-300">LIVE WMS</span>
          </div>
          <span class="text-blue-300">|</span>
          <span class="font-mono text-white font-semibold">{{ currentTime }}</span>
        </div>
      </div>

      <!-- Main Application Module Switcher Tabs -->
      <nav class="bg-[#004785] border-t border-blue-600/40 px-4 overflow-x-auto scrollbar-none">
        <div class="max-w-7xl mx-auto flex items-center gap-1 py-1 text-xs">
          <button (click)="selectView('CONTROL_CENTRE')" 
                  [class]="activeView() === 'CONTROL_CENTRE' ? activeTabClass : inactiveTabClass">
            <mat-icon class="text-base">dashboard</mat-icon>
            <span>Control Centre</span>
          </button>

          <button (click)="selectView('DIGITAL_TWIN')" 
                  [class]="activeView() === 'DIGITAL_TWIN' ? activeTabClass : inactiveTabClass">
            <mat-icon class="text-base">map</mat-icon>
            <span>Digital Twin Map</span>
          </button>

          <button (click)="selectView('PICKER_APP')" 
                  [class]="activeView() === 'PICKER_APP' ? activeTabClass : inactiveTabClass">
            <mat-icon class="text-base">qr_code_scanner</mat-icon>
            <span>Android Picker</span>
          </button>

          <button (click)="selectView('RECEIVING_APP')" 
                  [class]="activeView() === 'RECEIVING_APP' ? activeTabClass : inactiveTabClass">
            <mat-icon class="text-base">input</mat-icon>
            <span>Inbound Receiving</span>
          </button>

          <button (click)="selectView('DISPATCH_APP')" 
                  [class]="activeView() === 'DISPATCH_APP' ? activeTabClass : inactiveTabClass">
            <mat-icon class="text-base">local_shipping</mat-icon>
            <span>Outbound Dispatch</span>
          </button>

          <button (click)="selectView('CLICK_COLLECT')" 
                  [class]="activeView() === 'CLICK_COLLECT' ? activeTabClass : inactiveTabClass">
            <mat-icon class="text-base">storefront</mat-icon>
            <span>Click & Collect</span>
          </button>

          <button (click)="selectView('INVENTORY')" 
                  [class]="activeView() === 'INVENTORY' ? activeTabClass : inactiveTabClass">
            <mat-icon class="text-base">inventory_2</mat-icon>
            <span>Inventory & Ledger</span>
          </button>

          <button (click)="selectView('LOGISTICS_TOWER')" 
                  [class]="activeView() === 'LOGISTICS_TOWER' ? activeTabClass : inactiveTabClass">
            <mat-icon class="text-base">alt_route</mat-icon>
            <span>Control Tower</span>
          </button>

          <button (click)="selectView('CUSTOMER_VIEW')" 
                  [class]="activeView() === 'CUSTOMER_VIEW' ? activeTabClass : inactiveTabClass">
            <mat-icon class="text-base">person_pin</mat-icon>
            <span>Customer Tracker</span>
          </button>

          <button (click)="selectView('AI_SCENARIO')" 
                  [class]="activeView() === 'AI_SCENARIO' ? activeTabClass : inactiveTabClass">
            <mat-icon class="text-base">psychology</mat-icon>
            <span>AI & What-If Studio</span>
          </button>
        </div>
      </nav>
    </header>
  `
})
export class HeaderComponent {
  readonly state = inject(WarehouseStateEngine);
  readonly activeView = input.required<ActiveAppView>();
  readonly viewChange = output<ActiveAppView>();

  readonly activeTabClass = 'bg-[#FFDA1A] text-black font-extrabold px-3 py-1.5 rounded flex items-center gap-1.5 shadow transition-all whitespace-nowrap';
  readonly inactiveTabClass = 'text-blue-100 hover:text-white hover:bg-blue-800/60 px-3 py-1.5 rounded flex items-center gap-1.5 font-medium transition-all whitespace-nowrap';

  currentTime = new Date().toLocaleTimeString();

  constructor() {
    setInterval(() => {
      this.currentTime = new Date().toLocaleTimeString();
    }, 1000);
  }

  selectView(view: ActiveAppView) {
    this.viewChange.emit(view);
  }

  runMasterDemo() {
    this.viewChange.emit('CONTROL_CENTRE');
    this.state.runMasterDemoScenario();
  }

  runFailureDemo() {
    this.viewChange.emit('CONTROL_CENTRE');
    this.state.runFailureDemoScenario();
  }

  runCongestionDemo() {
    this.viewChange.emit('AI_SCENARIO');
    this.state.runCongestionDemoScenario();
  }

  runInboundDemo() {
    this.viewChange.emit('RECEIVING_APP');
    this.state.runInboundDemoScenario();
  }
}
