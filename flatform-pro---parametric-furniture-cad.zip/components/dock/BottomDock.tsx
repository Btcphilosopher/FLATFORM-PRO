'use client';

import React, { useState } from 'react';
import {
  AssemblyStep,
  BOMItem,
  CutListPiece,
  DesignWarning,
  FurnitureProject,
  SheetNestingPlan,
} from '@/types/furniture';
import { generateBOM, generateCutList } from '@/lib/bom-engine';
import { calculateSheetNesting } from '@/lib/nesting-engine';
import { generateAssemblySequence } from '@/lib/assembly-engine';
import { validateFurnitureProject } from '@/lib/validation-engine';
import {
  exportBOMToCSV,
  exportCutListToCSV,
  exportKotlinProjectZip,
  exportProjectToJSON,
} from '@/lib/export-engine';
import { KOTLIN_PROJECT_FILES } from '@/lib/kotlin-source-code';
import {
  AlertCircle,
  AlertTriangle,
  ArrowRight,
  Boxes,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Code2,
  Download,
  FileSpreadsheet,
  FileText,
  Info,
  Layers,
  ListOrdered,
  Maximize2,
  Play,
  RotateCcw,
  Scissors,
  ShieldAlert,
  Wrench,
} from 'lucide-react';

interface BottomDockProps {
  project: FurnitureProject;
  selectedComponentId: string | null;
  onSelectComponent: (id: string | null) => void;
  activeAssemblyStep: number;
  onSelectAssemblyStep: (step: number) => void;
}

type DockTab = 'bom' | 'cutlist' | 'nesting' | 'assembly' | 'validation' | 'kotlin';

export function BottomDock({
  project,
  selectedComponentId,
  onSelectComponent,
  activeAssemblyStep,
  onSelectAssemblyStep,
}: BottomDockProps) {
  const [activeTab, setActiveTab] = useState<DockTab>('bom');
  const [isExpanded, setIsExpanded] = useState(true);
  const [selectedKotlinFileIndex, setSelectedKotlinFileIndex] = useState(0);

  // Computations
  const bom = generateBOM(project);
  const cutList = generateCutList(project);
  const nestingPlans = calculateSheetNesting(cutList);
  const assemblySteps = generateAssemblySequence(project);
  const warnings = validateFurnitureProject(project);

  const errorCount = warnings.filter((w) => w.severity === 'error').length;
  const warningCount = warnings.filter((w) => w.severity === 'warning').length;

  return (
    <div
      id="bottom_engineering_dock"
      className={`w-full bg-[#16171B] border-t border-[#2C2E33] flex flex-col font-sans select-none transition-all duration-200 z-20 shrink-0 ${
        isExpanded ? 'h-64' : 'h-10'
      }`}
    >
      {/* Dock Header Tabs */}
      <div className="flex items-center justify-between px-3 bg-[#1A1B1E] border-b border-[#2C2E33] h-10 shrink-0">
        <div className="flex items-center gap-1 overflow-x-auto">
          {/* BOM Tab */}
          <button
            id="dock_tab_bom"
            onClick={() => {
              setActiveTab('bom');
              setIsExpanded(true);
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-t text-xs font-bold uppercase tracking-wider transition-colors ${
              activeTab === 'bom' && isExpanded
                ? 'bg-[#16171B] text-white border-t-2 border-blue-500'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-blue-400" />
            BOM ({bom.items.length})
          </button>

          {/* Cut List Tab */}
          <button
            id="dock_tab_cutlist"
            onClick={() => {
              setActiveTab('cutlist');
              setIsExpanded(true);
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-t text-xs font-bold uppercase tracking-wider transition-colors ${
              activeTab === 'cutlist' && isExpanded
                ? 'bg-[#16171B] text-white border-t-2 border-blue-500'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            <Scissors className="w-3.5 h-3.5 text-amber-400" />
            Cut List ({cutList.length})
          </button>

          {/* Sheet Nesting Tab */}
          <button
            id="dock_tab_nesting"
            onClick={() => {
              setActiveTab('nesting');
              setIsExpanded(true);
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-t text-xs font-bold uppercase tracking-wider transition-colors ${
              activeTab === 'nesting' && isExpanded
                ? 'bg-[#16171B] text-white border-t-2 border-blue-500'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            <Boxes className="w-3.5 h-3.5 text-emerald-400" />
            Sheet Nesting ({nestingPlans.reduce((sum, p) => sum + p.totalSheetsRequired, 0)} Sheets)
          </button>

          {/* Assembly Sequence Tab */}
          <button
            id="dock_tab_assembly"
            onClick={() => {
              setActiveTab('assembly');
              setIsExpanded(true);
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-t text-xs font-bold uppercase tracking-wider transition-colors ${
              activeTab === 'assembly' && isExpanded
                ? 'bg-[#16171B] text-white border-t-2 border-blue-500'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            <ListOrdered className="w-3.5 h-3.5 text-purple-400" />
            Assembly ({assemblySteps.length} Steps)
          </button>

          {/* Validation DRC Tab */}
          <button
            id="dock_tab_validation"
            onClick={() => {
              setActiveTab('validation');
              setIsExpanded(true);
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-t text-xs font-bold uppercase tracking-wider transition-colors ${
              activeTab === 'validation' && isExpanded
                ? 'bg-[#16171B] text-white border-t-2 border-blue-500'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            {errorCount > 0 ? (
              <ShieldAlert className="w-3.5 h-3.5 text-red-400" />
            ) : warningCount > 0 ? (
              <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
            ) : (
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            )}
            Validation
            {errorCount > 0 && (
              <span className="px-1.5 py-0.2 bg-red-900/80 text-red-200 rounded-full text-[9px] font-mono">
                {errorCount}
              </span>
            )}
          </button>

          {/* Kotlin Code & Architecture Exporter Tab */}
          <button
            id="dock_tab_kotlin"
            onClick={() => {
              setActiveTab('kotlin');
              setIsExpanded(true);
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-t text-xs font-bold uppercase tracking-wider transition-colors ${
              activeTab === 'kotlin' && isExpanded
                ? 'bg-[#16171B] text-white border-t-2 border-blue-500'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            <Code2 className="w-3.5 h-3.5 text-blue-400" />
            Kotlin / Compose Multiplatform
          </button>
        </div>

        {/* Right Dock Controls & Quick Export */}
        <div className="flex items-center gap-2">
          {activeTab === 'bom' && (
            <button
              onClick={() => exportBOMToCSV(project)}
              className="flex items-center gap-1 px-2.5 py-1 bg-[#222328] hover:bg-[#323439] text-gray-200 rounded text-[11px] border border-[#2C2E33] transition-colors"
            >
              <Download className="w-3 h-3 text-blue-400" /> Export CSV
            </button>
          )}

          {activeTab === 'cutlist' && (
            <button
              onClick={() => exportCutListToCSV(project)}
              className="flex items-center gap-1 px-2.5 py-1 bg-[#222328] hover:bg-[#323439] text-gray-200 rounded text-[11px] border border-[#2C2E33] transition-colors"
            >
              <Download className="w-3 h-3 text-amber-400" /> Export Cut List
            </button>
          )}

          {activeTab === 'kotlin' && (
            <button
              onClick={() => exportKotlinProjectZip()}
              className="flex items-center gap-1 px-2.5 py-1 bg-blue-900/60 hover:bg-blue-800 text-blue-200 rounded text-[11px] border border-blue-700/60 transition-colors"
            >
              <Download className="w-3 h-3 text-blue-300" /> Download Kotlin ZIP
            </button>
          )}

          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1 text-gray-400 hover:text-white hover:bg-[#222328] rounded"
          >
            {isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Dock Content Body */}
      {isExpanded && (
        <div className="flex-1 overflow-auto bg-[#16171B] p-3 text-xs">
          {/* TAB 1: BILL OF MATERIALS (BOM) */}
          {activeTab === 'bom' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-gray-400 text-[11px] pb-1 border-b border-[#2C2E33]">
                <div className="flex items-center gap-4 font-mono">
                  <span>
                    Total Board Area: <strong className="text-gray-200">{bom.totalBoardAreaM2} m²</strong>
                  </span>
                  <span>
                    Total Est. Weight: <strong className="text-gray-200">{bom.totalWeightKg} kg</strong>
                  </span>
                </div>
                <div className="text-emerald-400 font-bold text-sm font-mono">
                  Estimated Total Cost: ${bom.totalCost}
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-[#2C2E33] text-[10px] text-gray-500 uppercase tracking-wider font-mono">
                      <th className="py-1.5 px-2">Part No</th>
                      <th className="py-1.5 px-2">Component Name</th>
                      <th className="py-1.5 px-2">Type</th>
                      <th className="py-1.5 px-2 text-center">Qty</th>
                      <th className="py-1.5 px-2">Material / Model</th>
                      <th className="py-1.5 px-2">Dimensions (mm)</th>
                      <th className="py-1.5 px-2 text-right">Thick</th>
                      <th className="py-1.5 px-2 text-right">Est. Cost</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#2C2E33] text-[11px]">
                    {bom.items.map((item) => (
                      <tr
                        key={item.id}
                        onClick={() => onSelectComponent(item.id)}
                        className={`cursor-pointer transition-colors ${
                          selectedComponentId === item.id
                            ? 'bg-blue-900/30 text-white'
                            : 'text-gray-300 hover:bg-[#222328]'
                        }`}
                      >
                        <td className="py-1.5 px-2 font-mono text-gray-400">{item.partNumber}</td>
                        <td className="py-1.5 px-2 font-medium text-gray-200 truncate max-w-xs">
                          {item.name}
                        </td>
                        <td className="py-1.5 px-2 text-gray-400 uppercase text-[10px]">
                          {item.type.replace(/_/g, ' ')}
                        </td>
                        <td className="py-1.5 px-2 text-center font-bold text-gray-100 font-mono">{item.quantity}</td>
                        <td className="py-1.5 px-2 text-gray-300 truncate max-w-xs">{item.materialName}</td>
                        <td className="py-1.5 px-2 font-mono text-gray-400">{item.dimensionsMm}</td>
                        <td className="py-1.5 px-2 text-right font-mono text-gray-400">
                          {item.thicknessMm > 0 ? `${item.thicknessMm}mm` : '—'}
                        </td>
                        <td className="py-1.5 px-2 text-right font-mono text-emerald-400 font-bold">
                          ${item.totalCostEst.toFixed(2)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 2: CUT LIST OPTIMIZER */}
          {activeTab === 'cutlist' && (
            <div className="space-y-2">
              <div className="text-[11px] text-gray-400 flex items-center justify-between pb-1 border-b border-[#2C2E33] font-mono">
                <span>Precision CNC Panel Saw Cut Matrix (3mm Saw Kerf Allowance)</span>
                <span className="text-gray-200 font-bold">{cutList.length} Total Part Cuts</span>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-[#2C2E33] text-[10px] text-gray-500 uppercase tracking-wider font-mono">
                      <th className="py-1.5 px-2">Part No</th>
                      <th className="py-1.5 px-2">Part Description</th>
                      <th className="py-1.5 px-2 text-center">Qty</th>
                      <th className="py-1.5 px-2">Length (L)</th>
                      <th className="py-1.5 px-2">Width (W)</th>
                      <th className="py-1.5 px-2">Thick (T)</th>
                      <th className="py-1.5 px-2">Material</th>
                      <th className="py-1.5 px-2">Grain</th>
                      <th className="py-1.5 px-2">Edge Banding Codes</th>
                      <th className="py-1.5 px-2 text-center">CNC Ops</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#2C2E33] text-[11px]">
                    {cutList.map((c) => (
                      <tr
                        key={c.id}
                        onClick={() => onSelectComponent(c.id)}
                        className={`cursor-pointer transition-colors ${
                          selectedComponentId === c.id
                            ? 'bg-amber-950/40 text-amber-200'
                            : 'text-gray-300 hover:bg-[#222328]'
                        }`}
                      >
                        <td className="py-1.5 px-2 font-mono text-amber-400">{c.partNumber}</td>
                        <td className="py-1.5 px-2 font-medium text-gray-200 truncate max-w-xs">{c.name}</td>
                        <td className="py-1.5 px-2 text-center font-bold text-gray-100 font-mono">{c.quantity}</td>
                        <td className="py-1.5 px-2 font-mono text-gray-200">{c.lengthMm} mm</td>
                        <td className="py-1.5 px-2 font-mono text-gray-200">{c.widthMm} mm</td>
                        <td className="py-1.5 px-2 font-mono text-gray-400">{c.thicknessMm} mm</td>
                        <td className="py-1.5 px-2 text-gray-300 truncate max-w-xs">{c.materialName}</td>
                        <td className="py-1.5 px-2 text-gray-400 capitalize">{c.grainDirection}</td>
                        <td className="py-1.5 px-2 text-gray-400 font-mono text-[10px] truncate max-w-xs">
                          {c.edgeBandingSummary}
                        </td>
                        <td className="py-1.5 px-2 text-center">
                          <span className="px-1.5 py-0.5 bg-[#222328] text-blue-300 rounded text-[10px] font-mono">
                            {c.cncOpsCount}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 3: SHEET NESTING & MANUFACTURING PREVIEW */}
          {activeTab === 'nesting' && (
            <div className="space-y-4">
              {nestingPlans.map((plan, pIdx) => (
                <div key={pIdx} className="p-3 bg-black/40 border border-[#2C2E33] rounded-lg space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-bold text-emerald-400 text-xs">{plan.sheetMaterialName}</span>
                      <span className="text-gray-400 text-[11px] ml-2 font-mono">
                        {plan.sheetThicknessMm}mm Stock ({plan.sheetWidthMm} × {plan.sheetLengthMm} mm)
                      </span>
                    </div>
                    <div className="flex items-center gap-4 text-[11px] font-mono">
                      <span>
                        Sheets Required: <strong className="text-gray-100">{plan.totalSheetsRequired}</strong>
                      </span>
                      <span>
                        Material Yield:{' '}
                        <strong className="text-emerald-400">{plan.materialUtilizationPercent}%</strong>
                      </span>
                      <span>
                        Waste Area: <strong className="text-gray-400">{plan.wasteAreaM2} m²</strong>
                      </span>
                    </div>
                  </div>

                  {/* 2D Graphical Nesting Sheet Previews */}
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                    {plan.sheets.map((sheet) => (
                      <div key={sheet.sheetIndex} className="p-2 bg-black/60 border border-[#2C2E33] rounded space-y-1">
                        <div className="flex items-center justify-between text-[10px] text-gray-400 font-mono">
                          <span>Sheet #{sheet.sheetIndex} (2440 × 1220 mm)</span>
                          <span className="text-gray-500">Waste: {sheet.wastePercent}%</span>
                        </div>
                        {/* SVG Sheet Nesting Layout Diagram */}
                        <svg viewBox="0 0 2440 1220" className="w-full h-24 bg-[#1A1B1E] rounded border border-[#2C2E33]">
                          {sheet.placedPieces.map((p, idx) => (
                            <g key={idx}>
                              <rect
                                x={p.x}
                                y={p.y}
                                width={p.width}
                                height={p.height}
                                fill="#2563eb"
                                stroke="#60a5fa"
                                strokeWidth="8"
                                opacity="0.85"
                              />
                              <text
                                x={p.x + p.width / 2}
                                y={p.y + p.height / 2 + 15}
                                fill="#ffffff"
                                fontSize="48"
                                fontWeight="bold"
                                textAnchor="middle"
                              >
                                {p.partNumber}
                              </text>
                            </g>
                          ))}
                        </svg>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* TAB 4: ASSEMBLY WORKFLOW SEQUENCER */}
          {activeTab === 'assembly' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between bg-black/40 p-2.5 rounded-lg border border-[#2C2E33]">
                <div className="flex items-center gap-3">
                  <span className="text-purple-400 font-bold text-xs uppercase tracking-wider font-mono">
                    Step {activeAssemblyStep} / {assemblySteps.length}:
                  </span>
                  <span className="text-gray-100 font-medium text-xs">
                    {assemblySteps[activeAssemblyStep - 1]?.title}
                  </span>
                </div>
                <div className="flex items-center gap-1.5">
                  <button
                    disabled={activeAssemblyStep <= 1}
                    onClick={() => onSelectAssemblyStep(Math.max(1, activeAssemblyStep - 1))}
                    className="px-2.5 py-1 bg-[#222328] hover:bg-[#323439] disabled:opacity-40 text-gray-300 rounded text-[11px] border border-[#2C2E33] transition-colors"
                  >
                    Previous Step
                  </button>
                  <button
                    disabled={activeAssemblyStep >= assemblySteps.length}
                    onClick={() => onSelectAssemblyStep(Math.min(assemblySteps.length, activeAssemblyStep + 1))}
                    className="px-2.5 py-1 bg-purple-600 hover:bg-purple-500 disabled:opacity-40 text-white rounded text-[11px] transition-colors font-medium"
                  >
                    Next Step <ArrowRight className="w-3 h-3 inline ml-1" />
                  </button>
                </div>
              </div>

              {/* Active Step Details */}
              {assemblySteps[activeAssemblyStep - 1] && (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div className="md:col-span-2 p-3 bg-black/40 border border-[#2C2E33] rounded-lg space-y-2">
                    <div className="text-[10px] text-gray-400 uppercase font-semibold">Assembly Instructions</div>
                    <p className="text-gray-200 text-xs leading-relaxed">
                      {assemblySteps[activeAssemblyStep - 1].instruction}
                    </p>
                    {assemblySteps[activeAssemblyStep - 1].safetyTip && (
                      <div className="flex items-center gap-2 p-2 bg-amber-950/40 border border-amber-800/60 rounded text-[11px] text-amber-300 mt-2">
                        <AlertTriangle className="w-4 h-4 shrink-0" />
                        <span>{assemblySteps[activeAssemblyStep - 1].safetyTip}</span>
                      </div>
                    )}
                  </div>

                  <div className="p-3 bg-black/40 border border-[#2C2E33] rounded-lg space-y-2">
                    <div className="text-[10px] text-gray-400 uppercase font-semibold">Required Hardware & Tools</div>
                    <div className="space-y-1 text-[11px]">
                      {assemblySteps[activeAssemblyStep - 1].requiredHardware.map((hw, i) => (
                        <div key={i} className="flex items-center justify-between text-gray-300 font-mono">
                          <span>{hw.name}</span>
                          <span className="font-bold text-purple-400">×{hw.count}</span>
                        </div>
                      ))}
                    </div>
                    <div className="pt-2 border-t border-[#2C2E33] text-[10px] text-gray-400 font-mono">
                      Tools: {assemblySteps[activeAssemblyStep - 1].requiredTools.join(', ')}
                    </div>
                    <div className="text-[10px] text-gray-400 font-mono">
                      Est. Time: {assemblySteps[activeAssemblyStep - 1].estimatedMinutes} minutes
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 5: DESIGN VALIDATION & DRC WARNINGS */}
          {activeTab === 'validation' && (
            <div className="space-y-2">
              <div className="text-[11px] text-gray-400 pb-1 border-b border-[#2C2E33] font-mono">
                Live DRC (Design Rule Check) & Manufacturing Feasibility Analysis
              </div>
              <div className="space-y-2">
                {warnings.map((w) => (
                  <div
                    key={w.id}
                    onClick={() => w.componentId && onSelectComponent(w.componentId)}
                    className={`p-2.5 rounded-lg border text-xs cursor-pointer transition-colors ${
                      w.severity === 'error'
                        ? 'bg-red-950/40 border-red-800/80 text-red-200 hover:bg-red-950/60'
                        : w.severity === 'warning'
                        ? 'bg-amber-950/40 border-amber-800/80 text-amber-200 hover:bg-amber-950/60'
                        : 'bg-emerald-950/30 border-emerald-800/80 text-emerald-200'
                    }`}
                  >
                    <div className="flex items-center gap-2 font-bold">
                      {w.severity === 'error' ? (
                        <AlertCircle className="w-4 h-4 text-red-400" />
                      ) : w.severity === 'warning' ? (
                        <AlertTriangle className="w-4 h-4 text-amber-400" />
                      ) : (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      )}
                      <span>{w.title}</span>
                      <span className="text-[10px] uppercase px-1.5 py-0.2 rounded bg-black/40 border border-white/10 font-mono">
                        {w.ruleCategory}
                      </span>
                    </div>
                    <p className="mt-1 text-[11px] opacity-90">{w.message}</p>
                    {w.recommendedAction && (
                      <p className="mt-1 text-[10px] font-mono text-blue-300">
                        Recommendation: {w.recommendedAction}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 6: KOTLIN CODE & ARCHITECTURE VIEWER */}
          {activeTab === 'kotlin' && (
            <div className="grid grid-cols-4 gap-3 h-full">
              {/* Kotlin File Explorer Sidebar */}
              <div className="col-span-1 bg-black/40 border border-[#2C2E33] rounded-lg p-2 overflow-y-auto space-y-1">
                <div className="text-[10px] text-blue-400 uppercase font-bold tracking-wider mb-2 font-mono">
                  Compose Multiplatform Files
                </div>
                {KOTLIN_PROJECT_FILES.map((file, idx) => (
                  <button
                    key={file.path}
                    onClick={() => setSelectedKotlinFileIndex(idx)}
                    className={`w-full text-left px-2 py-1.5 rounded text-[11px] font-mono truncate transition-colors ${
                      selectedKotlinFileIndex === idx
                        ? 'bg-blue-900/40 border border-blue-700/60 text-blue-200 font-semibold'
                        : 'text-gray-400 hover:bg-[#222328] hover:text-gray-200'
                    }`}
                  >
                    {file.path.split('/').pop()}
                  </button>
                ))}
              </div>

              {/* Kotlin Syntax Viewer */}
              <div className="col-span-3 bg-black border border-[#2C2E33] rounded-lg p-3 overflow-auto">
                <div className="text-[11px] text-gray-400 pb-1 mb-2 border-b border-[#2C2E33] flex items-center justify-between">
                  <span className="font-mono text-blue-300">
                    {KOTLIN_PROJECT_FILES[selectedKotlinFileIndex]?.path}
                  </span>
                  <span className="text-[10px] uppercase text-gray-500 font-mono">
                    Kotlin 2.0 / Compose Multiplatform
                  </span>
                </div>
                <pre className="text-xs font-mono text-gray-300 leading-relaxed overflow-x-auto select-text">
                  {KOTLIN_PROJECT_FILES[selectedKotlinFileIndex]?.content}
                </pre>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
