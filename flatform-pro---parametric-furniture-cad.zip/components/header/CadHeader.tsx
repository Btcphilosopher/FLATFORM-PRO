'use client';

import React, { useState } from 'react';
import { FurnitureProject, UnitSystem, ViewportMode } from '@/types/furniture';
import { generateBOM } from '@/lib/bom-engine';
import { validateFurnitureProject } from '@/lib/validation-engine';
import { calculateSheetNesting } from '@/lib/nesting-engine';
import { generateCutList } from '@/lib/bom-engine';
import {
  exportBOMToCSV,
  exportCutListToCSV,
  exportKotlinProjectZip,
  exportProjectToJSON,
} from '@/lib/export-engine';
import {
  Box,
  CheckCircle2,
  ChevronDown,
  Code2,
  Compass,
  DollarSign,
  Download,
  Eye,
  FileCode,
  FileSpreadsheet,
  FileText,
  FolderOpen,
  Grid,
  HelpCircle,
  Layers,
  Layout,
  Plus,
  Redo2,
  RotateCcw,
  Save,
  Scale,
  Settings,
  ShieldAlert,
  ShieldCheck,
  Undo2,
  Wrench,
} from 'lucide-react';

interface CadHeaderProps {
  project: FurnitureProject;
  onUpdateProjectName: (name: string) => void;
  viewportMode: ViewportMode;
  onToggleViewportMode: (mode: ViewportMode) => void;
  unitSystem: UnitSystem;
  onToggleUnitSystem: (unit: UnitSystem) => void;
  onNewProject: () => void;
  onSaveProject: () => void;
  canUndo: boolean;
  canRedo: boolean;
  onUndo: () => void;
  onRedo: () => void;
  showGrid: boolean;
  onToggleGrid: () => void;
  showHardware: boolean;
  onToggleHardware: () => void;
  onOpenHelpModal: () => void;
}

export function CadHeader({
  project,
  onUpdateProjectName,
  viewportMode,
  onToggleViewportMode,
  unitSystem,
  onToggleUnitSystem,
  onNewProject,
  onSaveProject,
  canUndo,
  canRedo,
  onUndo,
  onRedo,
  showGrid,
  onToggleGrid,
  showHardware,
  onToggleHardware,
  onOpenHelpModal,
}: CadHeaderProps) {
  const [openMenu, setOpenMenu] = useState<string | null>(null);

  const bom = generateBOM(project);
  const cutList = generateCutList(project);
  const nestingPlans = calculateSheetNesting(cutList);
  const totalSheets = nestingPlans.reduce((sum, p) => sum + p.totalSheetsRequired, 0);
  const warnings = validateFurnitureProject(project);
  const hasErrors = warnings.some((w) => w.severity === 'error');

  const toggleMenu = (menuName: string) => {
    setOpenMenu(openMenu === menuName ? null : menuName);
  };

  return (
    <header id="cad_header_bar" className="w-full bg-[#1A1B1E] border-b border-[#2C2E33] flex flex-col font-sans text-xs select-none z-30 shrink-0">
      {/* Top Main Command Bar */}
      <div className="flex items-center justify-between px-4 h-10 border-b border-[#2C2E33]">
        {/* Left: Brand Identity & Nav Tabs */}
        <div className="flex items-center gap-6">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <div className="w-5 h-5 bg-[#3B82F6] rounded flex items-center justify-center font-bold text-[10px] text-white">
              FP
            </div>
            <span className="text-xs font-bold tracking-widest text-white">
              FLATFORM PRO <span className="opacity-40 font-normal text-[10px]">v{project.version}</span>
            </span>
          </div>

          {/* Nav Dropdowns */}
          <nav className="flex items-center gap-4 text-[11px] font-medium text-gray-400">
            {/* File Menu */}
            <div className="relative">
              <button
                id="menu_btn_file"
                onClick={() => toggleMenu('file')}
                className={`hover:text-white cursor-pointer transition-colors ${
                  openMenu === 'file' ? 'text-white border-b border-white' : ''
                }`}
              >
                File
              </button>
              {openMenu === 'file' && (
                <div className="absolute top-full left-0 mt-2 w-52 bg-[#16171B] border border-[#2C2E33] rounded-md shadow-2xl py-1 z-50 animate-in fade-in-50 duration-100">
                  <button
                    onClick={() => {
                      onNewProject();
                      setOpenMenu(null);
                    }}
                    className="w-full text-left px-3 py-1.5 text-gray-200 hover:bg-[#323439] hover:text-white flex items-center gap-2 text-xs"
                  >
                    <Plus className="w-3.5 h-3.5 text-blue-400" /> New Design Project
                  </button>
                  <button
                    onClick={() => {
                      onSaveProject();
                      setOpenMenu(null);
                    }}
                    className="w-full text-left px-3 py-1.5 text-gray-200 hover:bg-[#323439] hover:text-white flex items-center gap-2 text-xs"
                  >
                    <Save className="w-3.5 h-3.5 text-blue-400" /> Save Project (.flatform)
                  </button>
                  <div className="my-1 border-t border-[#2C2E33]" />
                  <button
                    onClick={() => {
                      exportBOMToCSV(project);
                      setOpenMenu(null);
                    }}
                    className="w-full text-left px-3 py-1.5 text-gray-200 hover:bg-[#323439] hover:text-white flex items-center gap-2 text-xs"
                  >
                    <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" /> Export BOM CSV
                  </button>
                  <button
                    onClick={() => {
                      exportCutListToCSV(project);
                      setOpenMenu(null);
                    }}
                    className="w-full text-left px-3 py-1.5 text-gray-200 hover:bg-[#323439] hover:text-white flex items-center gap-2 text-xs"
                  >
                    <FileSpreadsheet className="w-3.5 h-3.5 text-amber-400" /> Export Cut List CSV
                  </button>
                  <button
                    onClick={() => {
                      exportKotlinProjectZip();
                      setOpenMenu(null);
                    }}
                    className="w-full text-left px-3 py-1.5 text-blue-300 hover:bg-[#323439] hover:text-white flex items-center gap-2 text-xs"
                  >
                    <Code2 className="w-3.5 h-3.5 text-blue-400" /> Download Kotlin Project
                  </button>
                </div>
              )}
            </div>

            {/* View Menu */}
            <div className="relative">
              <button
                id="menu_btn_view"
                onClick={() => toggleMenu('view')}
                className={`hover:text-white cursor-pointer transition-colors ${
                  openMenu === 'view' ? 'text-white border-b border-white' : ''
                }`}
              >
                View
              </button>
              {openMenu === 'view' && (
                <div className="absolute top-full left-0 mt-2 w-52 bg-[#16171B] border border-[#2C2E33] rounded-md shadow-2xl py-1 z-50">
                  <button
                    onClick={() => {
                      onToggleViewportMode('3d');
                      setOpenMenu(null);
                    }}
                    className="w-full text-left px-3 py-1.5 text-gray-200 hover:bg-[#323439] hover:text-white flex items-center gap-2 text-xs"
                  >
                    <Box className="w-3.5 h-3.5 text-blue-400" /> 3D CAD Viewport
                  </button>
                  <button
                    onClick={() => {
                      onToggleViewportMode('2d_drawing');
                      setOpenMenu(null);
                    }}
                    className="w-full text-left px-3 py-1.5 text-gray-200 hover:bg-[#323439] hover:text-white flex items-center gap-2 text-xs"
                  >
                    <Compass className="w-3.5 h-3.5 text-blue-400" /> 2D Blueprints
                  </button>
                  <button
                    onClick={() => {
                      onToggleViewportMode('split');
                      setOpenMenu(null);
                    }}
                    className="w-full text-left px-3 py-1.5 text-gray-200 hover:bg-[#323439] hover:text-white flex items-center gap-2 text-xs"
                  >
                    <Layout className="w-3.5 h-3.5 text-blue-400" /> Split 3D / 2D View
                  </button>
                  <div className="my-1 border-t border-[#2C2E33]" />
                  <button
                    onClick={() => {
                      onToggleGrid();
                      setOpenMenu(null);
                    }}
                    className="w-full text-left px-3 py-1.5 text-gray-200 hover:bg-[#323439] hover:text-white flex items-center gap-2 text-xs"
                  >
                    <Grid className="w-3.5 h-3.5 text-gray-400" /> Toggle CAD Floor Grid
                  </button>
                  <button
                    onClick={() => {
                      onToggleHardware();
                      setOpenMenu(null);
                    }}
                    className="w-full text-left px-3 py-1.5 text-gray-200 hover:bg-[#323439] hover:text-white flex items-center gap-2 text-xs"
                  >
                    <Wrench className="w-3.5 h-3.5 text-gray-400" /> Toggle Fasteners & Hardware
                  </button>
                </div>
              )}
            </div>

            {/* Export Menu */}
            <div className="relative">
              <button
                id="menu_btn_export"
                onClick={() => toggleMenu('export')}
                className={`hover:text-white cursor-pointer transition-colors ${
                  openMenu === 'export' ? 'text-white border-b border-white' : ''
                }`}
              >
                Manufacturing
              </button>
              {openMenu === 'export' && (
                <div className="absolute top-full left-0 mt-2 w-56 bg-[#16171B] border border-[#2C2E33] rounded-md shadow-2xl py-1 z-50">
                  <button
                    onClick={() => {
                      exportProjectToJSON(project);
                      setOpenMenu(null);
                    }}
                    className="w-full text-left px-3 py-1.5 text-gray-200 hover:bg-[#323439] hover:text-white flex items-center gap-2 text-xs"
                  >
                    <FileCode className="w-3.5 h-3.5 text-blue-400" /> Export .flatform (JSON)
                  </button>
                  <button
                    onClick={() => {
                      exportBOMToCSV(project);
                      setOpenMenu(null);
                    }}
                    className="w-full text-left px-3 py-1.5 text-gray-200 hover:bg-[#323439] hover:text-white flex items-center gap-2 text-xs"
                  >
                    <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" /> Export BOM (.CSV)
                  </button>
                  <button
                    onClick={() => {
                      exportCutListToCSV(project);
                      setOpenMenu(null);
                    }}
                    className="w-full text-left px-3 py-1.5 text-gray-200 hover:bg-[#323439] hover:text-white flex items-center gap-2 text-xs"
                  >
                    <FileSpreadsheet className="w-3.5 h-3.5 text-amber-400" /> Export Panel Cut List (.CSV)
                  </button>
                  <button
                    onClick={() => {
                      exportKotlinProjectZip();
                      setOpenMenu(null);
                    }}
                    className="w-full text-left px-3 py-1.5 text-blue-300 hover:bg-[#323439] hover:text-white flex items-center gap-2 text-xs"
                  >
                    <Download className="w-3.5 h-3.5 text-blue-400" /> Full Kotlin/Compose Code (.ZIP)
                  </button>
                </div>
              )}
            </div>

            {/* Help */}
            <button
              onClick={onOpenHelpModal}
              className="hover:text-white cursor-pointer transition-colors"
            >
              Help
            </button>
          </nav>
        </div>

        {/* Right Status & File Info */}
        <div className="flex items-center gap-4 text-[10px]">
          <div className="flex items-center gap-2 opacity-80">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
            <input
              id="input_project_title"
              type="text"
              value={project.name}
              onChange={(e) => onUpdateProjectName(e.target.value)}
              className="bg-transparent text-gray-300 font-mono text-[10px] w-56 border-b border-transparent hover:border-[#383A40] focus:border-blue-500 focus:outline-none transition-colors"
            />
          </div>
          <span className="px-2 py-0.5 bg-[#2C2E33] rounded text-gray-400 font-mono text-[10px]">
            SAVED
          </span>
        </div>
      </div>

      {/* Secondary CAD Toolbar */}
      <div className="h-10 bg-[#222328] border-b border-[#2C2E33] flex items-center px-3 gap-1 shrink-0">
        {/* Undo / Redo & Basic Geometry Tools */}
        <div className="flex items-center gap-1 border-r border-[#383A40] pr-2 mr-1">
          <button
            id="btn_undo"
            disabled={!canUndo}
            onClick={onUndo}
            title="Undo (Ctrl+Z)"
            className="p-1.5 hover:bg-[#323439] text-gray-300 hover:text-white disabled:opacity-30 rounded transition-colors"
          >
            <Undo2 className="w-3.5 h-3.5" />
          </button>
          <button
            id="btn_redo"
            disabled={!canRedo}
            onClick={onRedo}
            title="Redo (Ctrl+Y)"
            className="p-1.5 hover:bg-[#323439] text-gray-300 hover:text-white disabled:opacity-30 rounded transition-colors"
          >
            <Redo2 className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* CAD Action Buttons */}
        <div className="flex items-center gap-1 border-r border-[#383A40] pr-2 mr-1">
          <button
            onClick={onToggleGrid}
            className={`p-1.5 hover:bg-[#323439] rounded text-[10px] px-2.5 font-medium transition-colors ${
              showGrid ? 'text-blue-400 bg-white/5' : 'text-gray-300'
            }`}
          >
            GRID: {showGrid ? 'ON' : 'OFF'}
          </button>
          <button
            onClick={onToggleHardware}
            className={`p-1.5 hover:bg-[#323439] rounded text-[10px] px-2.5 font-medium transition-colors ${
              showHardware ? 'text-blue-400 bg-white/5' : 'text-gray-300'
            }`}
          >
            HARDWARE
          </button>
          <button
            onClick={() => onToggleUnitSystem(unitSystem === 'mm' ? 'in' : 'mm')}
            className="p-1.5 hover:bg-[#323439] rounded text-[10px] px-2 text-gray-300 font-mono font-bold"
          >
            UNIT: <span className="text-blue-400">{unitSystem.toUpperCase()}</span>
          </button>
        </div>

        {/* Viewport Modes */}
        <div className="flex gap-2 ml-auto items-center">
          <div className="flex bg-black/40 p-0.5 rounded-md border border-white/5">
            <button
              id="btn_mode_3d"
              onClick={() => onToggleViewportMode('3d')}
              className={`px-3 py-1 text-[10px] font-medium rounded transition-colors ${
                viewportMode === '3d'
                  ? 'bg-[#3B82F6] text-white shadow-sm'
                  : 'text-gray-400 hover:text-white hover:bg-[#323439]'
              }`}
            >
              3D VIEW
            </button>
            <button
              id="btn_mode_2d"
              onClick={() => onToggleViewportMode('2d_drawing')}
              className={`px-3 py-1 text-[10px] font-medium rounded transition-colors ${
                viewportMode === '2d_drawing'
                  ? 'bg-[#3B82F6] text-white shadow-sm'
                  : 'text-gray-400 hover:text-white hover:bg-[#323439]'
              }`}
            >
              2D CAD
            </button>
            <button
              id="btn_mode_split"
              onClick={() => onToggleViewportMode('split')}
              className={`px-3 py-1 text-[10px] font-medium rounded transition-colors ${
                viewportMode === 'split'
                  ? 'bg-[#3B82F6] text-white shadow-sm'
                  : 'text-gray-400 hover:text-white hover:bg-[#323439]'
              }`}
            >
              SPLIT
            </button>
          </div>
        </div>
      </div>

      {/* Engineering Telemetry Status HUD Strip */}
      <div className="flex items-center justify-between px-4 h-6 bg-[#16171B] text-[10px] text-gray-400 border-b border-[#2C2E33] font-mono">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1">
            <span className="text-gray-500">DIMENSIONS:</span>
            <strong className="text-gray-200">
              {project.config.width} × {project.config.height} × {project.config.depth} mm
            </strong>
          </span>

          <span className="flex items-center gap-1">
            <span className="text-gray-500">BOARD AREA:</span>
            <strong className="text-gray-200">{bom.totalBoardAreaM2} m²</strong>
          </span>

          <span className="flex items-center gap-1">
            <span className="text-gray-500">TOTAL WEIGHT:</span>
            <strong className="text-gray-200">{bom.totalWeightKg} kg</strong>
          </span>

          <span className="flex items-center gap-1">
            <span className="text-gray-500">SHEET REQ:</span>
            <strong className="text-amber-400">{totalSheets} Sheets</strong>
          </span>
        </div>

        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            {hasErrors ? (
              <span className="text-red-400 font-bold flex items-center gap-1">
                <ShieldAlert className="w-3 h-3" /> DRC WARNING
              </span>
            ) : (
              <span className="text-emerald-400 font-bold flex items-center gap-1">
                <ShieldCheck className="w-3 h-3" /> DRC COMPLIANT
              </span>
            )}
          </div>

          <div className="flex items-center gap-1 text-emerald-400 font-bold">
            <span>EST. BOM: ${bom.totalCost}</span>
          </div>
        </div>
      </div>
    </header>
  );
}
