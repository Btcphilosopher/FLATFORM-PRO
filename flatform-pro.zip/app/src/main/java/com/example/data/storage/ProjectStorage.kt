package com.example.data.storage

import android.content.Context
import android.content.SharedPreferences
import com.example.domain.engine.ParametricEngine
import com.example.domain.model.FurnitureParameters
import com.example.domain.model.FurnitureProject
import com.example.domain.model.FurnitureTemplateType
import com.example.domain.templates.FurnitureTemplates
import org.json.JSONArray
import org.json.JSONObject

class ProjectStorage(context: Context? = null) {
    private val prefs: SharedPreferences? = context?.getSharedPreferences("flatform_pro_projects", Context.MODE_PRIVATE)

    fun getInitialProjects(): List<FurnitureProject> {
        val saved = loadSavedProjects()
        if (saved.isNotEmpty()) {
            return saved
        }

        // Demo projects
        val p1Template = FurnitureTemplates.getByType(FurnitureTemplateType.MODERN_WARDROBE)
        val p1 = ParametricEngine.buildProject(
            id = "proj_demo_wardrobe_01",
            name = "MODERN OAK MASTER WARDROBE",
            templateType = FurnitureTemplateType.MODERN_WARDROBE,
            params = p1Template.defaultParams,
            variants = p1Template.defaultVariants,
            activeVariantId = "var_oak_std"
        )

        val p2Template = FurnitureTemplates.getByType(FurnitureTemplateType.DESK_WITH_DRAWERS)
        val p2 = ParametricEngine.buildProject(
            id = "proj_demo_desk_02",
            name = "EXECUTIVE STUDIO DESK",
            templateType = FurnitureTemplateType.DESK_WITH_DRAWERS,
            params = p2Template.defaultParams,
            variants = p2Template.defaultVariants
        )

        val p3Template = FurnitureTemplates.getByType(FurnitureTemplateType.CHEST_OF_DRAWERS)
        val p3 = ParametricEngine.buildProject(
            id = "proj_demo_chest_03",
            name = "MINIMALIST 4-DRAWER CHEST",
            templateType = FurnitureTemplateType.CHEST_OF_DRAWERS,
            params = p3Template.defaultParams,
            variants = p3Template.defaultVariants
        )

        val p4Template = FurnitureTemplates.getByType(FurnitureTemplateType.TV_MEDIA_UNIT)
        val p4 = ParametricEngine.buildProject(
            id = "proj_demo_tv_04",
            name = "LOWLINE TV MEDIA CREDENZA",
            templateType = FurnitureTemplateType.TV_MEDIA_UNIT,
            params = p4Template.defaultParams,
            variants = p4Template.defaultVariants
        )

        return listOf(p1, p2, p3, p4)
    }

    fun saveProject(project: FurnitureProject) {
        val currentList = loadSavedProjects().toMutableList()
        val existingIndex = currentList.indexOfFirst { it.id == project.id }
        if (existingIndex >= 0) {
            currentList[existingIndex] = project
        } else {
            currentList.add(0, project)
        }
        persistList(currentList)
    }

    private fun persistList(list: List<FurnitureProject>) {
        if (prefs == null) return
        try {
            val jsonArray = JSONArray()
            list.forEach { p ->
                val obj = JSONObject().apply {
                    put("id", p.id)
                    put("name", p.name)
                    put("templateType", p.templateType.name)
                    put("widthMm", p.parameters.widthMm.toDouble())
                    put("heightMm", p.parameters.heightMm.toDouble())
                    put("depthMm", p.parameters.depthMm.toDouble())
                    put("panelThicknessMm", p.parameters.panelThicknessMm.toDouble())
                    put("backPanelThicknessMm", p.parameters.backPanelThicknessMm.toDouble())
                    put("backPanelInsetMm", p.parameters.backPanelInsetMm.toDouble())
                    put("toeKickHeightMm", p.parameters.toeKickHeightMm.toDouble())
                    put("doorGapMm", p.parameters.doorGapMm.toDouble())
                    put("drawerClearanceMm", p.parameters.drawerClearanceMm.toDouble())
                    put("shelfCount", p.parameters.shelfCount)
                    put("dividerCount", p.parameters.dividerCount)
                    put("doorCount", p.parameters.doorCount)
                    put("drawerCount", p.parameters.drawerCount)
                    put("primaryMaterialId", p.parameters.primaryMaterialId)
                    put("accentMaterialId", p.parameters.accentMaterialId)
                    put("hasBackPanel", p.parameters.hasBackPanel)
                    put("hasDoors", p.parameters.hasDoors)
                    put("hasDrawers", p.parameters.hasDrawers)
                    put("modifiedAt", System.currentTimeMillis())
                }
                jsonArray.put(obj)
            }
            prefs.edit().putString("projects_json", jsonArray.toString()).apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun loadSavedProjects(): List<FurnitureProject> {
        val jsonStr = prefs?.getString("projects_json", null) ?: return emptyList()
        val result = mutableListOf<FurnitureProject>()
        try {
            val jsonArray = JSONArray(jsonStr)
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                val templateType = FurnitureTemplateType.valueOf(obj.optString("templateType", FurnitureTemplateType.MODERN_WARDROBE.name))
                val params = FurnitureParameters(
                    widthMm = obj.optDouble("widthMm", 2400.0).toFloat(),
                    heightMm = obj.optDouble("heightMm", 2200.0).toFloat(),
                    depthMm = obj.optDouble("depthMm", 600.0).toFloat(),
                    panelThicknessMm = obj.optDouble("panelThicknessMm", 18.0).toFloat(),
                    backPanelThicknessMm = obj.optDouble("backPanelThicknessMm", 6.0).toFloat(),
                    backPanelInsetMm = obj.optDouble("backPanelInsetMm", 16.0).toFloat(),
                    toeKickHeightMm = obj.optDouble("toeKickHeightMm", 80.0).toFloat(),
                    doorGapMm = obj.optDouble("doorGapMm", 2.5).toFloat(),
                    drawerClearanceMm = obj.optDouble("drawerClearanceMm", 12.7).toFloat(),
                    shelfCount = obj.optInt("shelfCount", 6),
                    dividerCount = obj.optInt("dividerCount", 2),
                    doorCount = obj.optInt("doorCount", 2),
                    drawerCount = obj.optInt("drawerCount", 3),
                    primaryMaterialId = obj.optString("primaryMaterialId", "mat_oak_veneer"),
                    accentMaterialId = obj.optString("accentMaterialId", "mat_white_melamine"),
                    hasBackPanel = obj.optBoolean("hasBackPanel", true),
                    hasDoors = obj.optBoolean("hasDoors", true),
                    hasDrawers = obj.optBoolean("hasDrawers", true)
                )

                val proj = ParametricEngine.buildProject(
                    id = obj.getString("id"),
                    name = obj.getString("name"),
                    templateType = templateType,
                    params = params
                )
                result.add(proj)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return result
    }
}
