package com.example.ui.panels

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.materials.MaterialLibrary
import com.example.domain.model.*
import com.example.ui.theme.*

@Composable
fun ParametricPropertiesPanel(
    project: FurnitureProject,
    selectedComponentId: String?,
    onUpdateParameters: (FurnitureParameters) -> Unit,
    onUpdateComponentEdge: (String, EdgeTreatment) -> Unit,
    onUpdateComponentJoint: (String, JointType) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val params = project.parameters
    val selectedComp = project.components.find { it.id == selectedComponentId }

    Column(
        modifier = modifier
            .fillMaxHeight()
            .background(CadSurface)
            .verticalScroll(scrollState)
            .testTag("parametric_properties_panel")
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "PARAMETRIC INSPECTOR",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = CadAccentBlue,
                letterSpacing = 1.sp
            )
            Icon(Icons.Default.Tune, contentDescription = null, tint = CadAccentBlue, modifier = Modifier.size(16.dp))
        }

        HorizontalDivider(color = CadBorder)

        // 1. GLOBAL FURNITURE DIMENSIONS
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("OVERALL DIMENSIONS (MM)", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = CadTextSecondary)

            // Width
            DimensionInputRow(
                label = "Width (W)",
                value = params.widthMm,
                step = 100f,
                minVal = 400f,
                maxVal = 3600f,
                testTag = "input_width",
                onValueChange = { onUpdateParameters(params.copy(widthMm = it)) }
            )

            // Height
            DimensionInputRow(
                label = "Height (H)",
                value = params.heightMm,
                step = 100f,
                minVal = 400f,
                maxVal = 2800f,
                testTag = "input_height",
                onValueChange = { onUpdateParameters(params.copy(heightMm = it)) }
            )

            // Depth
            DimensionInputRow(
                label = "Depth (D)",
                value = params.depthMm,
                step = 50f,
                minVal = 250f,
                maxVal = 900f,
                testTag = "input_depth",
                onValueChange = { onUpdateParameters(params.copy(depthMm = it)) }
            )

            // Panel Thickness
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Panel Thickness", fontSize = 11.sp, color = CadTextPrimary)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf(16f, 18f, 19f, 22f, 25f).forEach { t ->
                        val isSel = params.panelThicknessMm == t
                        Surface(
                            onClick = { onUpdateParameters(params.copy(panelThicknessMm = t)) },
                            shape = RoundedCornerShape(4.dp),
                            color = if (isSel) CadAccentBlue.copy(alpha = 0.2f) else CadSurfaceVariant,
                            border = if (isSel) androidx.compose.foundation.BorderStroke(1.dp, CadAccentBlue) else null
                        ) {
                            Text(
                                "${t.toInt()}mm",
                                fontSize = 10.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSel) CadAccentBlue else CadTextSecondary,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }

            // Toe-Kick Height
            DimensionInputRow(
                label = "Toe-Kick Plinth",
                value = params.toeKickHeightMm,
                step = 10f,
                minVal = 0f,
                maxVal = 150f,
                testTag = "input_toekick",
                onValueChange = { onUpdateParameters(params.copy(toeKickHeightMm = it)) }
            )

            // Back Panel Inset
            DimensionInputRow(
                label = "Back Panel Inset",
                value = params.backPanelInsetMm,
                step = 2f,
                minVal = 8f,
                maxVal = 30f,
                testTag = "input_back_inset",
                onValueChange = { onUpdateParameters(params.copy(backPanelInsetMm = it)) }
            )
        }

        HorizontalDivider(color = CadBorder)

        // 2. INTERNAL CONFIGURATION
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("INTERIOR & FACADE CONFIG", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = CadTextSecondary)

            // Shelves Count
            CounterRow(
                label = "Adjustable Shelves",
                count = params.shelfCount,
                minVal = 0,
                maxVal = 16,
                testTag = "count_shelves",
                onCountChange = { onUpdateParameters(params.copy(shelfCount = it)) }
            )

            // Dividers Count
            CounterRow(
                label = "Vertical Dividers",
                count = params.dividerCount,
                minVal = 0,
                maxVal = 5,
                testTag = "count_dividers",
                onCountChange = { onUpdateParameters(params.copy(dividerCount = it)) }
            )

            // Doors Count
            CounterRow(
                label = "Facade Doors",
                count = params.doorCount,
                minVal = 0,
                maxVal = 4,
                testTag = "count_doors",
                onCountChange = { onUpdateParameters(params.copy(doorCount = it, hasDoors = it > 0)) }
            )

            // Drawers Count
            CounterRow(
                label = "Drawer Bays",
                count = params.drawerCount,
                minVal = 0,
                maxVal = 6,
                testTag = "count_drawers",
                onCountChange = { onUpdateParameters(params.copy(drawerCount = it, hasDrawers = it > 0)) }
            )
        }

        HorizontalDivider(color = CadBorder)

        // 3. SELECTED COMPONENT PROPERTIES & CNC OPERATIONS
        if (selectedComp != null) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "COMPONENT: ${selectedComp.name.uppercase()}",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = CadAccentCyan
                )

                Card(
                    colors = CardDefaults.cardColors(containerColor = CadSurfaceVariant),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CadBorder),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Dimensions (L×W×T):", fontSize = 11.sp, color = CadTextSecondary)
                            Text(
                                "${selectedComp.dimensions.width.toInt()} × ${selectedComp.dimensions.height.toInt()} × ${selectedComp.dimensions.depth.toInt()} mm",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = CadTextPrimary,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Position (X, Y, Z):", fontSize = 11.sp, color = CadTextSecondary)
                            Text(
                                "(${selectedComp.position.x.toInt()}, ${selectedComp.position.y.toInt()}, ${selectedComp.position.z.toInt()})",
                                fontSize = 11.sp,
                                color = CadTextPrimary,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Material:", fontSize = 11.sp, color = CadTextSecondary)
                            Text(
                                MaterialLibrary.findById(selectedComp.materialId).name,
                                fontSize = 11.sp,
                                color = CadAccentAmber
                            )
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Edge Banding:", fontSize = 11.sp, color = CadTextSecondary)
                            Text(selectedComp.edgeTreatment.summary(), fontSize = 11.sp, color = CadTextPrimary)
                        }
                    }
                }

                // CNC Operations List
                if (selectedComp.operations.isNotEmpty()) {
                    Text("CNC Operations (${selectedComp.operations.size})", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = CadTextSecondary)
                    selectedComp.operations.forEach { op ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(CadSurfaceElevated, RoundedCornerShape(4.dp))
                                .padding(horizontal = 8.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Default.Engineering, contentDescription = null, tint = CadAccentBlue, modifier = Modifier.size(14.dp))
                            Text(op.description, fontSize = 10.sp, color = CadTextPrimary, modifier = Modifier.weight(1f))
                            Text("Ø${op.diameterMm.toInt()}mm", fontSize = 9.sp, color = CadAccentCyan, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        } else {
            Box(modifier = Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                Text("Select any component in viewport or tree to inspect CNC joinery & edge treatments.", fontSize = 11.sp, color = CadTextMuted, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            }
        }
    }
}

@Composable
private fun DimensionInputRow(
    label: String,
    value: Float,
    step: Float,
    minVal: Float,
    maxVal: Float,
    testTag: String,
    onValueChange: (Float) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, fontSize = 11.sp, color = CadTextPrimary)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            IconButton(
                onClick = { onValueChange((value - step).coerceIn(minVal, maxVal)) },
                modifier = Modifier.size(24.dp).testTag("${testTag}_minus")
            ) {
                Icon(Icons.Default.RemoveCircleOutline, contentDescription = "Decrease", tint = CadTextSecondary, modifier = Modifier.size(16.dp))
            }
            Surface(
                shape = RoundedCornerShape(4.dp),
                color = CadSurfaceVariant,
                border = androidx.compose.foundation.BorderStroke(1.dp, CadBorder)
            ) {
                Text(
                    text = "${value.toInt()} mm",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = CadAccentBlue,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp).testTag(testTag)
                )
            }
            IconButton(
                onClick = { onValueChange((value + step).coerceIn(minVal, maxVal)) },
                modifier = Modifier.size(24.dp).testTag("${testTag}_plus")
            ) {
                Icon(Icons.Default.AddCircleOutline, contentDescription = "Increase", tint = CadTextSecondary, modifier = Modifier.size(16.dp))
            }
        }
    }
}

@Composable
private fun CounterRow(
    label: String,
    count: Int,
    minVal: Int,
    maxVal: Int,
    testTag: String,
    onCountChange: (Int) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, fontSize = 11.sp, color = CadTextPrimary)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            IconButton(
                onClick = { onCountChange((count - 1).coerceIn(minVal, maxVal)) },
                modifier = Modifier.size(24.dp).testTag("${testTag}_minus")
            ) {
                Icon(Icons.Default.Remove, contentDescription = "Decrease", tint = CadTextSecondary, modifier = Modifier.size(16.dp))
            }
            Surface(
                shape = RoundedCornerShape(4.dp),
                color = CadSurfaceVariant,
                border = androidx.compose.foundation.BorderStroke(1.dp, CadBorder)
            ) {
                Text(
                    text = "$count",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = CadTextPrimary,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp).testTag(testTag)
                )
            }
            IconButton(
                onClick = { onCountChange((count + 1).coerceIn(minVal, maxVal)) },
                modifier = Modifier.size(24.dp).testTag("${testTag}_plus")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Increase", tint = CadTextSecondary, modifier = Modifier.size(16.dp))
            }
        }
    }
}
