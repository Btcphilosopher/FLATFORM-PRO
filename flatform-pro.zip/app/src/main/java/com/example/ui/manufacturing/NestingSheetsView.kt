package com.example.ui.manufacturing

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.NestingSheet
import com.example.domain.model.PlacedPanel
import com.example.ui.theme.*
import kotlin.math.min

@Composable
fun NestingSheetsView(
    sheets: List<NestingSheet>,
    modifier: Modifier = Modifier
) {
    val textMeasurer = rememberTextMeasurer()

    if (sheets.isEmpty()) {
        Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No cut-list sheets generated yet.", color = CadTextMuted, fontSize = 13.sp)
        }
        return
    }

    LazyColumn(
        modifier = modifier.fillMaxSize().testTag("nesting_sheets_list"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        items(sheets, key = { it.sheetIndex }) { sheet ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CadSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, CadBorder),
                shape = RoundedCornerShape(8.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    // Sheet Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "RAW SHEET #${sheet.sheetIndex}: ${sheet.materialName.uppercase()} (${sheet.thicknessMm.toInt()}mm)",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = CadAccentBlue
                            )
                            Text(
                                text = "Panel Size: ${sheet.sheetWidthMm.toInt()} × ${sheet.sheetHeightMm.toInt()} mm • ${sheet.placedPanels.size} Parts Nested",
                                fontSize = 10.sp,
                                color = CadTextSecondary
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = if (sheet.wastePercentage < 20f) CadAccentGreen.copy(alpha = 0.15f) else CadAccentAmber.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "Waste: ${String.format("%.1f", sheet.wastePercentage)}%",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (sheet.wastePercentage < 20f) CadAccentGreen else CadAccentAmber,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    // 2D Sheet Canvas Diagram
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp)
                            .background(CadBackground, RoundedCornerShape(6.dp))
                            .border(1.dp, CadBorderSubtle, RoundedCornerShape(6.dp))
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize().padding(12.dp)) {
                            val canvasW = size.width
                            val canvasH = size.height

                            val scale = min(canvasW / sheet.sheetWidthMm, canvasH / sheet.sheetHeightMm)
                            val sheetDrawW = sheet.sheetWidthMm * scale
                            val sheetDrawH = sheet.sheetHeightMm * scale

                            val startX = (canvasW - sheetDrawW) / 2f
                            val startY = (canvasH - sheetDrawH) / 2f

                            // Draw Raw Sheet Background (Wood/Melamine panel representation)
                            drawRect(
                                color = Color(0xFF1E293B),
                                topLeft = Offset(startX, startY),
                                size = Size(sheetDrawW, sheetDrawH)
                            )
                            drawRect(
                                color = CadBorderBright,
                                topLeft = Offset(startX, startY),
                                size = Size(sheetDrawW, sheetDrawH),
                                style = Stroke(width = 1.5f)
                            )

                            // Draw Placed Parts
                            sheet.placedPanels.forEachIndexed { idx, panel ->
                                val px = startX + (panel.x * scale)
                                val py = startY + (panel.y * scale)
                                val pw = panel.width * scale
                                val ph = panel.height * scale

                                // Panel Fill
                                val colors = listOf(
                                    Color(0xFF2563EB), Color(0xFF0891B2), Color(0xFF0D9488),
                                    Color(0xFF059669), Color(0xFFD97706), Color(0xFF7C3AED)
                                )
                                val pColor = colors[idx % colors.size].copy(alpha = 0.75f)

                                drawRect(
                                    color = pColor,
                                    topLeft = Offset(px, py),
                                    size = Size(pw, ph)
                                )
                                drawRect(
                                    color = Color.White.copy(alpha = 0.8f),
                                    topLeft = Offset(px, py),
                                    size = Size(pw, ph),
                                    style = Stroke(width = 1f)
                                )

                                // Part Label
                                if (pw > 40f && ph > 20f) {
                                    val layout = textMeasurer.measure(
                                        text = "${panel.cutListItem.name}\n${panel.width.toInt()}×${panel.height.toInt()}",
                                        style = TextStyle(
                                            color = Color.White,
                                            fontSize = 8.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    )
                                    drawText(
                                        textLayoutResult = layout,
                                        topLeft = Offset(px + 4f, py + 4f)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
