import { BOMItem, CutListPiece, FurnitureProject } from '@/types/furniture';
import { getMaterialById } from './materials';

/**
 * Calculates accurate Bill of Materials (BOM) for all components and hardware.
 */
export function generateBOM(project: FurnitureProject): {
  items: BOMItem[];
  totalCost: number;
  totalWeightKg: number;
  totalBoardAreaM2: number;
} {
  const items: BOMItem[] = [];
  let totalCost = 0;
  let totalWeightKg = 0;
  let totalBoardAreaM2 = 0;

  let partCounter = 1;

  // 1. Process Structural and Interior Components
  for (const comp of project.components) {
    const mat = getMaterialById(comp.materialId);
    const areaM2 = (comp.dimensions.width * comp.dimensions.height) / 1_000_000;
    const volumeM3 = (comp.dimensions.width * comp.dimensions.height * comp.thicknessMm) / 1_000_000_000;
    const weightKg = volumeM3 * mat.densityKgM3 * comp.quantity;
    const unitCost = areaM2 * mat.costPerM2;
    const itemTotalCost = unitCost * comp.quantity;

    totalCost += itemTotalCost;
    totalWeightKg += weightKg;
    totalBoardAreaM2 += areaM2 * comp.quantity;

    items.push({
      id: comp.id,
      partNumber: `P-${String(partCounter++).padStart(3, '0')}`,
      name: comp.name,
      type: comp.type,
      quantity: comp.quantity,
      materialName: mat.name,
      dimensionsMm: `${Math.round(comp.dimensions.width)} × ${Math.round(comp.dimensions.height)}`,
      thicknessMm: comp.thicknessMm,
      areaM2: Number(areaM2.toFixed(3)),
      weightKg: Number(weightKg.toFixed(2)),
      unitCostEst: Number(unitCost.toFixed(2)),
      totalCostEst: Number(itemTotalCost.toFixed(2)),
    });
  }

  // 2. Process Hardware Items (Grouped by Model/Name)
  const groupedHardware = new Map<string, { count: number; name: string; unitCost: number; model: string }>();
  for (const hw of project.hardwareItems) {
    const existing = groupedHardware.get(hw.model) || {
      count: 0,
      name: hw.name.split('#')[0].trim(),
      unitCost: hw.unitCost,
      model: hw.model,
    };
    existing.count += 1;
    groupedHardware.set(hw.model, existing);
  }

  groupedHardware.forEach((hw, key) => {
    const itemTotalCost = hw.unitCost * hw.count;
    totalCost += itemTotalCost;
    items.push({
      id: `bom_hw_${key}`,
      partNumber: `HW-${String(partCounter++).padStart(3, '0')}`,
      name: hw.name,
      type: 'hardware',
      quantity: hw.count,
      materialName: hw.model,
      dimensionsMm: '—',
      thicknessMm: 0,
      areaM2: 0,
      weightKg: Number((hw.count * 0.08).toFixed(2)),
      unitCostEst: Number(hw.unitCost.toFixed(2)),
      totalCostEst: Number(itemTotalCost.toFixed(2)),
    });
  });

  return {
    items,
    totalCost: Number(totalCost.toFixed(2)),
    totalWeightKg: Number(totalWeightKg.toFixed(2)),
    totalBoardAreaM2: Number(totalBoardAreaM2.toFixed(3)),
  };
}

/**
 * Generates CNC and Panel Saw Cut List with grain direction and edge banding.
 */
export function generateCutList(project: FurnitureProject): CutListPiece[] {
  const pieces: CutListPiece[] = [];
  let num = 1;

  for (const comp of project.components) {
    const mat = getMaterialById(comp.materialId);

    // Format edge banding string: e.g. "L1: 1.0mm ABS | W1: 1.0mm ABS | L2: 0.4mm | W2: —"
    const edgeSummary = [
      `Top: ${comp.edgeTreatments.top !== 'none' ? comp.edgeTreatments.top : '—'}`,
      `Bot: ${comp.edgeTreatments.bottom !== 'none' ? comp.edgeTreatments.bottom : '—'}`,
      `Left: ${comp.edgeTreatments.left !== 'none' ? comp.edgeTreatments.left : '—'}`,
      `Right: ${comp.edgeTreatments.right !== 'none' ? comp.edgeTreatments.right : '—'}`,
    ].join(' · ');

    const cncOpsCount = comp.machiningHoles.length + comp.machiningGrooves.length;

    // Standard woodworking convention: Length (along grain), Width (cross grain)
    const length = Math.max(comp.dimensions.width, comp.dimensions.height);
    const width = Math.min(comp.dimensions.width, comp.dimensions.height);

    pieces.push({
      id: comp.id,
      partNumber: `CUT-${String(num++).padStart(3, '0')}`,
      name: comp.name,
      quantity: comp.quantity,
      lengthMm: Math.round(length),
      widthMm: Math.round(width),
      thicknessMm: comp.thicknessMm,
      materialId: comp.materialId,
      materialName: mat.name,
      grainDirection: comp.grainDirection,
      edgeBandingSummary: edgeSummary,
      cncOpsCount,
    });
  }

  return pieces;
}
