import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { WarehouseStateEngine } from '../../core/services/warehouse-state.service';
import { PickTask } from '../../core/models/warehouse.types';

@Component({
  selector: 'app-picker-app',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 bg-slate-200 min-h-screen flex justify-center items-start">
      
      <!-- Handheld Android Rugged Terminal Frame Container -->
      <div class="w-full max-w-md bg-slate-900 border-8 border-slate-800 rounded-3xl shadow-2xl text-white overflow-hidden flex flex-col min-h-[720px]">
        
        <!-- Rugged Android Header Bar -->
        <div class="bg-slate-950 p-3 flex items-center justify-between border-b border-slate-800 text-xs">
          <div class="flex items-center gap-2">
            <span class="bg-[#FFDA1A] text-black font-black text-[9px] px-2 py-0.5 rounded uppercase">ANDROID WMS v2.4</span>
            <span class="font-bold text-slate-300 font-mono">DEV-WRK-8042</span>
          </div>
          <div class="flex items-center gap-2">
            <!-- Offline / Online Sync Indicator -->
            <span class="flex items-center gap-1 text-[10px] font-bold text-emerald-400">
              <mat-icon class="text-xs">wifi</mat-icon>
              ONLINE
            </span>
            <span class="text-slate-400 font-mono">88%</span>
          </div>
        </div>

        <!-- Android App Header -->
        <div class="bg-[#0058A3] p-4 flex items-center justify-between">
          <div class="flex items-center gap-2">
            <mat-icon class="text-[#FFDA1A]">qr_code_scanner</mat-icon>
            <div>
              <h3 class="font-extrabold text-sm uppercase">MY PICK TASKS</h3>
              <p class="text-[10px] text-blue-200">Worker: Erik Johansson • Shift: Morning</p>
            </div>
          </div>
          <span class="bg-blue-900 text-blue-100 font-bold text-[10px] px-2 py-1 rounded-full font-mono">
            {{ activeTasks().length }} Assigned
          </span>
        </div>

        <!-- Android Main Screen Content Area -->
        <div class="p-4 flex-1 space-y-4 overflow-y-auto bg-slate-900">
          
          @if (currentTask()) {
            <!-- Active Task Workflow Screen -->
            <div class="bg-slate-800 border-2 border-[#0058A3] rounded-xl p-4 space-y-4">
              
              <div class="flex items-center justify-between border-b border-slate-700 pb-2">
                <div>
                  <span class="text-[10px] text-blue-400 font-mono uppercase">Task ID: {{ currentTask()?.taskId }}</span>
                  <h4 class="font-extrabold text-sm text-white">{{ currentTask()?.orderId }}</h4>
                </div>
                <span class="bg-amber-500 text-black font-black text-[10px] px-2 py-0.5 rounded">
                  PRIORITY 1
                </span>
              </div>

              <!-- Location Navigation Banner -->
              <div class="bg-blue-950/80 border border-blue-500/50 p-3 rounded-lg text-center space-y-1">
                <span class="text-[10px] text-blue-300 font-bold uppercase tracking-wider block">TARGET STORAGE LOCATION</span>
                <p class="text-2xl font-black font-mono text-[#FFDA1A] tracking-wider">{{ currentTask()?.sourceLocationId }}</p>
                <p class="text-[10px] text-slate-300">Aisle A02 • Rack 04 • Bin 01</p>
              </div>

              <!-- Product Details & Package Flat-Pack Dimensions -->
              <div class="bg-slate-900 p-3 rounded-lg space-y-2 border border-slate-700 text-xs">
                <div class="flex justify-between items-center">
                  <span class="font-bold text-white">{{ currentTask()?.productName }}</span>
                  <span class="bg-slate-800 text-slate-300 font-mono text-[10px] px-2 py-0.5 rounded">
                    Qty: {{ currentTask()?.quantity }}
                  </span>
                </div>

                <div class="space-y-1 text-[11px] text-slate-300">
                  <p><span class="text-slate-400">SKU:</span> <span class="font-mono text-white font-bold">{{ currentTask()?.sku }}</span></p>
                  <p><span class="text-slate-400">Package Barcode:</span> <span class="font-mono text-emerald-400">EAN-BILLY-001-P1</span></p>
                  <p><span class="text-slate-400">Handling Class:</span> <span class="bg-red-900/80 text-red-200 font-bold px-1.5 py-0.2 rounded text-[10px]">HEAVY FLATPACK (22kg)</span></p>
                </div>
              </div>

              <!-- Workflow Stage Stepper Buttons -->
              <div class="space-y-2 pt-2">
                @if (workflowStep() === 'NAVIGATE') {
                  <button (click)="advanceStep('SCAN_LOCATION')" 
                          class="w-full bg-[#0058A3] hover:bg-blue-700 text-white font-extrabold text-xs py-3 rounded-lg flex items-center justify-center gap-2 shadow-lg uppercase">
                    <mat-icon>navigation</mat-icon>
                    ARRIVED AT LOCATION • SCAN LOC BARCODE
                  </button>
                } @else if (workflowStep() === 'SCAN_LOCATION') {
                  <div class="bg-amber-950/60 border border-amber-600 p-3 rounded text-center space-y-2">
                    <span class="text-xs font-bold text-amber-300 uppercase">LOCATION CAMERA SCANNER</span>
                    <button (click)="advanceStep('SCAN_PRODUCT')" 
                            class="w-full bg-[#FFDA1A] text-black font-black text-xs py-2.5 rounded flex items-center justify-center gap-1 shadow">
                      <mat-icon>qr_code_scanner</mat-icon>
                      SIMULATE LOCATION BARCODE SCAN
                    </button>
                  </div>
                } @else if (workflowStep() === 'SCAN_PRODUCT') {
                  <div class="bg-emerald-950/60 border border-emerald-600 p-3 rounded text-center space-y-2">
                    <span class="text-xs font-bold text-emerald-300 uppercase">SCAN PACKAGE EAN BARCODE</span>
                    <button (click)="advanceStep('CONFIRM_PICK')" 
                            class="w-full bg-emerald-500 text-black font-black text-xs py-2.5 rounded flex items-center justify-center gap-1 shadow">
                      <mat-icon>check_circle</mat-icon>
                      CONFIRM PACKAGE BARCODE MATCH
                    </button>
                  </div>
                } @else if (workflowStep() === 'CONFIRM_PICK') {
                  <button (click)="completePick()" 
                          class="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs py-3 rounded-lg flex items-center justify-center gap-2 shadow-lg uppercase">
                    <mat-icon>done_all</mat-icon>
                    CONFIRM PICK & MOVE TO STAGING STG-04
                  </button>
                }

                <!-- Exception Reporting Trigger Button -->
                <button (click)="showExceptionModal.set(true)" 
                        class="w-full bg-red-950/80 hover:bg-red-900 border border-red-700 text-red-200 font-bold text-xs py-2 rounded flex items-center justify-center gap-1">
                  <mat-icon class="text-sm">report_problem</mat-icon>
                  REPORT EXCEPTION (NOT FOUND / DAMAGED)
                </button>
              </div>

            </div>
          } @else {
            <div class="py-16 text-center space-y-3 text-slate-400">
              <mat-icon class="text-4xl text-emerald-400">check_circle_outline</mat-icon>
              <h4 class="font-extrabold text-white uppercase text-sm">ALL PICK TASKS COMPLETED</h4>
              <p class="text-xs">No pending tasks in active pick wave. Return to dispatcher or take a break.</p>
            </div>
          }

        </div>

        <!-- Android Bottom Navigation Bar -->
        <div class="bg-slate-950 border-t border-slate-800 p-2 flex justify-around text-[10px] text-slate-400">
          <div class="flex flex-col items-center text-[#FFDA1A]">
            <mat-icon class="text-base">assignment</mat-icon>
            <span>TASKS</span>
          </div>
          <div class="flex flex-col items-center">
            <mat-icon class="text-base">qr_code_scanner</mat-icon>
            <span>SCAN</span>
          </div>
          <div class="flex flex-col items-center">
            <mat-icon class="text-base">inventory</mat-icon>
            <span>INVENTORY</span>
          </div>
          <div class="flex flex-col items-center">
            <mat-icon class="text-base">account_circle</mat-icon>
            <span>PROFILE</span>
          </div>
        </div>

      </div>

      <!-- Exception Modal Overlay -->
      @if (showExceptionModal()) {
        <div class="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
          <div class="bg-slate-900 border-2 border-red-600 p-6 rounded-xl max-w-sm w-full space-y-4 text-white">
            <div class="flex items-center justify-between border-b border-slate-800 pb-2">
              <h3 class="font-extrabold text-sm text-red-400 uppercase">REPORT PICKING EXCEPTION</h3>
              <button (click)="showExceptionModal.set(false)" class="text-slate-400 hover:text-white">✕</button>
            </div>

            <p class="text-xs text-slate-300">Select reason for exception. Backend system will flag location, audit stock, and re-allocate order.</p>

            <div class="space-y-2 text-xs">
              <button (click)="reportException('NOT_FOUND')" 
                      class="w-full bg-slate-800 hover:bg-slate-700 text-white p-2.5 rounded font-bold text-left border border-slate-700 flex items-center gap-2">
                <mat-icon class="text-red-500 text-sm">search_off</mat-icon>
                NOT FOUND AT LOCATION
              </button>
              <button (click)="reportException('DAMAGED')" 
                      class="w-full bg-slate-800 hover:bg-slate-700 text-white p-2.5 rounded font-bold text-left border border-slate-700 flex items-center gap-2">
                <mat-icon class="text-amber-500 text-sm">broken_image</mat-icon>
                ITEM DAMAGED / UNSAFE
              </button>
              <button (click)="reportException('BLOCKED_LOCATION')" 
                      class="w-full bg-slate-800 hover:bg-slate-700 text-white p-2.5 rounded font-bold text-left border border-slate-700 flex items-center gap-2">
                <mat-icon class="text-yellow-500 text-sm">block</mat-icon>
                AISLE / LOCATION BLOCKED
              </button>
            </div>
          </div>
        </div>
      }

    </div>
  `
})
export class PickerAppComponent {
  readonly state = inject(WarehouseStateEngine);
  readonly workflowStep = signal<'NAVIGATE' | 'SCAN_LOCATION' | 'SCAN_PRODUCT' | 'CONFIRM_PICK'>('NAVIGATE');
  readonly showExceptionModal = signal(false);

  readonly activeTasks = signal<PickTask[]>(this.state.pickTasks().filter(t => t.status === 'IN_PROGRESS' || t.status === 'PENDING'));

  currentTask(): PickTask | undefined {
    return this.activeTasks()[0];
  }

  advanceStep(nextStep: 'NAVIGATE' | 'SCAN_LOCATION' | 'SCAN_PRODUCT' | 'CONFIRM_PICK') {
    this.workflowStep.set(nextStep);
  }

  completePick() {
    const task = this.currentTask();
    if (task) {
      this.state.processPickTask(task.taskId, 'COMPLETED');
      this.activeTasks.update(list => list.slice(1));
      this.workflowStep.set('NAVIGATE');
    }
  }

  reportException(reason: 'NOT_FOUND' | 'DAMAGED' | 'WRONG_LOCATION' | 'BLOCKED_LOCATION') {
    const task = this.currentTask();
    if (task) {
      this.state.processPickTask(task.taskId, 'PAUSED_EXCEPTION', reason);
      this.showExceptionModal.set(false);
      this.state.runFailureDemoScenario();
    }
  }
}
