import { CutListPiece, SheetNestingPlan } from '@/types/furniture';
import { getMaterialById } from './materials';

/**
 * 2D Guillotine / Bin-Packing Nesting Optimizer for Sheet Goods
 */
export function calculateSheetNesting(
  pieces: CutListPiece[],
  sheetWidthMm = 2440,
  sheetLengthMm = 1220,
  kerfMm = 4
): SheetNestingPlan[] {
  // Group pieces by material and thickness
  const groups = new Map<string, CutListPiece[]>();

  for (const p of pieces) {
    const key = `${p.materialId}_${p.thicknessMm}`;
    const list = groups.get(key) || [];
    list.push(p);
    groups.set(key, list);
  }

  const plans: SheetNestingPlan[] = [];

  groups.forEach((groupPieces, key) => {
    const [matId, thicknessStr] = key.split('_');
    const thicknessMm = Number(thicknessStr);
    const mat = getMaterialById(matId);

    // Expand pieces by quantity and sort largest area first (First Fit Decreasing heuristic)
    const itemsToPlace: { piece: CutListPiece; w: number; h: number }[] = [];
    for (const p of groupPieces) {
      for (let q = 0; q < p.quantity; q++) {
        itemsToPlace.push({
          piece: p,
          w: p.lengthMm,
          h: p.widthMm,
        });
      }
    }
    itemsToPlace.sort((a, b) => b.w * b.h - a.w * a.h);

    const sheets: SheetNestingPlan['sheets'] = [];

    // Simple robust 2D Shelf Packing Algorithm
    let currentSheetIndex = 1;
    let placedInCurrentSheet: SheetNestingPlan['sheets'][0]['placedPieces'] = [];
    let currentX = 15; // 15mm edge trim margin
    let currentY = 15;
    let currentShelfHeight = 0;

    for (const item of itemsToPlace) {
      // Check if piece fits in current shelf width
      let fitsNormal =
        currentX + item.w + kerfMm <= sheetWidthMm - 15 &&
        currentY + item.h + kerfMm <= sheetLengthMm - 15;
      let rotated = false;

      // If grain allows rotation or no grain
      if (!fitsNormal && item.piece.grainDirection === 'none') {
        if (
          currentX + item.h + kerfMm <= sheetWidthMm - 15 &&
          currentY + item.w + kerfMm <= sheetLengthMm - 15
        ) {
          fitsNormal = true;
          rotated = true;
        }
      }

      if (fitsNormal) {
        const pw = rotated ? item.h : item.w;
        const ph = rotated ? item.w : item.h;

        placedInCurrentSheet.push({
          pieceId: item.piece.id,
          partNumber: item.piece.partNumber,
          name: item.piece.name,
          x: currentX,
          y: currentY,
          width: pw,
          height: ph,
          rotated,
        });

        currentX += pw + kerfMm;
        currentShelfHeight = Math.max(currentShelfHeight, ph);
      } else {
        // Move to next shelf row
        currentY += currentShelfHeight + kerfMm;
        currentX = 15;
        currentShelfHeight = 0;

        // Check if fits in new shelf on same sheet
        let fitsNewShelf =
          currentX + item.w + kerfMm <= sheetWidthMm - 15 &&
          currentY + item.h + kerfMm <= sheetLengthMm - 15;
        rotated = false;

        if (!fitsNewShelf && item.piece.grainDirection === 'none') {
          if (
            currentX + item.h + kerfMm <= sheetWidthMm - 15 &&
            currentY + item.w + kerfMm <= sheetLengthMm - 15
          ) {
            fitsNewShelf = true;
            rotated = true;
          }
        }

        if (fitsNewShelf) {
          const pw = rotated ? item.h : item.w;
          const ph = rotated ? item.w : item.h;

          placedInCurrentSheet.push({
            pieceId: item.piece.id,
            partNumber: item.piece.partNumber,
            name: item.piece.name,
            x: currentX,
            y: currentY,
            width: pw,
            height: ph,
            rotated,
          });

          currentX += pw + kerfMm;
          currentShelfHeight = Math.max(currentShelfHeight, ph);
        } else {
          // Finish current sheet and start new sheet
          const sheetArea = (sheetWidthMm * sheetLengthMm) / 1_000_000;
          const usedArea = placedInCurrentSheet.reduce((acc, p) => acc + (p.width * p.height) / 1_000_000, 0);
          const wastePercent = Number((((sheetArea - usedArea) / sheetArea) * 100).toFixed(1));

          sheets.push({
            sheetIndex: currentSheetIndex++,
            placedPieces: placedInCurrentSheet,
            wastePercent: Math.max(0, wastePercent),
          });

          // Reset for new sheet
          placedInCurrentSheet = [];
          currentX = 15;
          currentY = 15;
          currentShelfHeight = 0;

          const pw = item.w;
          const ph = item.h;

          placedInCurrentSheet.push({
            pieceId: item.piece.id,
            partNumber: item.piece.partNumber,
            name: item.piece.name,
            x: currentX,
            y: currentY,
            width: pw,
            height: ph,
            rotated: false,
          });

          currentX += pw + kerfMm;
          currentShelfHeight = Math.max(currentShelfHeight, ph);
        }
      }
    }

    if (placedInCurrentSheet.length > 0) {
      const sheetArea = (sheetWidthMm * sheetLengthMm) / 1_000_000;
      const usedArea = placedInCurrentSheet.reduce((acc, p) => acc + (p.width * p.height) / 1_000_000, 0);
      const wastePercent = Number((((sheetArea - usedArea) / sheetArea) * 100).toFixed(1));

      sheets.push({
        sheetIndex: currentSheetIndex,
        placedPieces: placedInCurrentSheet,
        wastePercent: Math.max(0, wastePercent),
      });
    }

    const totalSheetArea = sheets.length * ((sheetWidthMm * sheetLengthMm) / 1_000_000);
    const totalPlacedArea = sheets.reduce(
      (sum, s) => sum + s.placedPieces.reduce((acc, p) => acc + (p.width * p.height) / 1_000_000, 0),
      0
    );
    const utilization = totalSheetArea > 0 ? (totalPlacedArea / totalSheetArea) * 100 : 100;

    plans.push({
      sheetMaterialId: matId,
      sheetMaterialName: mat.name,
      sheetThicknessMm: thicknessMm,
      sheetWidthMm,
      sheetLengthMm,
      totalSheetsRequired: sheets.length,
      totalPieces: itemsToPlace.length,
      materialUtilizationPercent: Number(utilization.toFixed(1)),
      wasteAreaM2: Number((totalSheetArea - totalPlacedArea).toFixed(2)),
      sheets,
    });
  });

  return plans;
}
