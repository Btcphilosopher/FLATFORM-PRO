package com.example.ui.viewport

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Straighten
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.FurnitureComponent
import com.example.domain.model.FurnitureProject
import com.example.ui.theme.*
import kotlin.math.abs
import kotlin.math.sqrt

enum class MeasurementUnit(val symbol: String, val scaleToMm: Float) {
    MILLIMETERS("mm", 1.0f),
    CENTIMETERS("cm", 10.0f),
    METERS("m", 1000.0f),
    INCHES("in", 25.4f)
}

@Composable
fun MeasurementToolDialog(
    project: FurnitureProject,
    selectedCompId: String?,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    var compAId by remember { mutableStateOf(selectedCompId ?: project.components.firstOrNull()?.id) }
    var compBId by remember { mutableStateOf(project.components.getOrNull(1)?.id) }
    var unit by remember { mutableStateOf(MeasurementUnit.MILLIMETERS) }

    val compA = project.components.find { it.id == compAId }
    val compB = project.components.find { it.id == compBId }

    Card(
        modifier = modifier
            .width(420.dp)
            .border(1.dp, CadAccentAmber, RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = CadSurface),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.Straighten, contentDescription = null, tint = CadAccentAmber, modifier = Modifier.size(20.dp))
                    Text("CAD Precision Measurement", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = CadTextPrimary)
                }
                IconButton(onClick = onClose, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = CadTextSecondary, modifier = Modifier.size(18.dp))
                }
            }

            // Unit Selector
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                MeasurementUnit.values().forEach { u ->
                    FilterChip(
                        selected = unit == u,
                        onClick = { unit = u },
                        label = { Text(u.name.lowercase().capitalize(), fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = CadAccentAmber.copy(alpha = 0.2f),
                            selectedLabelColor = CadAccentAmber,
                            containerColor = CadSurfaceVariant,
                            labelColor = CadTextSecondary
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = unit == u,
                            borderColor = if (unit == u) CadAccentAmber else CadBorder
                        )
                    )
                }
            }

            Divider(color = CadBorder)

            // Component A & B Pickers
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Reference Component A:", fontSize = 11.sp, color = CadTextSecondary)
                ComponentDropdown(
                    components = project.components,
                    selectedId = compAId,
                    onSelect = { compAId = it }
                )

                Text("Target Component B:", fontSize = 11.sp, color = CadTextSecondary)
                ComponentDropdown(
                    components = project.components,
                    selectedId = compBId,
                    onSelect = { compBId = it }
                )
            }

            // Measurement Output
            if (compA != null && compB != null) {
                val dx = abs(compA.position.x - compB.position.x)
                val dy = abs(compA.position.y - compB.position.y)
                val dz = abs(compA.position.z - compB.position.z)
                val euclideanDist = sqrt((dx * dx) + (dy * dy) + (dz * dz))

                Card(
                    colors = CardDefaults.cardColors(containerColor = CadSurfaceElevated),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CadBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Direct 3D Distance:", fontSize = 12.sp, color = CadTextSecondary)
                            Text(
                                formatDistance(euclideanDist, unit),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = CadAccentAmber,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("ΔX (Width Axis):", fontSize = 11.sp, color = CadTextMuted)
                            Text(formatDistance(dx, unit), fontSize = 11.sp, color = CadTextPrimary, fontFamily = FontFamily.Monospace)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("ΔY (Height Axis):", fontSize = 11.sp, color = CadTextMuted)
                            Text(formatDistance(dy, unit), fontSize = 11.sp, color = CadTextPrimary, fontFamily = FontFamily.Monospace)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("ΔZ (Depth Axis):", fontSize = 11.sp, color = CadTextMuted)
                            Text(formatDistance(dz, unit), fontSize = 11.sp, color = CadTextPrimary, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ComponentDropdown(
    components: List<FurnitureComponent>,
    selectedId: String?,
    onSelect: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    val selectedComp = components.find { it.id == selectedId }

    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = it }
    ) {
        OutlinedTextField(
            value = selectedComp?.name ?: "Select component",
            onValueChange = {},
            readOnly = true,
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier.menuAnchor().fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = CadSurfaceVariant,
                unfocusedContainerColor = CadSurfaceVariant,
                focusedBorderColor = CadAccentAmber,
                unfocusedBorderColor = CadBorder,
                focusedTextColor = CadTextPrimary,
                unfocusedTextColor = CadTextPrimary
            ),
            textStyle = TextStyle(fontSize = 12.sp)
        )

        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier.background(CadSurfaceElevated)
        ) {
            components.forEach { comp ->
                DropdownMenuItem(
                    text = { Text(comp.name, fontSize = 12.sp, color = CadTextPrimary) },
                    onClick = {
                        onSelect(comp.id)
                        expanded = false
                    }
                )
            }
        }
    }
}

private fun formatDistance(distanceMm: Float, unit: MeasurementUnit): String {
    val converted = distanceMm / unit.scaleToMm
    return if (unit == MeasurementUnit.METERS) {
        String.format("%.3f %s", converted, unit.symbol)
    } else {
        String.format("%.1f %s", converted, unit.symbol)
    }
}

private fun String.capitalize(): String = replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
