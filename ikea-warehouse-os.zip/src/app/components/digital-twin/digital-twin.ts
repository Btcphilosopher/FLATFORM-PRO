import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { WarehouseStateEngine } from '../../core/services/warehouse-state.service';
import { WarehouseLocation } from '../../core/models/warehouse.types';

@Component({
  selector: 'app-digital-twin',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 bg-[#111111] text-white min-h-screen space-y-4">
      
      <!-- Top Control Toolbar -->
      <div class="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="bg-[#FFDA1A] text-black font-extrabold text-[10px] px-2 py-0.5 rounded">DIGITAL TWIN ENGINE v3.7</span>
            <span class="text-xs text-slate-400 font-mono">2D SPATIAL INDEXING & HEATMAP</span>
          </div>
          <h2 class="text-xl font-black uppercase text-white tracking-tight mt-0.5">SYNTHETIC DISTRIBUTION CENTRE ÄLMHULT 01</h2>
        </div>

        <!-- Simulation Clock Controls -->
        <div class="flex items-center gap-2 text-xs">
          <span class="text-slate-400 uppercase text-[10px] font-bold">Sim Clock:</span>
          <button (click)="setClockSpeed('REAL_TIME')" 
                  [class]="clockSpeed() === 'REAL_TIME' ? activeClockClass : inactiveClockClass">
            1X REALTIME
          </button>
          <button (click)="setClockSpeed('FAST_2X')" 
                  [class]="clockSpeed() === 'FAST_2X' ? activeClockClass : inactiveClockClass">
            2X SPEED
          </button>

          <button (click)="toggleHeatmap()" 
                  [class]="showHeatmap() ? 'bg-amber-500 text-black font-extrabold px-3 py-1.5 rounded flex items-center gap-1 shadow' : 'bg-slate-800 text-slate-300 px-3 py-1.5 rounded hover:bg-slate-700 flex items-center gap-1'">
            <mat-icon class="text-sm">thermostat</mat-icon>
            {{ showHeatmap() ? 'HEATMAP ON' : 'HEATMAP OFF' }}
          </button>
        </div>
      </div>

      <!-- Main Layout: Twin Canvas + Location Details Inspector Drawer -->
      <div class="grid grid-cols-1 lg:grid-cols-4 gap-6">
        
        <!-- Left 3 Cols: Interactive Digital Twin Canvas -->
        <div class="lg:col-span-3 bg-slate-950 border border-slate-800 rounded-lg p-4 relative overflow-hidden min-h-[580px]">
          
          <!-- Legend Bar -->
          <div class="absolute top-6 left-6 z-10 bg-slate-900/90 backdrop-blur border border-slate-700 p-3 rounded text-xs space-y-1.5 shadow-lg">
            <h4 class="font-bold text-[#FFDA1A] text-[10px] uppercase tracking-wider mb-1">MAP LEGEND</h4>
            <div class="flex items-center gap-2">
              <span class="w-3 h-3 bg-[#0058A3] rounded-sm inline-block"></span>
              <span class="text-slate-300">Forward Pick Aisle</span>
            </div>
            <div class="flex items-center gap-2">
              <span class="w-3 h-3 bg-indigo-600 rounded-sm inline-block"></span>
              <span class="text-slate-300">High-Bay Storage</span>
            </div>
            <div class="flex items-center gap-2">
              <span class="w-3 h-3 bg-emerald-500 rounded-full inline-block"></span>
              <span class="text-slate-300">Worker / Picker</span>
            </div>
            <div class="flex items-center gap-2">
              <span class="w-3 h-3 bg-amber-500 rounded-sm inline-block"></span>
              <span class="text-slate-300">Forklift Vehicle</span>
            </div>
          </div>

          <!-- Interactive Warehouse Map Canvas Area -->
          <div class="w-full h-[520px] bg-[#0c0f14] rounded border border-slate-800/80 relative overflow-auto p-6" id="warehouse-canvas-container">
            
            <!-- Inbound Docks Header Zone -->
            <div class="border-b-2 border-dashed border-emerald-500/40 pb-2 mb-6 flex items-center justify-between">
              <span class="bg-emerald-900/80 text-emerald-300 font-extrabold text-[10px] px-2.5 py-1 rounded tracking-wider uppercase">
                INBOUND TRUCK DOCKS (DOCK-01 TO DOCK-04)
              </span>
              <span class="text-xs text-emerald-400 font-mono">1 Truck Unloading at Dock 02</span>
            </div>

            <!-- Warehouse Storage Aisles Grid (Rendered from Addressable Locations) -->
            <div class="grid grid-cols-4 gap-6 py-4">
              
              <!-- Forward Pick Aisle A01 -->
              <div class="bg-slate-900/90 border-2 border-blue-600 p-3 rounded space-y-2">
                <div class="flex items-center justify-between border-b border-blue-500/30 pb-1">
                  <span class="font-extrabold text-blue-400 text-xs uppercase">Aisle A01 (Forward Pick)</span>
                  <span class="text-[10px] text-slate-400 font-mono">Util: 72%</span>
                </div>

                <div class="grid grid-cols-2 gap-2">
                  @for (loc of getAisleLocations('A01'); track loc.locationId) {
                    <button (click)="selectLocation(loc)" 
                         [class]="getLocationCardClass(loc)"
                         class="p-2 rounded cursor-pointer transition-all border text-xs text-left w-full">
                      <div class="flex items-center justify-between font-mono font-bold text-[10px]">
                        <span>{{ loc.rack }}-{{ loc.bin }}</span>
                        <span>{{ loc.currentUtilisationPct }}%</span>
                      </div>
                      <p class="text-[9px] opacity-80 mt-1 truncate">SKU: KALLAX / LAMP</p>
                    </button>
                  }
                </div>
              </div>

              <!-- Forward Pick Aisle A02 -->
              <div class="bg-slate-900/90 border-2 border-amber-500 p-3 rounded space-y-2">
                <div class="flex items-center justify-between border-b border-amber-500/30 pb-1">
                  <span class="font-extrabold text-amber-400 text-xs uppercase">Aisle A02 (Congestion Alert)</span>
                  <span class="text-[10px] text-amber-400 font-mono font-bold">Util: 88%</span>
                </div>

                <div class="grid grid-cols-2 gap-2">
                  @for (loc of getAisleLocations('A02'); track loc.locationId) {
                    <button (click)="selectLocation(loc)" 
                         [class]="getLocationCardClass(loc)"
                         class="p-2 rounded cursor-pointer transition-all border text-xs text-left w-full">
                      <div class="flex items-center justify-between font-mono font-bold text-[10px]">
                        <span>{{ loc.rack }}-{{ loc.bin }}</span>
                        <span>{{ loc.currentUtilisationPct }}%</span>
                      </div>
                      <p class="text-[9px] opacity-80 mt-1 truncate">SKU: BILLY-SYN-001</p>
                    </button>
                  }
                </div>
              </div>

              <!-- High-Bay Storage HBA-01 -->
              <div class="bg-slate-900/90 border-2 border-indigo-600 p-3 rounded space-y-2">
                <div class="flex items-center justify-between border-b border-indigo-500/30 pb-1">
                  <span class="font-extrabold text-indigo-400 text-xs uppercase">High-Bay HBA-01</span>
                  <span class="text-[10px] text-slate-400 font-mono">Util: 64%</span>
                </div>

                <div class="grid grid-cols-2 gap-2">
                  @for (loc of getAisleLocations('HBA'); track loc.locationId) {
                    <button (click)="selectLocation(loc)" 
                         [class]="getLocationCardClass(loc)"
                         class="p-2 rounded cursor-pointer transition-all border text-xs text-left w-full">
                      <div class="flex items-center justify-between font-mono font-bold text-[10px]">
                        <span>{{ loc.rack }}-{{ loc.bin }}</span>
                        <span>{{ loc.currentUtilisationPct }}%</span>
                      </div>
                      <p class="text-[9px] opacity-80 mt-1 truncate">SKU: PAX-SYN-003</p>
                    </button>
                  }
                </div>
              </div>

              <!-- Staging & Click Collect Bay -->
              <div class="bg-slate-900/90 border-2 border-emerald-600 p-3 rounded space-y-2">
                <div class="flex items-center justify-between border-b border-emerald-500/30 pb-1">
                  <span class="font-extrabold text-emerald-400 text-xs uppercase">Staging & Click-Collect</span>
                  <span class="text-[10px] text-slate-400 font-mono">STG-01 to STG-08</span>
                </div>

                <div class="space-y-2 pt-1">
                  <div class="bg-emerald-950/80 border border-emerald-700 p-2 rounded text-[11px] space-y-1">
                    <span class="font-bold text-emerald-300">Staging Bay STG-04</span>
                    <p class="text-[10px] text-slate-300">Order #ORD-100042 Consolidated</p>
                  </div>
                  <div class="bg-blue-950/80 border border-blue-700 p-2 rounded text-[11px] space-y-1">
                    <span class="font-bold text-blue-300">Click & Collect Bay 02</span>
                    <p class="text-[10px] text-slate-300">Customer Sven Lindqvist Checked In</p>
                  </div>
                </div>
              </div>

            </div>

            <!-- Outbound Docks Footer Zone -->
            <div class="border-t-2 border-dashed border-blue-500/40 pt-2 mt-6 flex items-center justify-between">
              <span class="bg-blue-900/80 text-blue-300 font-extrabold text-[10px] px-2.5 py-1 rounded tracking-wider uppercase">
                OUTBOUND DELIVERY DOCKS (DOCK-05 TO DOCK-08)
              </span>
              <span class="text-xs text-blue-400 font-mono">Load Plan Complete for Truck SE-882</span>
            </div>

          </div>
        </div>

        <!-- Right Col: Location Inspector Drawer -->
        <div class="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 class="font-extrabold text-sm uppercase text-[#FFDA1A] tracking-wider flex items-center gap-2">
              <mat-icon class="text-base">search</mat-icon>
              LOCATION INSPECTOR
            </h3>
            <span class="text-xs text-slate-400 font-mono">Click any location</span>
          </div>

          @if (selectedLocation()) {
            <div class="space-y-4 text-xs">
              <div class="bg-slate-800 p-3 rounded border border-slate-700 space-y-1">
                <span class="text-[10px] font-mono text-blue-400 uppercase">Selected Location Address</span>
                <p class="text-lg font-black font-mono text-white">{{ selectedLocation()?.locationId }}</p>
                <div class="flex items-center justify-between text-slate-400 pt-1 border-t border-slate-700/60">
                  <span>Zone: {{ selectedLocation()?.zoneType }}</span>
                  <span class="font-bold text-emerald-400">Util: {{ selectedLocation()?.currentUtilisationPct }}%</span>
                </div>
              </div>

              <div class="space-y-2">
                <h4 class="font-bold text-slate-300 uppercase text-[11px]">Physical Specs & Capacity</h4>
                <div class="grid grid-cols-2 gap-2 text-slate-300 font-mono text-[11px]">
                  <div class="bg-slate-950 p-2 rounded border border-slate-800">
                    <span class="text-[9px] text-slate-500 block uppercase">Max Capacity</span>
                    <span>{{ selectedLocation()?.capacityM3 }} m³</span>
                  </div>
                  <div class="bg-slate-950 p-2 rounded border border-slate-800">
                    <span class="text-[9px] text-slate-500 block uppercase">Max Weight</span>
                    <span>{{ selectedLocation()?.capacityKg }} kg</span>
                  </div>
                </div>
              </div>

              <div class="space-y-2">
                <h4 class="font-bold text-slate-300 uppercase text-[11px]">Active Stock Allocated</h4>
                <div class="bg-slate-950 p-3 rounded border border-slate-800 space-y-2">
                  <div class="flex items-center justify-between">
                    <span class="font-bold text-white">BILLY-SYN-001</span>
                    <span class="font-mono font-bold text-[#FFDA1A]">84 Units</span>
                  </div>
                  <p class="text-[10px] text-slate-400">SYNTHETIC-BILLY-BOOKCASE (Package 1 of 2)</p>
                  <div class="pt-2 border-t border-slate-800 flex justify-between text-[10px] text-slate-500 font-mono">
                    <span>Available: 72</span>
                    <span>Reserved: 8</span>
                  </div>
                </div>
              </div>

              <div class="space-y-2">
                <h4 class="font-bold text-slate-300 uppercase text-[11px]">Assigned Worker Tasks</h4>
                <div class="bg-blue-950/60 border border-blue-800 p-2.5 rounded text-[11px] space-y-1">
                  <div class="flex items-center justify-between text-blue-300 font-bold">
                    <span>TASK-7710</span>
                    <span class="bg-amber-500/20 text-amber-300 px-1.5 py-0.5 rounded text-[9px]">IN PROGRESS</span>
                  </div>
                  <p class="text-slate-300 text-[10px]">Worker ERik Johansson (WRK-8042) picking 2 units</p>
                </div>
              </div>
            </div>
          } @else {
            <div class="py-12 text-center text-slate-500 space-y-2">
              <mat-icon class="text-3xl text-slate-600">touch_app</mat-icon>
              <p class="text-xs">Click on any storage bin location in the map to inspect live stock, capacity, and active tasks.</p>
            </div>
          }
        </div>

      </div>

    </div>
  `
})
export class DigitalTwinComponent {
  readonly state = inject(WarehouseStateEngine);
  readonly selectedLocation = signal<WarehouseLocation | null>(null);
  readonly showHeatmap = signal(false);
  readonly clockSpeed = signal<'REAL_TIME' | 'FAST_2X'>('REAL_TIME');

  readonly activeClockClass = 'bg-[#FFDA1A] text-black font-extrabold px-3 py-1.5 rounded shadow';
  readonly inactiveClockClass = 'bg-slate-800 text-slate-300 px-3 py-1.5 rounded hover:bg-slate-700';

  getAisleLocations(aislePrefix: string): WarehouseLocation[] {
    return this.state.locations().filter(l => l.locationId.includes(aislePrefix)).slice(0, 6);
  }

  selectLocation(loc: WarehouseLocation) {
    this.selectedLocation.set(loc);
  }

  toggleHeatmap() {
    this.showHeatmap.update(v => !v);
  }

  setClockSpeed(speed: 'REAL_TIME' | 'FAST_2X') {
    this.clockSpeed.set(speed);
  }

  getLocationCardClass(loc: WarehouseLocation): string {
    const isSelected = this.selectedLocation()?.locationId === loc.locationId;

    if (this.showHeatmap()) {
      if (loc.currentUtilisationPct > 80) return 'bg-red-950/90 border-red-600 text-red-200';
      if (loc.currentUtilisationPct > 60) return 'bg-amber-950/90 border-amber-600 text-amber-200';
      return 'bg-emerald-950/90 border-emerald-600 text-emerald-200';
    }

    if (isSelected) {
      return 'bg-[#FFDA1A] text-black border-white font-bold scale-105 shadow-lg';
    }

    return 'bg-slate-950/80 border-slate-800 text-slate-300 hover:border-slate-500';
  }
}
