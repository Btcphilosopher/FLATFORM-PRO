export type UnitSystem = 'mm' | 'cm' | 'm' | 'in';

export type FurnitureCategory =
  | 'wardrobe'
  | 'base_cabinet'
  | 'wall_cabinet'
  | 'tall_cabinet'
  | 'bookcase'
  | 'desk'
  | 'sideboard'
  | 'tv_unit'
  | 'chest_of_drawers'
  | 'custom';

export type ComponentType =
  | 'side_left'
  | 'side_right'
  | 'top'
  | 'bottom'
  | 'back'
  | 'partition'
  | 'shelf_fixed'
  | 'shelf_adjustable'
  | 'door_left'
  | 'door_right'
  | 'door_single'
  | 'drawer_front'
  | 'drawer_box'
  | 'plinth'
  | 'leg'
  | 'hardware';

export type JointType =
  | 'cam_lock_dowel'
  | 'confirmat_screw'
  | 'wood_dowel_only'
  | 'pocket_screw'
  | 'dado_groove'
  | 'biscuit'
  | 'corner_bracket'
  | 'hidden_connector';

export type EdgeBandingType = 'none' | '0.4mm_pvc' | '1.0mm_abs' | '2.0mm_abs' | 'wood_veneer';

export type ShadingMode = 'solid' | 'wireframe' | 'materials' | 'xray' | 'exploded';

export type CameraPreset =
  | 'perspective'
  | 'isometric'
  | 'front'
  | 'rear'
  | 'left'
  | 'right'
  | 'top'
  | 'bottom';

export type WorkspaceMode = 'engineering' | 'configurator';

export type ViewportMode = '3d' | '2d_drawing' | 'split';

export interface Vector3D {
  x: number;
  y: number;
  z: number;
}

export interface Dimension3D {
  width: number;  // X span in mm
  height: number; // Y span in mm
  depth: number;  // Z span in mm
}

export interface MaterialDefinition {
  id: string;
  name: string;
  category: 'solid_wood' | 'panel_board' | 'finish' | 'composite';
  color: string;
  roughness: number;
  metalness: number;
  densityKgM3: number;
  thicknessOptionsMm: number[];
  defaultThicknessMm: number;
  costPerM2: number;
  grainTexture: 'horizontal' | 'vertical' | 'none';
  description: string;
}

export interface HardwareItem {
  id: string;
  name: string;
  category: 'hinge' | 'slide' | 'cam_lock' | 'dowel' | 'screw' | 'handle' | 'shelf_pin' | 'foot' | 'bracket';
  model: string;
  manufacturer: string;
  unitCost: number;
  quantity?: number;
  dimensions: Dimension3D;
  position: Vector3D;
  rotation: Vector3D;
  attachedToComponentId?: string;
  description: string;
}

export interface MachiningHole {
  id: string;
  diameterMm: number;
  depthMm: number;
  x: number; // local face coordinate
  y: number;
  face: 'front' | 'back' | 'top' | 'bottom' | 'left' | 'right';
  purpose: 'cam_pin' | 'cam_housing' | 'dowel' | 'shelf_pin' | 'hinge_cup' | 'slide_mount' | 'handle';
}

export interface MachiningGroove {
  id: string;
  name: string;
  widthMm: number;
  depthMm: number;
  offsetMm: number;
  direction: 'horizontal' | 'vertical';
  purpose: 'back_panel_slot' | 'drawer_bottom_slot' | 'dado';
}

export interface EdgeTreatments {
  top: EdgeBandingType;
  bottom: EdgeBandingType;
  left: EdgeBandingType;
  right: EdgeBandingType;
}

export interface FurnitureComponent {
  id: string;
  name: string;
  type: ComponentType;
  category: 'structure' | 'interior' | 'doors' | 'drawers' | 'hardware';
  dimensions: Dimension3D; // mm
  position: Vector3D;     // mm relative to furniture origin (center bottom)
  rotation: Vector3D;     // degrees
  materialId: string;
  thicknessMm: number;
  quantity: number;
  visible: boolean;
  locked: boolean;
  edgeTreatments: EdgeTreatments;
  grainDirection: 'length' | 'width' | 'none';
  machiningHoles: MachiningHole[];
  machiningGrooves: MachiningGroove[];
  hardwareIds: string[];
  subComponents?: FurnitureComponent[];
  customProperties?: Record<string, any>;
}

export interface ParametricConfig {
  // Global dimensions
  width: number;          // mm
  height: number;         // mm
  depth: number;          // mm
  
  // Construction rules
  carcassThickness: number;   // default 18mm
  backPanelThickness: number; // default 6mm
  backPanelGrooveDepth: number; // default 8mm
  backPanelInset: number;     // default 15mm
  plinthHeight: number;       // default 80mm
  plinthSetback: number;      // default 20mm
  jointType: JointType;
  
  // Interior divisions
  baysCount: number;          // 1, 2, or 3
  shelvesPerBay: number[];    // e.g. [3, 4]
  shelfSpacingMode: 'equal' | 'custom';
  shelfSetback: number;       // default 15mm
  
  // Doors
  hasDoors: boolean;
  doorType: 'slab' | 'framed' | 'sliding' | 'glass';
  doorBays: number[];         // which bays have doors
  doorGap: number;            // default 2.5mm
  doorOpeningAngle: number;   // 0 = closed, 90 = open
  
  // Drawers
  hasDrawers: boolean;
  drawerBays: number[];       // which bays have drawers
  drawersCount: number;       // total in drawer section
  drawerClearance: number;    // default 3mm
  drawerHeightMm: number;     // default 180mm
  drawerSlideType: 'undermount_soft_close' | 'ball_bearing_side';
  
  // Materials
  defaultCarcassMaterialId: string;
  defaultFrontMaterialId: string;
  defaultBackMaterialId: string;
}

export interface DesignWarning {
  id: string;
  severity: 'info' | 'warning' | 'error';
  title: string;
  message: string;
  componentId?: string;
  ruleCategory: 'structural' | 'clearance' | 'machining' | 'hardware' | 'manufacturability';
  recommendedAction?: string;
}

export interface BOMItem {
  id: string;
  partNumber: string;
  name: string;
  type: ComponentType | 'hardware';
  quantity: number;
  materialName: string;
  dimensionsMm: string;
  thicknessMm: number;
  areaM2: number;
  weightKg: number;
  unitCostEst: number;
  totalCostEst: number;
}

export interface CutListPiece {
  id: string;
  partNumber: string;
  name: string;
  quantity: number;
  lengthMm: number;
  widthMm: number;
  thicknessMm: number;
  materialId: string;
  materialName: string;
  grainDirection: 'length' | 'width' | 'none';
  edgeBandingSummary: string;
  cncOpsCount: number;
}

export interface SheetNestingPlan {
  sheetMaterialId: string;
  sheetMaterialName: string;
  sheetThicknessMm: number;
  sheetWidthMm: number;
  sheetLengthMm: number;
  totalSheetsRequired: number;
  totalPieces: number;
  materialUtilizationPercent: number;
  wasteAreaM2: number;
  sheets: {
    sheetIndex: number;
    placedPieces: {
      pieceId: string;
      partNumber: string;
      name: string;
      x: number;
      y: number;
      width: number;
      height: number;
      rotated: boolean;
    }[];
    wastePercent: number;
  }[];
}

export interface AssemblyStep {
  stepNumber: number;
  title: string;
  instruction: string;
  targetComponentIds: string[];
  requiredHardware: { name: string; count: number; iconType: string }[];
  requiredTools: string[];
  estimatedMinutes: number;
  safetyTip?: string;
}

export interface DesignVariant {
  id: string;
  name: string;
  description: string;
  configOverrides?: Partial<ParametricConfig>;
  materialOverrideId?: string;
  widthOverride?: number;
  doorStyleOverride?: string;
}

export interface FurnitureProject {
  id: string;
  name: string;
  version: string;
  category: FurnitureCategory;
  createdDate?: string;
  lastModifiedDate?: string;
  createdAt?: string;
  updatedAt?: string;
  author?: string;
  notes?: string;
  description?: string;
  config: ParametricConfig;
  components: FurnitureComponent[];
  hardwareItems: HardwareItem[];
  variants: DesignVariant[];
  activeVariantId: string | null;
  unitSystem: UnitSystem;
}
