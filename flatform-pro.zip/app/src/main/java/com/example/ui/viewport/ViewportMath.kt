package com.example.ui.viewport

import androidx.compose.ui.geometry.Offset
import com.example.domain.model.Dimension3D
import com.example.domain.model.FurnitureComponent
import com.example.domain.model.Vector3D
import kotlin.math.*

enum class ViewportProjection {
    PERSPECTIVE,
    ORTHOGRAPHIC,
    ISOMETRIC
}

enum class ShadingMode {
    MATERIAL_TEXTURED,
    TECHNICAL_SOLID,
    WIREFRAME,
    X_RAY,
    EXPLODED
}

enum class CameraPreset {
    PERSPECTIVE_DEFAULT,
    ISOMETRIC,
    FRONT,
    REAR,
    LEFT,
    RIGHT,
    TOP,
    BOTTOM
}

data class CameraState(
    val yawDeg: Float = 35f,       // Orbit azimuth angle
    val pitchDeg: Float = 22f,     // Orbit elevation angle (-89 to +89)
    val distance: Float = 3200f,   // Camera distance (mm)
    val panX: Float = 0f,          // Screen pan offset X (pixels)
    val panY: Float = 0f,          // Screen pan offset Y (pixels)
    val projection: ViewportProjection = ViewportProjection.PERSPECTIVE
)

data class ProjectedPoint(
    val screenX: Float,
    val screenY: Float,
    val depthZ: Float
)

data class ProjectedFace(
    val points: List<Offset>,
    val averageDepthZ: Float,
    val normalZ: Float, // Dot product with light
    val color: Long,
    val componentId: String,
    val faceName: String
)

data class ProjectedComponent(
    val component: FurnitureComponent,
    val faces: List<ProjectedFace>,
    val averageDepth: Float,
    val minScreenX: Float,
    val maxScreenX: Float,
    val minScreenY: Float,
    val maxScreenY: Float
)

object Viewport3DEngine {

    /**
     * Transforms a 3D world coordinate into 2D canvas screen coordinate.
     */
    fun project3DTo2D(
        point: Vector3D,
        camera: CameraState,
        screenWidth: Float,
        screenHeight: Float,
        worldCenter: Vector3D = Vector3D(0f, 0f, 0f)
    ): ProjectedPoint {
        // 1. Center around world origin
        val relX = point.x - worldCenter.x
        val relY = point.y - worldCenter.y
        val relZ = point.z - worldCenter.z

        // 2. Rotate by Yaw (around Y axis)
        val yawRad = Math.toRadians(camera.yawDeg.toDouble())
        val cosY = cos(yawRad).toFloat()
        val sinY = sin(yawRad).toFloat()

        val x1 = relX * cosY - relZ * sinY
        val y1 = relY
        val z1 = relX * sinY + relZ * cosY

        // 3. Rotate by Pitch (around X axis)
        val pitchRad = Math.toRadians(camera.pitchDeg.toDouble())
        val cosP = cos(pitchRad).toFloat()
        val sinP = sin(pitchRad).toFloat()

        val x2 = x1
        val y2 = y1 * cosP - z1 * sinP
        val z2 = y1 * sinP + z1 * cosP

        // 4. Translate by Camera Distance
        val camZ = z2 + camera.distance

        // 5. Projection
        val screenX: Float
        val screenY: Float

        val cx = screenWidth / 2f + camera.panX
        val cy = screenHeight / 2f + camera.panY

        when (camera.projection) {
            ViewportProjection.PERSPECTIVE -> {
                val fovFactor = min(screenWidth, screenHeight) * 1.8f
                val safeZ = max(100f, camZ)
                val scale = fovFactor / safeZ
                screenX = cx + (x2 * scale)
                screenY = cy - (y2 * scale) // Flip Y for screen space
            }
            ViewportProjection.ORTHOGRAPHIC, ViewportProjection.ISOMETRIC -> {
                val scale = (min(screenWidth, screenHeight) / camera.distance) * 1.6f
                screenX = cx + (x2 * scale)
                screenY = cy - (y2 * scale)
            }
        }

        return ProjectedPoint(screenX, screenY, camZ)
    }

    /**
     * Builds and projects all 6 faces of a 3D box component with depth sorting and directional lighting.
     */
    fun projectCuboid(
        comp: FurnitureComponent,
        camera: CameraState,
        screenWidth: Float,
        screenHeight: Float,
        worldCenter: Vector3D,
        baseColor: Long,
        explodedFactor: Float = 0f,
        isSelected: Boolean = false,
        shadingMode: ShadingMode = ShadingMode.MATERIAL_TEXTURED
    ): ProjectedComponent {
        val pos = comp.position + (comp.explosiveOffset * explodedFactor)
        val dim = comp.dimensions

        val x0 = pos.x
        val x1 = pos.x + dim.width
        val y0 = pos.y
        val y1 = pos.y + dim.height
        val z0 = pos.z
        val z1 = pos.z + dim.depth

        // 8 Vertices of the 3D Panel
        val v000 = project3DTo2D(Vector3D(x0, y0, z0), camera, screenWidth, screenHeight, worldCenter)
        val v100 = project3DTo2D(Vector3D(x1, y0, z0), camera, screenWidth, screenHeight, worldCenter)
        val v110 = project3DTo2D(Vector3D(x1, y1, z0), camera, screenWidth, screenHeight, worldCenter)
        val v010 = project3DTo2D(Vector3D(x0, y1, z0), camera, screenWidth, screenHeight, worldCenter)

        val v001 = project3DTo2D(Vector3D(x0, y0, z1), camera, screenWidth, screenHeight, worldCenter)
        val v101 = project3DTo2D(Vector3D(x1, y0, z1), camera, screenWidth, screenHeight, worldCenter)
        val v111 = project3DTo2D(Vector3D(x1, y1, z1), camera, screenWidth, screenHeight, worldCenter)
        val v011 = project3DTo2D(Vector3D(x0, y1, z1), camera, screenWidth, screenHeight, worldCenter)

        // 6 Faces definitions with lighting tints
        val facesData = listOf(
            // Front face (Z min)
            Triple(listOf(v000, v100, v110, v010), 1.0f, "Front"),
            // Back face (Z max)
            Triple(listOf(v101, v001, v011, v111), 0.7f, "Back"),
            // Top face (Y max)
            Triple(listOf(v010, v110, v111, v011), 1.15f, "Top"),
            // Bottom face (Y min)
            Triple(listOf(v001, v101, v100, v000), 0.55f, "Bottom"),
            // Left face (X min)
            Triple(listOf(v001, v000, v010, v011), 0.85f, "Left"),
            // Right face (X max)
            Triple(listOf(v100, v101, v111, v110), 0.95f, "Right")
        )

        val projectedFaces = mutableListOf<ProjectedFace>()
        var minSx = Float.MAX_VALUE
        var maxSx = -Float.MAX_VALUE
        var minSy = Float.MAX_VALUE
        var maxSy = -Float.MAX_VALUE
        var totalDepth = 0f
        var vertCount = 0

        facesData.forEach { (verts, lightFactor, name) ->
            val points = verts.map {
                minSx = min(minSx, it.screenX)
                maxSx = max(maxSx, it.screenX)
                minSy = min(minSy, it.screenY)
                maxSy = max(maxSy, it.screenY)
                totalDepth += it.depthZ
                vertCount++
                Offset(it.screenX, it.screenY)
            }

            // Calculate face normal direction to test backface culling
            val isClockwise = isPolygonClockwise(points)
            if (isClockwise) {
                val avgZ = verts.map { it.depthZ }.average().toFloat()

                val faceColor = when {
                    isSelected -> 0xFF38BDF8
                    shadingMode == ShadingMode.TECHNICAL_SOLID -> applyShading(0xFF5A6578, lightFactor)
                    shadingMode == ShadingMode.X_RAY -> 0x4438BDF8
                    else -> applyShading(baseColor, lightFactor)
                }

                projectedFaces.add(
                    ProjectedFace(
                        points = points,
                        averageDepthZ = avgZ,
                        normalZ = lightFactor,
                        color = faceColor,
                        componentId = comp.id,
                        faceName = name
                    )
                )
            }
        }

        return ProjectedComponent(
            component = comp,
            faces = projectedFaces,
            averageDepth = if (vertCount > 0) totalDepth / vertCount else 0f,
            minScreenX = minSx,
            maxScreenX = maxSx,
            minScreenY = minSy,
            maxScreenY = maxSy
        )
    }

    private fun isPolygonClockwise(pts: List<Offset>): Boolean {
        if (pts.size < 3) return false
        var sum = 0f
        for (i in pts.indices) {
            val p1 = pts[i]
            val p2 = pts[(i + 1) % pts.size]
            sum += (p2.x - p1.x) * (p2.y + p1.y)
        }
        return sum < 0 // Clockwise in screen coordinates where Y is down
    }

    private fun applyShading(colorArgb: Long, factor: Float): Long {
        val a = (colorArgb shr 24) and 0xFF
        val r = min(255, (((colorArgb shr 16) and 0xFF) * factor).toInt())
        val g = min(255, (((colorArgb shr 8) and 0xFF) * factor).toInt())
        val b = min(255, ((colorArgb and 0xFF) * factor).toInt())
        return (a shl 24) or (r.toLong() shl 16) or (g.toLong() shl 8) or b.toLong()
    }

    /**
     * Hit testing: checks if a 2D screen coordinate touches any face of the component.
     */
    fun hitTest(x: Float, y: Float, comp: ProjectedComponent): Boolean {
        if (x < comp.minScreenX || x > comp.maxScreenX || y < comp.minScreenY || y > comp.maxScreenY) {
            return false
        }
        val pt = Offset(x, y)
        return comp.faces.any { face -> isPointInPolygon(pt, face.points) }
    }

    private fun isPointInPolygon(pt: Offset, polygon: List<Offset>): Boolean {
        var inside = false
        var j = polygon.size - 1
        for (i in polygon.indices) {
            val pi = polygon[i]
            val pj = polygon[j]
            if ((pi.y > pt.y) != (pj.y > pt.y) &&
                pt.x < (pj.x - pi.x) * (pt.y - pi.y) / (pj.y - pi.y) + pi.x
            ) {
                inside = !inside
            }
            j = i
        }
        return inside
    }
}
