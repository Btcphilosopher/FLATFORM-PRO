package com.example.ui.panels

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.hardware.HardwareCatalog
import com.example.domain.model.FurnitureProject
import com.example.domain.model.HardwareCategory
import com.example.ui.theme.*

@Composable
fun HardwareCatalogPanel(
    project: FurnitureProject,
    modifier: Modifier = Modifier
) {
    var activeCat by remember { mutableStateOf<HardwareCategory?>(null) }

    Column(
        modifier = modifier
            .fillMaxHeight()
            .background(CadSurface)
            .testTag("hardware_catalog_panel")
    ) {
        // Header
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = "HARDWARE & FASTENERS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = CadAccentBlue,
                letterSpacing = 1.sp
            )

            // Category Filter Chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                FilterChip(
                    selected = activeCat == null,
                    onClick = { activeCat = null },
                    label = { Text("All", fontSize = 10.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = CadAccentBlue.copy(alpha = 0.2f),
                        selectedLabelColor = CadAccentBlue,
                        containerColor = CadSurfaceVariant,
                        labelColor = CadTextSecondary
                    ),
                    modifier = Modifier.height(26.dp)
                )
                listOf(HardwareCategory.HINGES, HardwareCategory.DRAWER_SLIDES, HardwareCategory.CAM_LOCKS_DOWELS).forEach { cat ->
                    FilterChip(
                        selected = activeCat == cat,
                        onClick = { activeCat = cat },
                        label = { Text(cat.name.replace("_", " ").lowercase().capitalize(), fontSize = 10.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = CadAccentBlue.copy(alpha = 0.2f),
                            selectedLabelColor = CadAccentBlue,
                            containerColor = CadSurfaceVariant,
                            labelColor = CadTextSecondary
                        ),
                        modifier = Modifier.height(26.dp)
                    )
                }
            }
        }

        HorizontalDivider(color = CadBorder)

        val items = project.hardwareList.filter {
            activeCat == null || it.category == activeCat
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(items, key = { it.id }) { hw ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = CadSurfaceVariant),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CadBorder),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = hw.name,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = CadTextPrimary,
                                modifier = Modifier.weight(1f)
                            )
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = CadAccentCyan.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = "Qty: ${hw.quantity}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = CadAccentCyan,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Text(
                            text = "Code: ${hw.code} • Mount: ${hw.mountingType}",
                            fontSize = 10.sp,
                            color = CadTextSecondary
                        )

                        Text(
                            text = hw.specs,
                            fontSize = 10.sp,
                            color = CadTextMuted
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Unit Cost: €${String.format("%.2f", hw.unitCost)}",
                                fontSize = 10.sp,
                                color = CadAccentAmber
                            )
                            Text(
                                text = "Total: €${String.format("%.2f", hw.unitCost * hw.quantity)}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = CadTextPrimary
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun String.capitalize(): String = replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
