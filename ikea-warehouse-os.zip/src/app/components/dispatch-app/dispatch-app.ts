import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { WarehouseStateEngine } from '../../core/services/warehouse-state.service';

@Component({
  selector: 'app-dispatch-app',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 bg-[#F4F4F4] min-h-screen text-slate-900 space-y-6">
      
      <div class="bg-white border border-slate-300 p-5 rounded-lg shadow-sm flex items-center justify-between">
        <div>
          <span class="bg-[#0058A3] text-white font-bold text-xs px-2.5 py-0.5 rounded uppercase">OUTBOUND DISPATCH</span>
          <h2 class="text-2xl font-black text-slate-900 uppercase mt-1">DISPATCH & VEHICLE LOAD OPTIMIZER</h2>
          <p class="text-xs text-slate-600">3D Package Volumetric Arrangement • Outbound Dock Management • Delivery Routes</p>
        </div>

        <span class="bg-blue-100 text-[#0058A3] font-black text-xs px-3 py-1.5 rounded">
          2 Trucks Loaded Today
        </span>
      </div>

      <!-- Truck Load Plan Display -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div class="bg-white border border-slate-300 rounded-lg p-5 shadow-sm space-y-4">
          <div class="flex justify-between items-center border-b border-slate-200 pb-2">
            <div>
              <span class="text-xs font-mono text-slate-500">Route #SE-STO-04</span>
              <h3 class="font-black text-slate-900 text-lg">Delivery Truck SE-882 (Volvo FM)</h3>
            </div>
            <span class="bg-emerald-100 text-emerald-800 font-extrabold text-xs px-2.5 py-1 rounded">
              LOAD 94% OPTIMIZED
            </span>
          </div>

          <!-- 3D/2D Visual Truck Compartment Grid -->
          <div class="bg-slate-900 text-white p-4 rounded-lg space-y-2">
            <span class="text-[10px] text-slate-400 font-mono uppercase block">3D Trailer Load Arrangement Plan</span>
            
            <div class="grid grid-cols-4 gap-2 h-40 border-2 border-slate-700 p-2 rounded bg-slate-950">
              <div class="bg-amber-600/90 text-black font-extrabold text-[10px] p-2 rounded flex flex-col justify-between">
                <span>FRONT LEFT</span>
                <span>PAX (42kg)</span>
              </div>
              <div class="bg-amber-600/90 text-black font-extrabold text-[10px] p-2 rounded flex flex-col justify-between">
                <span>FRONT RIGHT</span>
                <span>PAX (38kg)</span>
              </div>
              <div class="bg-blue-600/90 text-white font-extrabold text-[10px] p-2 rounded flex flex-col justify-between">
                <span>MID</span>
                <span>BILLY (22kg)</span>
              </div>
              <div class="bg-emerald-600/90 text-black font-extrabold text-[10px] p-2 rounded flex flex-col justify-between">
                <span>REAR (LAST IN)</span>
                <span>KALLAX (18kg)</span>
              </div>
            </div>

            <p class="text-[11px] text-slate-300">Stacking Rule: Heavy flat-pack furniture stacked on base level; fragile packages top-loaded.</p>
          </div>
        </div>

        <div class="bg-white border border-slate-300 rounded-lg p-5 shadow-sm space-y-4">
          <h3 class="font-black text-slate-900 text-base border-b border-slate-200 pb-2">Outbound Delivery Stops</h3>
          <div class="space-y-3">
            <div class="bg-slate-50 border border-slate-200 p-3 rounded flex items-center justify-between text-xs">
              <div>
                <span class="font-bold text-slate-900">Stop 1: Kungsgatan 14, Stockholm</span>
                <span class="text-[10px] text-slate-500 block">Order #ORD-100045 (3 Packages)</span>
              </div>
              <span class="font-mono text-emerald-700 font-bold">ETA 15:45</span>
            </div>
            <div class="bg-slate-50 border border-slate-200 p-3 rounded flex items-center justify-between text-xs">
              <div>
                <span class="font-bold text-slate-900">Stop 2: Sveavägen 82, Stockholm</span>
                <span class="text-[10px] text-slate-500 block">Order #ORD-100048 (2 Packages)</span>
              </div>
              <span class="font-mono text-slate-600 font-bold">ETA 16:30</span>
            </div>
          </div>
        </div>
      </div>

    </div>
  `
})
export class DispatchAppComponent {
  readonly state = inject(WarehouseStateEngine);
}
