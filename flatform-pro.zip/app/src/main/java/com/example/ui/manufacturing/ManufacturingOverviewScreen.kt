package com.example.ui.manufacturing

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.BomItem
import com.example.domain.model.CutListItem
import com.example.domain.model.FurnitureProject
import com.example.ui.theme.*

enum class ManufacturingTab {
    BILL_OF_MATERIALS,
    CUT_LIST_OPTIMIZER,
    NESTING_LAYOUTS,
    CNC_GCODE_PREVIEW
}

@Composable
fun ManufacturingOverviewScreen(
    project: FurnitureProject,
    onOpenExportModal: () -> Unit,
    modifier: Modifier = Modifier
) {
    var activeTab by remember { mutableStateOf(ManufacturingTab.BILL_OF_MATERIALS) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CadBackground)
            .testTag("manufacturing_screen")
    ) {
        // Top Sub-Navigation & Export Action Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(CadSurface)
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Tabs
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                ManufacturingTab.values().forEach { tab ->
                    val isSel = activeTab == tab
                    FilterChip(
                        selected = isSel,
                        onClick = { activeTab = tab },
                        label = {
                            Text(
                                text = tab.name.replace("_", " ").lowercase().capitalize(),
                                fontSize = 11.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = CadAccentBlue.copy(alpha = 0.2f),
                            selectedLabelColor = CadAccentBlue,
                            containerColor = CadSurfaceVariant,
                            labelColor = CadTextSecondary
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSel,
                            borderColor = if (isSel) CadAccentBlue else CadBorder
                        )
                    )
                }
            }

            // Export Actions
            Button(
                onClick = onOpenExportModal,
                shape = RoundedCornerShape(6.dp),
                colors = ButtonDefaults.buttonColors(containerColor = CadAccentBlue, contentColor = Color.Black),
                modifier = Modifier.height(34.dp).testTag("btn_export_manufacturing")
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                    Text("Export CNC / BOM", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        HorizontalDivider(color = CadBorder)

        // Summary Metric Tiles
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            val totalCost = project.bomItems.sumOf { it.totalCost.toDouble() }.toFloat()
            val totalParts = project.components.size
            val totalSheets = project.nestingSheets.size
            val avgWaste = if (project.nestingSheets.isNotEmpty()) project.nestingSheets.map { it.wastePercentage }.average().toFloat() else 0f

            MetricTile("TOTAL COST ESTIMATE", "€${String.format("%.2f", totalCost)}", CadAccentAmber, Modifier.weight(1f))
            MetricTile("TOTAL CUT PANELS", "$totalParts Parts", CadAccentBlue, Modifier.weight(1f))
            MetricTile("RAW SHEET COUNT", "$totalSheets × Standard 2440×1220", CadAccentCyan, Modifier.weight(1f))
            MetricTile("AVG NESTING SCRAP", "${String.format("%.1f", avgWaste)}% Waste", if (avgWaste < 20f) CadAccentGreen else CadAccentAmber, Modifier.weight(1f))
        }

        // Tab Content
        Box(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 4.dp)) {
            when (activeTab) {
                ManufacturingTab.BILL_OF_MATERIALS -> BomTableView(project.bomItems)
                ManufacturingTab.CUT_LIST_OPTIMIZER -> CutListTableView(project.cutListItems)
                ManufacturingTab.NESTING_LAYOUTS -> NestingSheetsView(project.nestingSheets)
                ManufacturingTab.CNC_GCODE_PREVIEW -> CncGCodePreviewView(project)
            }
        }
    }
}

@Composable
private fun MetricTile(label: String, value: String, valueColor: Color, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = CadSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, CadBorder),
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(label, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = CadTextMuted, letterSpacing = 0.5.sp)
            Text(value, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = valueColor, fontFamily = FontFamily.Monospace)
        }
    }
}

@Composable
private fun BomTableView(items: List<BomItem>) {
    val hScroll = rememberScrollState()

    Card(
        colors = CardDefaults.cardColors(containerColor = CadSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, CadBorder),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        Column(modifier = Modifier.fillMaxSize().padding(8.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(hScroll)
                    .background(CadSurfaceElevated, RoundedCornerShape(4.dp))
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Part #", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = CadAccentBlue, modifier = Modifier.width(80.dp))
                Text("Description / Name", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = CadTextSecondary, modifier = Modifier.width(180.dp))
                Text("Category", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = CadTextSecondary, modifier = Modifier.width(100.dp))
                Text("Dimensions (mm)", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = CadTextSecondary, modifier = Modifier.width(130.dp))
                Text("Material / Spec", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = CadTextSecondary, modifier = Modifier.width(160.dp))
                Text("Qty", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = CadTextSecondary, modifier = Modifier.width(50.dp))
                Text("Unit (€)", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = CadTextSecondary, modifier = Modifier.width(70.dp))
                Text("Total (€)", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = CadAccentAmber, modifier = Modifier.width(80.dp))
            }

            HorizontalDivider(color = CadBorder)

            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(items) { item ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(hScroll)
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(item.partNumber, fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = CadAccentCyan, modifier = Modifier.width(80.dp))
                        Text(item.name, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = CadTextPrimary, modifier = Modifier.width(180.dp))
                        Text(item.category, fontSize = 10.sp, color = CadTextSecondary, modifier = Modifier.width(100.dp))
                        Text(item.dimensions, fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = CadTextPrimary, modifier = Modifier.width(130.dp))
                        Text(item.materialName, fontSize = 10.sp, color = CadTextMuted, modifier = Modifier.width(160.dp))
                        Text("${item.quantity}", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = CadTextPrimary, modifier = Modifier.width(50.dp))
                        Text(String.format("%.2f", item.unitCost), fontSize = 10.sp, color = CadTextSecondary, modifier = Modifier.width(70.dp))
                        Text(String.format("%.2f", item.totalCost), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CadAccentAmber, modifier = Modifier.width(80.dp))
                    }
                    HorizontalDivider(color = CadBorderSubtle)
                }
            }
        }
    }
}

@Composable
private fun CutListTableView(items: List<CutListItem>) {
    val hScroll = rememberScrollState()

    Card(
        colors = CardDefaults.cardColors(containerColor = CadSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, CadBorder),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        Column(modifier = Modifier.fillMaxSize().padding(8.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(hScroll)
                    .background(CadSurfaceElevated, RoundedCornerShape(4.dp))
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Cut ID", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = CadAccentBlue, modifier = Modifier.width(80.dp))
                Text("Part Name", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = CadTextSecondary, modifier = Modifier.width(160.dp))
                Text("Length (mm)", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = CadTextSecondary, modifier = Modifier.width(90.dp))
                Text("Width (mm)", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = CadTextSecondary, modifier = Modifier.width(90.dp))
                Text("Thick", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = CadTextSecondary, modifier = Modifier.width(60.dp))
                Text("Material Panel", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = CadTextSecondary, modifier = Modifier.width(150.dp))
                Text("Grain", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = CadTextSecondary, modifier = Modifier.width(80.dp))
                Text("Edge Banding", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = CadTextSecondary, modifier = Modifier.width(120.dp))
                Text("CNC Ops", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = CadAccentCyan, modifier = Modifier.width(70.dp))
            }

            HorizontalDivider(color = CadBorder)

            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(items) { item ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(hScroll)
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(item.partNumber, fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = CadAccentBlue, modifier = Modifier.width(80.dp))
                        Text(item.name, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = CadTextPrimary, modifier = Modifier.width(160.dp))
                        Text("${item.lengthMm.toInt()}", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = CadTextPrimary, modifier = Modifier.width(90.dp))
                        Text("${item.widthMm.toInt()}", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = CadTextPrimary, modifier = Modifier.width(90.dp))
                        Text("${item.thicknessMm.toInt()}", fontSize = 10.sp, color = CadTextMuted, modifier = Modifier.width(60.dp))
                        Text(item.materialName, fontSize = 10.sp, color = CadTextSecondary, modifier = Modifier.width(150.dp))
                        Text(item.grainDirection.name, fontSize = 10.sp, color = CadAccentAmber, modifier = Modifier.width(80.dp))
                        Text(item.edgeTreatment, fontSize = 10.sp, color = CadTextMuted, modifier = Modifier.width(120.dp))
                        Text("${item.cncOperationsCount} ops", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = CadAccentCyan, modifier = Modifier.width(70.dp))
                    }
                    HorizontalDivider(color = CadBorderSubtle)
                }
            }
        }
    }
}

@Composable
private fun CncGCodePreviewView(project: FurnitureProject) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CadSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, CadBorder),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("CNC ISO G-CODE PROGRAMMING PREVIEW", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CadAccentBlue)
                Surface(shape = RoundedCornerShape(4.dp), color = CadSurfaceVariant) {
                    Text("Post-Processor: Biesse Rover / Homag Weeke Compatible", fontSize = 10.sp, color = CadTextSecondary, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                }
            }

            val gcodeSample = buildString {
                appendLine("%")
                appendLine("(FLATFORM PRO CNC POST PROCESSOR V1.0)")
                appendLine("(PROJECT: ${project.name})")
                appendLine("(DATE: ${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm").format(java.util.Date())})")
                appendLine("G21 (Metric units mm)")
                appendLine("G90 (Absolute coordinates)")
                appendLine("G17 (XY plane selection)")
                appendLine("T01 M06 (Tool 01: 9.5mm Compression End Mill)")
                appendLine("S18000 M03 (Spindle 18000 RPM Clockwise)")
                appendLine("G00 Z25.000 (Safe clearance height)")
                project.components.take(3).forEach { comp ->
                    appendLine("(---- COMPONENT: ${comp.name} ----)")
                    appendLine("G00 X${comp.position.x.toInt()}.000 Y${comp.position.y.toInt()}.000")
                    appendLine("G01 Z-18.200 F3500")
                    appendLine("G01 X${(comp.position.x + comp.dimensions.width).toInt()}.000 F6500")
                    appendLine("G00 Z25.000")
                }
                appendLine("M05 (Spindle Stop)")
                appendLine("G00 X0.000 Y0.000")
                appendLine("M30 (End of program)")
                appendLine("%")
            }

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF0F172A), RoundedCornerShape(6.dp))
                    .padding(12.dp)
            ) {
                Text(
                    text = gcodeSample,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    color = CadAccentCyan,
                    lineHeight = 16.sp
                )
            }
        }
    }
}

private fun String.capitalize(): String = replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
