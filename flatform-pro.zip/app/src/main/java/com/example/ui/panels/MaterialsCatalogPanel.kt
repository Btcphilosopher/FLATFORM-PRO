package com.example.ui.panels

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.materials.MaterialLibrary
import com.example.domain.model.MaterialCategory
import com.example.ui.theme.*

@Composable
fun MaterialsCatalogPanel(
    selectedMaterialId: String,
    onSelectMaterial: (String) -> Unit,
    onApplyToAll: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var activeCategory by remember { mutableStateOf<MaterialCategory?>(null) }

    Column(
        modifier = modifier
            .fillMaxHeight()
            .background(CadSurface)
            .testTag("materials_catalog_panel")
    ) {
        // Header
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = "ENGINEERED MATERIALS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = CadAccentBlue,
                letterSpacing = 1.sp
            )

            // Category Filter Chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                FilterChip(
                    selected = activeCategory == null,
                    onClick = { activeCategory = null },
                    label = { Text("All", fontSize = 10.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = CadAccentBlue.copy(alpha = 0.2f),
                        selectedLabelColor = CadAccentBlue,
                        containerColor = CadSurfaceVariant,
                        labelColor = CadTextSecondary
                    ),
                    modifier = Modifier.height(26.dp)
                )
                MaterialCategory.values().take(2).forEach { cat ->
                    FilterChip(
                        selected = activeCategory == cat,
                        onClick = { activeCategory = cat },
                        label = { Text(cat.name.replace("_", " ").lowercase().capitalize(), fontSize = 10.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = CadAccentBlue.copy(alpha = 0.2f),
                            selectedLabelColor = CadAccentBlue,
                            containerColor = CadSurfaceVariant,
                            labelColor = CadTextSecondary
                        ),
                        modifier = Modifier.height(26.dp)
                    )
                }
            }
        }

        HorizontalDivider(color = CadBorder)

        // Materials List
        val filtered = MaterialLibrary.materials.filter {
            activeCategory == null || it.category == activeCategory
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(filtered, key = { it.id }) { mat ->
                val isSelected = mat.id == selectedMaterialId

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectMaterial(mat.id) },
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) CadSurfaceElevated else CadSurfaceVariant
                    ),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isSelected) CadAccentBlue else CadBorder
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Material Swatch Circle
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(Color(mat.primaryColor), CircleShape)
                                .border(1.dp, Color(mat.secondaryColor), CircleShape)
                        )

                        // Details
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = mat.name,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (isSelected) CadAccentBlue else CadTextPrimary
                            )
                            Text(
                                text = "${mat.finish.name.replace("_", " ").lowercase().capitalize()} • ${mat.densityKgM3.toInt()} kg/m³",
                                fontSize = 10.sp,
                                color = CadTextSecondary
                            )
                            Text(
                                text = "€${String.format("%.2f", mat.costPerM2)} / m² • ${mat.thicknessOptionsMm.joinToString("/")}mm",
                                fontSize = 10.sp,
                                color = CadAccentAmber
                            )
                        }

                        if (isSelected) {
                            Icon(
                                Icons.Default.Check,
                                contentDescription = "Active Material",
                                tint = CadAccentBlue,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }

            item {
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = { onApplyToAll(selectedMaterialId) },
                    modifier = Modifier.fillMaxWidth().height(36.dp),
                    shape = RoundedCornerShape(6.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CadAccentBlue,
                        contentColor = Color.Black
                    )
                ) {
                    Text("Apply Material to Entire Carcass", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

private fun String.capitalize(): String = replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
